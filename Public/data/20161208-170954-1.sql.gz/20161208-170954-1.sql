-- -----------------------------
-- MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : wxlongxiang
-- 
-- Part : #1
-- Date : 2016-12-08 17:09:54
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `my_access`
-- -----------------------------
DROP TABLE IF EXISTS `my_access`;
CREATE TABLE `my_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='授权表';

-- -----------------------------
-- Records of `my_access`
-- -----------------------------
INSERT INTO `my_access` VALUES ('1', '48', '3', '');
INSERT INTO `my_access` VALUES ('1', '47', '3', '');
INSERT INTO `my_access` VALUES ('1', '46', '3', '');
INSERT INTO `my_access` VALUES ('1', '45', '3', '');
INSERT INTO `my_access` VALUES ('1', '44', '3', '');
INSERT INTO `my_access` VALUES ('1', '43', '3', '');
INSERT INTO `my_access` VALUES ('1', '42', '3', '');
INSERT INTO `my_access` VALUES ('1', '41', '3', '');
INSERT INTO `my_access` VALUES ('1', '40', '3', '');
INSERT INTO `my_access` VALUES ('1', '39', '3', '');
INSERT INTO `my_access` VALUES ('1', '38', '3', '');
INSERT INTO `my_access` VALUES ('1', '37', '3', '');
INSERT INTO `my_access` VALUES ('1', '36', '3', '');
INSERT INTO `my_access` VALUES ('1', '8', '2', '');
INSERT INTO `my_access` VALUES ('1', '116', '3', '');
INSERT INTO `my_access` VALUES ('1', '103', '3', '');
INSERT INTO `my_access` VALUES ('1', '102', '3', '');
INSERT INTO `my_access` VALUES ('1', '101', '3', '');
INSERT INTO `my_access` VALUES ('1', '100', '3', '');
INSERT INTO `my_access` VALUES ('1', '99', '3', '');
INSERT INTO `my_access` VALUES ('1', '90', '3', '');
INSERT INTO `my_access` VALUES ('1', '89', '3', '');
INSERT INTO `my_access` VALUES ('1', '88', '3', '');
INSERT INTO `my_access` VALUES ('1', '87', '3', '');
INSERT INTO `my_access` VALUES ('1', '86', '3', '');
INSERT INTO `my_access` VALUES ('1', '81', '3', '');
INSERT INTO `my_access` VALUES ('1', '80', '3', '');
INSERT INTO `my_access` VALUES ('1', '79', '3', '');
INSERT INTO `my_access` VALUES ('1', '78', '3', '');
INSERT INTO `my_access` VALUES ('1', '77', '3', '');
INSERT INTO `my_access` VALUES ('1', '76', '3', '');
INSERT INTO `my_access` VALUES ('1', '75', '3', '');
INSERT INTO `my_access` VALUES ('1', '74', '3', '');
INSERT INTO `my_access` VALUES ('1', '7', '2', '');
INSERT INTO `my_access` VALUES ('1', '31', '3', '');
INSERT INTO `my_access` VALUES ('1', '30', '3', '');
INSERT INTO `my_access` VALUES ('1', '29', '3', '');
INSERT INTO `my_access` VALUES ('1', '28', '3', '');
INSERT INTO `my_access` VALUES ('1', '5', '2', '');
INSERT INTO `my_access` VALUES ('1', '115', '3', '');
INSERT INTO `my_access` VALUES ('1', '113', '3', '');
INSERT INTO `my_access` VALUES ('1', '112', '3', '');
INSERT INTO `my_access` VALUES ('1', '111', '3', '');
INSERT INTO `my_access` VALUES ('1', '110', '3', '');
INSERT INTO `my_access` VALUES ('1', '109', '3', '');
INSERT INTO `my_access` VALUES ('1', '108', '3', '');
INSERT INTO `my_access` VALUES ('1', '107', '3', '');
INSERT INTO `my_access` VALUES ('1', '106', '3', '');
INSERT INTO `my_access` VALUES ('1', '105', '3', '');
INSERT INTO `my_access` VALUES ('1', '104', '3', '');
INSERT INTO `my_access` VALUES ('1', '94', '3', '');
INSERT INTO `my_access` VALUES ('1', '93', '3', '');
INSERT INTO `my_access` VALUES ('1', '92', '3', '');
INSERT INTO `my_access` VALUES ('1', '91', '3', '');
INSERT INTO `my_access` VALUES ('1', '73', '3', '');
INSERT INTO `my_access` VALUES ('1', '72', '3', '');
INSERT INTO `my_access` VALUES ('1', '71', '3', '');
INSERT INTO `my_access` VALUES ('1', '65', '3', '');
INSERT INTO `my_access` VALUES ('1', '64', '3', '');
INSERT INTO `my_access` VALUES ('1', '63', '3', '');
INSERT INTO `my_access` VALUES ('1', '62', '3', '');
INSERT INTO `my_access` VALUES ('1', '61', '3', '');
INSERT INTO `my_access` VALUES ('1', '70', '3', '');
INSERT INTO `my_access` VALUES ('1', '60', '3', '');
INSERT INTO `my_access` VALUES ('1', '59', '3', '');
INSERT INTO `my_access` VALUES ('1', '58', '3', '');
INSERT INTO `my_access` VALUES ('1', '57', '3', '');
INSERT INTO `my_access` VALUES ('1', '4', '2', '');
INSERT INTO `my_access` VALUES ('1', '85', '3', '');
INSERT INTO `my_access` VALUES ('1', '84', '3', '');
INSERT INTO `my_access` VALUES ('1', '83', '3', '');
INSERT INTO `my_access` VALUES ('1', '82', '3', '');
INSERT INTO `my_access` VALUES ('1', '69', '3', '');
INSERT INTO `my_access` VALUES ('1', '68', '3', '');
INSERT INTO `my_access` VALUES ('1', '67', '3', '');
INSERT INTO `my_access` VALUES ('1', '56', '3', '');
INSERT INTO `my_access` VALUES ('1', '55', '3', '');
INSERT INTO `my_access` VALUES ('1', '54', '3', '');
INSERT INTO `my_access` VALUES ('1', '53', '3', '');
INSERT INTO `my_access` VALUES ('1', '52', '3', '');
INSERT INTO `my_access` VALUES ('1', '51', '3', '');
INSERT INTO `my_access` VALUES ('1', '50', '3', '');
INSERT INTO `my_access` VALUES ('1', '49', '3', '');
INSERT INTO `my_access` VALUES ('1', '66', '3', '');
INSERT INTO `my_access` VALUES ('1', '6', '2', '');
INSERT INTO `my_access` VALUES ('1', '27', '3', '');
INSERT INTO `my_access` VALUES ('1', '26', '3', '');
INSERT INTO `my_access` VALUES ('1', '25', '3', '');
INSERT INTO `my_access` VALUES ('1', '24', '3', '');
INSERT INTO `my_access` VALUES ('1', '23', '3', '');
INSERT INTO `my_access` VALUES ('1', '22', '3', '');
INSERT INTO `my_access` VALUES ('1', '21', '3', '');
INSERT INTO `my_access` VALUES ('1', '3', '2', '');
INSERT INTO `my_access` VALUES ('1', '35', '3', '');
INSERT INTO `my_access` VALUES ('1', '34', '3', '');
INSERT INTO `my_access` VALUES ('1', '33', '3', '');
INSERT INTO `my_access` VALUES ('1', '32', '3', '');
INSERT INTO `my_access` VALUES ('1', '20', '3', '');
INSERT INTO `my_access` VALUES ('1', '19', '3', '');
INSERT INTO `my_access` VALUES ('1', '18', '3', '');
INSERT INTO `my_access` VALUES ('1', '17', '3', '');
INSERT INTO `my_access` VALUES ('1', '16', '3', '');
INSERT INTO `my_access` VALUES ('1', '15', '3', '');
INSERT INTO `my_access` VALUES ('1', '14', '3', '');
INSERT INTO `my_access` VALUES ('1', '13', '3', '');
INSERT INTO `my_access` VALUES ('1', '12', '3', '');
INSERT INTO `my_access` VALUES ('1', '11', '3', '');
INSERT INTO `my_access` VALUES ('1', '10', '3', '');
INSERT INTO `my_access` VALUES ('1', '9', '3', '');
INSERT INTO `my_access` VALUES ('1', '2', '2', '');
INSERT INTO `my_access` VALUES ('1', '1', '1', '');
INSERT INTO `my_access` VALUES ('1', '114', '3', '');

-- -----------------------------
-- Table structure for `my_account_log`
-- -----------------------------
DROP TABLE IF EXISTS `my_account_log`;
CREATE TABLE `my_account_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `act` varchar(255) DEFAULT NULL COMMENT '动作',
  `type` int(11) DEFAULT NULL COMMENT '类型 5:推广返利.1,在线充值,4:用户提现,2:订单消费',
  `addtime` datetime DEFAULT NULL,
  `orderno` varchar(45) DEFAULT NULL COMMENT '在线充值订单号',
  `status` int(11) DEFAULT '0' COMMENT '在线充值状态  0:失败,1:成功',
  `paytime` datetime DEFAULT NULL COMMENT '在线充值支付时间',
  `payinfo` longtext COMMENT '在线充值结果信息',
  `payid` int(11) DEFAULT NULL COMMENT '支付者会员id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='账户变动记录';

-- -----------------------------
-- Records of `my_account_log`
-- -----------------------------
INSERT INTO `my_account_log` VALUES ('1', '195', '0.00', '下级消费返利', '5', '2016-11-03 10:03:14', '', '0', '', '', '198');
INSERT INTO `my_account_log` VALUES ('2', '195', '0.00', '下级消费返利', '5', '2016-11-03 10:03:51', '', '0', '', '', '196');
INSERT INTO `my_account_log` VALUES ('3', '195', '0.00', '下级消费返利', '5', '2016-11-03 10:07:44', '', '0', '', '', '196');
INSERT INTO `my_account_log` VALUES ('4', '195', '0.00', '下级消费返利', '5', '2016-11-03 10:14:58', '', '0', '', '', '198');
INSERT INTO `my_account_log` VALUES ('5', '195', '0.04', '下级消费返利', '5', '2016-11-03 10:20:23', '', '0', '', '', '198');
INSERT INTO `my_account_log` VALUES ('6', '195', '0.01', '下级消费返利', '5', '2016-11-03 10:24:32', '', '0', '', '', '198');
INSERT INTO `my_account_log` VALUES ('7', '195', '0.01', '下级消费返利', '5', '2016-11-03 10:27:00', '', '0', '', '', '196');
INSERT INTO `my_account_log` VALUES ('8', '195', '0.06', '下级消费返利', '5', '2016-11-03 10:30:59', '', '0', '', '', '196');
INSERT INTO `my_account_log` VALUES ('9', '0', '0.38', '下级消费返利', '5', '2016-11-04 08:27:19', '', '0', '', '', '195');
INSERT INTO `my_account_log` VALUES ('10', '195', '0.40', '下级消费返利', '5', '2016-11-04 10:44:34', '', '0', '', '', '203');
INSERT INTO `my_account_log` VALUES ('11', '195', '0.05', '下级消费返利', '5', '2016-11-04 10:46:33', '', '0', '', '', '203');
INSERT INTO `my_account_log` VALUES ('12', '0', '0.20', '下级消费返利', '5', '2016-11-11 09:49:58', '', '0', '', '', '202');
INSERT INTO `my_account_log` VALUES ('14', '1', '10.00', '使用消费积分购买商品', '2', '2016-12-08 14:09:46', '', '0', '', '', '1');
INSERT INTO `my_account_log` VALUES ('15', '1', '500.00', '在线充值', '1', '2016-12-08 15:34:32', '1612081534', '1', '2016-12-08 15:34:32', '佣金账户支付', '');
INSERT INTO `my_account_log` VALUES ('16', '1', '500.00', '使用佣金账户充值消费积分', '6', '2016-12-08 15:34:32', '', '0', '', '', '1');

-- -----------------------------
-- Table structure for `my_address`
-- -----------------------------
DROP TABLE IF EXISTS `my_address`;
CREATE TABLE `my_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agentid` int(11) DEFAULT '0' COMMENT '代理商ID',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isdefault` tinyint(3) DEFAULT '0' COMMENT '0-否，1-默认',
  `username` varchar(255) DEFAULT NULL COMMENT '用户填写的真实姓名',
  `telephone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `provinceid` int(11) DEFAULT '0',
  `cityid` int(11) DEFAULT '0',
  `districtid` int(11) DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `memberid` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='收货地址表';

-- -----------------------------
-- Records of `my_address`
-- -----------------------------
INSERT INTO `my_address` VALUES ('57', '0', '2016-09-01 16:40:29', '0', '叶俊', '13456454241', '51', '5101', '510104', '大业路', '129');
INSERT INTO `my_address` VALUES ('58', '0', '2016-09-26 11:28:12', '0', '耳朵', '13812345678', '12', '1202', '120223', '嘟嘟或者', '135');
INSERT INTO `my_address` VALUES ('59', '0', '2016-10-25 10:53:17', '0', '叶俊', '13564649754', '31', '3101', '310106', '还是计算机技术', '137');
INSERT INTO `my_address` VALUES ('60', '0', '2016-10-27 14:48:08', '0', '军', '13333333333', '11', '1101', '110101', '龙岗区', '146');
INSERT INTO `my_address` VALUES ('61', '0', '2016-11-02 17:02:02', '0', 'yejun', '13564645874', '11', '1101', '110102', '详细地址', '145');
INSERT INTO `my_address` VALUES ('62', '0', '2016-11-03 10:02:43', '0', '叶俊', '13586465487', '14', '1405', '140524', '详细地址', '198');
INSERT INTO `my_address` VALUES ('63', '0', '2016-11-03 10:03:29', '0', '周春', '18683438262', '51', '5101', '510104', '大业路', '196');
INSERT INTO `my_address` VALUES ('64', '0', '2016-11-04 08:27:08', '0', '覃建方', '18683438262', '51', '5101', '510101', '大业路', '195');
INSERT INTO `my_address` VALUES ('65', '0', '2016-11-04 10:44:17', '0', '陶俊杰', '13523019166', '51', '5101', '510107', '奥克斯广场', '203');
INSERT INTO `my_address` VALUES ('66', '0', '2016-11-09 09:11:55', '0', '叶俊', '13564697548', '14', '1405', '140525', '测试地质', '225');
INSERT INTO `my_address` VALUES ('67', '0', '2016-11-11 09:49:24', '0', '李亚琼', '18783506496', '51', '5101', '510104', '芷泉街较场坝东67号', '202');
INSERT INTO `my_address` VALUES ('68', '0', '2016-11-29 16:30:46', '0', '周中健', '18982270568', '51', '5101', '510105', '苏坡中路48号', '284');
INSERT INTO `my_address` VALUES ('69', '0', '2016-11-29 16:30:47', '0', '周中健', '18982270568', '51', '5101', '510105', '苏坡中路48号', '284');
INSERT INTO `my_address` VALUES ('70', '0', '2016-11-29 16:30:47', '0', '周中健', '18982270568', '51', '5101', '510105', '苏坡中路48号', '284');
INSERT INTO `my_address` VALUES ('71', '0', '2016-11-29 16:30:47', '0', '周中健', '18982270568', '51', '5101', '510105', '苏坡中路48号', '284');
INSERT INTO `my_address` VALUES ('72', '0', '2016-12-08 13:43:41', '1', 'yejun', '13564646787', '11', '1101', '110103', '详细地址', '1');

-- -----------------------------
-- Table structure for `my_cart`
-- -----------------------------
DROP TABLE IF EXISTS `my_cart`;
CREATE TABLE `my_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) DEFAULT NULL,
  `memberid` varchar(255) DEFAULT NULL COMMENT '保存用户的openid',
  `attr` longtext COMMENT '属性',
  `num` int(11) DEFAULT NULL COMMENT '数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `my_category_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `my_category_coupon`;
CREATE TABLE `my_category_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  `sort` tinyint(3) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `depth` tinyint(3) DEFAULT '0' COMMENT '层级',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `sortpath` varchar(100) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '推荐：0-否，1-是',
  `indexpic` varchar(255) NOT NULL DEFAULT '' COMMENT '形象图',
  `template` varchar(255) DEFAULT NULL COMMENT '模板名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='优惠券分类表';

-- -----------------------------
-- Records of `my_category_coupon`
-- -----------------------------
INSERT INTO `my_category_coupon` VALUES ('1', '2016-01-26 11:34:05', '1', '1', '5元券', '', '1', '0', '0,1,', '0', '', '');
INSERT INTO `my_category_coupon` VALUES ('2', '2016-01-26 11:34:05', '1', '2', '10元券', '', '1', '0', '0,2,', '0', '', '');

-- -----------------------------
-- Table structure for `my_category_info`
-- -----------------------------
DROP TABLE IF EXISTS `my_category_info`;
CREATE TABLE `my_category_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  `sort` tinyint(3) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `depth` tinyint(3) DEFAULT '0' COMMENT '层级',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `sortpath` varchar(100) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '推荐：0-否，1-是',
  `indexpic` varchar(255) NOT NULL DEFAULT '' COMMENT '形象图',
  `template` varchar(255) DEFAULT NULL COMMENT '模板名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='单页分类表';

-- -----------------------------
-- Records of `my_category_info`
-- -----------------------------
INSERT INTO `my_category_info` VALUES ('1', '2016-11-03 16:32:24', '1', '1', '关于我们', '', '1', '0', '0,1,', '0', '', '');
INSERT INTO `my_category_info` VALUES ('4', '2016-12-08 16:58:02', '1', '4', '积分规则', '', '1', '0', '0,4,', '0', '', '');

-- -----------------------------
-- Table structure for `my_category_label`
-- -----------------------------
DROP TABLE IF EXISTS `my_category_label`;
CREATE TABLE `my_category_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  `sort` tinyint(3) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `remark` text COMMENT '备注',
  `depth` tinyint(3) DEFAULT '0' COMMENT '层级',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `sortpath` varchar(100) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '推荐：0-否，1-是',
  `indexpic` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='标签分类表';

-- -----------------------------
-- Records of `my_category_label`
-- -----------------------------
INSERT INTO `my_category_label` VALUES ('1', '2015-07-21 22:16:30', '1', '1', '基础信息', '', '1', '0', '0,1,', '0', '');
INSERT INTO `my_category_label` VALUES ('2', '2015-07-21 22:16:30', '1', '2', '广告幻灯', '', '1', '0', '0,2,', '0', '');

-- -----------------------------
-- Table structure for `my_category_member`
-- -----------------------------
DROP TABLE IF EXISTS `my_category_member`;
CREATE TABLE `my_category_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  `sort` tinyint(3) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `depth` tinyint(3) DEFAULT '0' COMMENT '层级',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `sortpath` varchar(100) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '推荐：0-否，1-是',
  `indexpic` varchar(255) NOT NULL DEFAULT '' COMMENT '形象图',
  `template` varchar(255) DEFAULT NULL COMMENT '模板名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员分类表';

-- -----------------------------
-- Records of `my_category_member`
-- -----------------------------
INSERT INTO `my_category_member` VALUES ('1', '2016-01-23 11:18:30', '1', '1', '普通会员', '', '1', '0', '0,1,', '0', '', '');
INSERT INTO `my_category_member` VALUES ('2', '2016-01-25 17:12:37', '1', '2', '推广会员', '', '1', '0', '0,2,', '0', '', '');

-- -----------------------------
-- Table structure for `my_category_news`
-- -----------------------------
DROP TABLE IF EXISTS `my_category_news`;
CREATE TABLE `my_category_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  `sort` tinyint(3) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `depth` tinyint(3) DEFAULT '0' COMMENT '层级',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `sortpath` varchar(100) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '推荐：0-否，1-是',
  `indexpic` varchar(255) NOT NULL DEFAULT '' COMMENT '形象图',
  `template` varchar(255) DEFAULT NULL COMMENT '模板名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='资讯分类表';

-- -----------------------------
-- Records of `my_category_news`
-- -----------------------------
INSERT INTO `my_category_news` VALUES ('1', '2016-01-07 16:07:20', '1', '1', '分类1', '', '1', '0', '0,1,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('2', '2016-01-07 15:54:47', '1', '2', '分类2', '', '1', '0', '0,2,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('3', '2016-01-07 15:54:47', '1', '3', '分类3', '', '1', '0', '0,3,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('4', '2016-01-07 15:54:47', '1', '4', '分类4', '', '1', '0', '0,4,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('5', '2016-01-07 15:54:47', '1', '5', '分类5', '', '1', '0', '0,5,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('6', '2016-01-07 15:54:47', '1', '6', '分类6', '', '1', '0', '0,6,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('7', '2016-01-07 15:54:47', '1', '7', '分类7', '', '1', '0', '0,7,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('8', '2016-01-07 15:59:54', '1', '8', '分类1.1', '', '2', '1', '0,1,8,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('9', '2016-01-07 15:59:54', '1', '9', '分类1.2', '', '2', '1', '0,1,9,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('10', '2016-01-07 15:59:54', '1', '10', '分类1.3', '', '2', '1', '0,1,10,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('11', '2016-01-07 15:59:54', '1', '11', '分类1.4', '', '2', '1', '0,1,11,', '0', '', '');
INSERT INTO `my_category_news` VALUES ('12', '2016-01-07 15:59:54', '1', '12', '分类1.5', '', '2', '1', '0,1,12,', '0', '', '');

-- -----------------------------
-- Table structure for `my_category_product`
-- -----------------------------
DROP TABLE IF EXISTS `my_category_product`;
CREATE TABLE `my_category_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  `sort` tinyint(3) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `depth` tinyint(3) DEFAULT '0' COMMENT '层级',
  `pid` int(11) DEFAULT '0' COMMENT '父ID',
  `sortpath` varchar(100) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '推荐：0-否，1-是',
  `indexpic` varchar(255) NOT NULL DEFAULT '' COMMENT '形象图',
  `template` varchar(255) DEFAULT NULL COMMENT '模板名',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='产品分类表';

-- -----------------------------
-- Records of `my_category_product`
-- -----------------------------
INSERT INTO `my_category_product` VALUES ('1', '2016-12-08 10:59:49', '1', '1', '茅台上酱（酱香型）', '', '1', '0', '0,1,', '0', '', '');
INSERT INTO `my_category_product` VALUES ('2', '2016-12-08 10:59:49', '1', '2', '茅台上酱（浓香型）', '', '1', '0', '0,2,', '0', '', '');
INSERT INTO `my_category_product` VALUES ('3', '2016-12-08 10:59:49', '1', '3', '茅台上酱（个人定制）', '', '1', '0', '0,3,', '0', '', '');

-- -----------------------------
-- Table structure for `my_config`
-- -----------------------------
DROP TABLE IF EXISTS `my_config`;
CREATE TABLE `my_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='配置项';

-- -----------------------------
-- Records of `my_config`
-- -----------------------------
INSERT INTO `my_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1', '龙翔国际', '1');
INSERT INTO `my_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1', '龙翔国际', '2');
INSERT INTO `my_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1', '龙翔国际', '3');
INSERT INTO `my_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1', '1', '4');
INSERT INTO `my_config` VALUES ('5', 'WEB_SITE_ICP', '1', '备案信息', '1', '', '备案信息', '1', '蜀ICP备1000000号', '5');
INSERT INTO `my_config` VALUES ('6', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '2', '', '路径必须以 / 结尾', '1', './Public/data/', '6');
INSERT INTO `my_config` VALUES ('7', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '2', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1', '20971520', '7');
INSERT INTO `my_config` VALUES ('8', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '2', '0:不压缩
1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1', '1', '8');
INSERT INTO `my_config` VALUES ('9', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '2', '1:普通
4:一般
9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1', '9', '9');
INSERT INTO `my_config` VALUES ('10', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '不受限控制器方法', '1', '5', '10');
INSERT INTO `my_config` VALUES ('11', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '44', '仅超级管理员可访问的控制器方法', '1', '6', '11');
INSERT INTO `my_config` VALUES ('12', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '0', '', '主要用于数据解析和页面表单的生成', '1', '0:数字
1:字符
2:文本
3:数组
4:枚举
5:分割', '12');
INSERT INTO `my_config` VALUES ('13', 'CONFIG_GROUP_LIST', '3', '配置分组', '0', '1:基本
2:系统
3:接口
4:返利', '配置分组', '1', '1:基本
2:系统
3:接口
4:返利', '13');
INSERT INTO `my_config` VALUES ('14', 'CONFIG_STATUS_LIST', '3', '订单状态', '0', '0:订单提交
1:系统确认
2:已发货
3:已完成
4:已取消', '状态分组', '1', '0:订单提交
1:系统确认
2:已发货
3:已完成
4:已取消', '14');
INSERT INTO `my_config` VALUES ('15', 'CONFIG_PAYMETHOD_LIST', '3', '支付方式配置', '0', '1:微信支付
4:货到付款', '支付方式配置', '1', '1:微信支付
4:货到付款', '15');
INSERT INTO `my_config` VALUES ('16', 'CONFIG_BOOKTIME_LIST', '3', '可预定时段分组', '0', '', '可预定时段分组', '1', '', '16');
INSERT INTO `my_config` VALUES ('17', 'POINT_RATE', '0', '积分比例', '4', '', '如1，表示：消费1元积1分', '1', '100', '17');
INSERT INTO `my_config` VALUES ('19', 'WEB_SITE_COPYRIGHT', '1', '版权信息', '1', '', '版权信息', '1', '龙翔国际 2016', '19');
INSERT INTO `my_config` VALUES ('20', 'WEB_SITE_TEMPLATE', '4', '模板设置', '1', 'default:默认', '选择前台显示模板', '1', 'default', '4');
INSERT INTO `my_config` VALUES ('21', 'SMTP_SERVER', '1', 'STMP服务器', '3', '', '发送邮件的SMTP服务器地址', '1', 'smtp.163.com', '21');
INSERT INTO `my_config` VALUES ('22', 'SMTP_PORT', '0', 'SMTP端口', '3', '', 'SMTP服务器的端口', '1', '25', '22');
INSERT INTO `my_config` VALUES ('23', 'SMTP_EMAIL', '1', '发件人名称', '3', '', '一般是email地址或公司名称', '1', '', '23');
INSERT INTO `my_config` VALUES ('24', 'SMTP_USERNAME', '1', '邮箱账号', '3', '', '同上', '1', '', '24');
INSERT INTO `my_config` VALUES ('25', 'SMTP_USERPWD', '1', '邮箱密码', '3', '', '发件箱密码', '1', '', '25');
INSERT INTO `my_config` VALUES ('26', 'SMTP_LINE', '5', '邮件接口设置', '3', '', '短信接口设置', '1', '', '20');
INSERT INTO `my_config` VALUES ('27', 'SMS_LINE', '5', '短信接口设置', '3', '', '短信接口设置', '1', '', '27');
INSERT INTO `my_config` VALUES ('28', 'SMS_API_URL', '1', '短信接口API', '3', '', '短信接口网关地址', '1', '', '28');
INSERT INTO `my_config` VALUES ('29', 'SMS_USERNAME', '1', '用户名', '3', '', '短信接口用户名', '1', '', '29');
INSERT INTO `my_config` VALUES ('30', 'SMS_USERPWD', '1', '密码', '3', '', '短信接口密码', '1', '', '30');
INSERT INTO `my_config` VALUES ('31', 'WEB_SITE_EMAIL', '4', '邮件系统', '2', '0:禁用
1:启用', '启用后才能发送邮件，需要配置邮件接口', '0', '1', '36');
INSERT INTO `my_config` VALUES ('32', 'WEB_SITE_SMS', '4', '短信系统', '2', '0:禁用
1:启用', '启用后才能发送手机短信，需要配置短信接口', '0', '0', '37');
INSERT INTO `my_config` VALUES ('33', 'WEB_SITE_WECHAT', '4', '微信接口', '2', '0:禁用
1:启用', '启用后才能接管微信平台，需要配置微信接口', '0', '1', '38');
INSERT INTO `my_config` VALUES ('37', 'VOTE_DAY', '0', '投票总数', '2', '', '一个用户每天投票总数', '0', '3', '37');
INSERT INTO `my_config` VALUES ('38', 'VOTE_PLAYER', '0', '对选手投票总数', '2', '', '用户每天对同一个选手的投票总数', '0', '1', '38');
INSERT INTO `my_config` VALUES ('39', 'ALIPAY', '4', '启用支付宝支付', '2', '0:禁用
1:启用', '1：启用，0：禁用【支付宝支付需要在程序中设置账号密码】', '1', '0', '39');
INSERT INTO `my_config` VALUES ('40', 'ACCOUNTPAY', '4', '启用消费积分支付', '2', '0:禁用
1:启用', '0：禁用，1：启用', '1', '1', '40');
INSERT INTO `my_config` VALUES ('44', 'FIRST_FIRST_REFEE', '0', '首次购买上一级返利', '4', '', '首次购买上一级返利', '1', '100', '44');
INSERT INTO `my_config` VALUES ('45', 'FIRST_SECOND_REFEE', '0', '首次购买向上第二级返利', '4', '', '首次购买向上第二级返利', '1', '50', '45');
INSERT INTO `my_config` VALUES ('46', 'FIRST_THIRD_REFEE', '0', '首次购买向上第三级返利', '4', '', '首次购买向上第三级返利', '1', '30', '46');
INSERT INTO `my_config` VALUES ('47', 'OTHER_FIRST_REFEE', '0', '非首次购买向上一级返利', '4', '', '非首次购买向上一级返利', '1', '80', '47');
INSERT INTO `my_config` VALUES ('48', 'OTHER_SECOND_REFEE', '0', '非首次购买向上第二级返利', '4', '', '非首次购买向上第二级返利', '1', '40', '48');
INSERT INTO `my_config` VALUES ('49', 'OTHER_THIRD_REFEE', '0', '非首次购买向上第三级返利', '4', '', '非首次购买向上第三级返利', '1', '20', '49');

-- -----------------------------
-- Table structure for `my_content_active`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_active`;
CREATE TABLE `my_content_active` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(250) DEFAULT '',
  `indexpic` varchar(250) DEFAULT NULL,
  `keywords` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  `content` longtext,
  `source` varchar(250) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL COMMENT '0',
  `linkurl` varchar(250) DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(50) DEFAULT NULL,
  `sort` int(11) DEFAULT '0' COMMENT '0',
  `status` tinyint(4) DEFAULT NULL COMMENT '1',
  `isresume` tinyint(3) DEFAULT '0',
  `sortpath` varchar(250) DEFAULT NULL,
  `images` varchar(1024) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `start` datetime DEFAULT NULL COMMENT '开始时间',
  `end` datetime DEFAULT NULL COMMENT '结束时间',
  `explain` longtext COMMENT '规则说明',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='投票活动';

-- -----------------------------
-- Records of `my_content_active`
-- -----------------------------
INSERT INTO `my_content_active` VALUES ('1', '', '活动1', '/Public/uploadfile/file/2016-08-10/57aaf030c5c10.jpg', '活动1', '这是活动规则。。。。。', '<p>这是活动规则。。。。。</p>', '', '', '0', '', '2016-08-10 17:16:46', '', '1', '1', '0', '', '[\"\"]', '', '2016-08-09 00:00:00', '2016-08-16 00:00:00', '<p>这是活动说明。。。。。</p>');
INSERT INTO `my_content_active` VALUES ('2', '', '活动2', '/Public/uploadfile/file/2016-08-10/57aaf030c5c10.jpg', '活动1', '这是活动规则。。。。。', '<p>这是活动规则。。。。。</p>', '', '', '0', '', '2016-08-10 17:16:46', '', '1', '1', '0', '', '[\"\"]', '', '2016-08-09 00:00:00', '2016-08-16 00:00:00', '<p>这是活动说明。。。。。</p>');
INSERT INTO `my_content_active` VALUES ('3', '', '活动2', '/Public/uploadfile/file/2016-08-10/57aaf030c5c10.jpg', '活动1', '这是活动规则。。。。。', '<p>这是活动规则。。。。。</p>', '', '', '0', '', '2016-08-10 17:16:46', '', '1', '1', '0', '', '[\"\"]', '', '2016-08-09 00:00:00', '2016-08-16 00:00:00', '<p>这是活动说明。。。。。</p>');
INSERT INTO `my_content_active` VALUES ('4', '', '活动3', '/Public/uploadfile/file/2016-08-10/57aaf030c5c10.jpg', '活动1', '这是活动规则。。。。。', '<p>这是活动规则。。。。。</p>', '', '', '0', '', '2016-08-10 17:16:46', '', '1', '1', '0', '', '[\"\"]', '', '2016-08-09 00:00:00', '2016-08-16 00:00:00', '<p>这是活动说明。。。。。</p>');

-- -----------------------------
-- Table structure for `my_content_active_member`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_active_member`;
CREATE TABLE `my_content_active_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activeid` int(11) NOT NULL DEFAULT '0' COMMENT '参加的活动id',
  `no` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `headimg` varchar(255) DEFAULT NULL COMMENT '头像',
  `photo` longtext COMMENT '照片',
  `tickets` int(11) NOT NULL DEFAULT '0' COMMENT '票数',
  `content` longtext COMMENT '详细介绍',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态，0:待审核，1：已通过，2：不通过',
  `qq` varchar(255) DEFAULT NULL COMMENT 'qq',
  `mobile` varchar(255) DEFAULT NULL COMMENT '手机',
  `fav` varchar(255) DEFAULT NULL COMMENT '爱好',
  `memberid` int(11) DEFAULT NULL COMMENT '选手id',
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='活动参加人员表';

-- -----------------------------
-- Records of `my_content_active_member`
-- -----------------------------
INSERT INTO `my_content_active_member` VALUES ('4', '2', '1', '悟空', '/Public/uploadfile/file/2016-08-11/57ac28fc1aa90.jpg', '/Public/uploadfile/file/2016-08-11/57ac28fc1aa90.jpg,/Public/uploadfile/file/2016-08-11/57ac1ba66f090.jpg,/Public/uploadfile/file/2016-08-10/57aad7d121980.jpg', '3', '这是个人介绍', '1', '54687984', '13548745784', '看电影，打球', '3', '2016-08-11 15:27:58');
INSERT INTO `my_content_active_member` VALUES ('5', '3', '1', '八戒', '/Public/uploadfile/file/2016-08-11/57ac1ba215310.jpg', '/Public/uploadfile/file/2016-08-11/57ac1ba215310.jpg,/Public/uploadfile/file/2016-08-04/57a298ec15508.jpg,/Public/uploadfile/file/2016-08-10/57aad7d121980.jpg', '3', '发送快放假了三大', '1', '135664646', '13564646464', '坎坎坷坷', '3', '2016-08-11 15:28:35');
INSERT INTO `my_content_active_member` VALUES ('6', '4', '1', '沙僧', '/Public/uploadfile/file/2016-08-11/57ac298d2a620.jpg', '/Public/uploadfile/file/2016-08-11/57ac298d2a620.jpg', '1', '范德萨范德萨发生大干', '1', '54644646', '13548787878', '的萨芬撒', '3', '2016-08-11 15:30:21');
INSERT INTO `my_content_active_member` VALUES ('7', '1', '2', '覃建方3', '/Public/uploadfile/file/2016-08-11/57ac2d3386920.jpg', '/Public/uploadfile/file/2016-08-11/57ac2d3386920.jpg,/Public/uploadfile/file/2016-08-11/57ac2d27d76e0.jpeg', '10', '一个好人', '1', '228551650', '18683438262', '各种', '19', '2016-08-11 15:46:03');
INSERT INTO `my_content_active_member` VALUES ('8', '1', '3', '肖', '/Public/uploadfile/file/2016-08-12/57ad668a76a70.jpg', '/Public/uploadfile/file/2016-08-12/57ad668a76a70.jpg', '8', '不知', '1', '421876', '15198233645', '不止', '21', '2016-08-12 14:02:52');
INSERT INTO `my_content_active_member` VALUES ('9', '1', '4', '的', '/Public/uploadfile/file/2016-08-12/57ad6891e8080.jpg', '/Public/uploadfile/file/2016-08-12/57ad6891e8080.jpg', '1', '哈哈', '1', '13391513337', '13391513337', '活生生', '11', '2016-08-12 14:11:31');
INSERT INTO `my_content_active_member` VALUES ('10', '1', '5', 'yejun ', '/Public/uploadfile/file/2016-08-11/57ac092553ca0.jpg', '/Public/uploadfile/file/2016-08-11/57ac092553ca0.jpg,/Public/uploadfile/file/2016-08-18/57b519e7124f8.jpg', '1', '个人介绍', '1', '546545465', '13564646464', '看电影', '76', '2016-08-18 10:14:15');
INSERT INTO `my_content_active_member` VALUES ('11', '3', '2', '111', '/Public/uploadfile/file/2016-08-18/57b5602469208.jpg', '/Public/uploadfile/file/2016-08-18/57b5602469208.jpg', '0', '222222', '0', '111', '13447215555', '1111', '89', '2016-08-18 15:13:57');
INSERT INTO `my_content_active_member` VALUES ('12', '4', '2', '华丽丽', '/Public/uploadfile/file/2016-08-18/57b56094a8048.jpg', '/Public/uploadfile/file/2016-08-18/57b56094a8048.jpg', '0', '好了里了哦哦你路他路路路了路路路了', '0', '1234568', '15424523366', '估计', '89', '2016-08-18 15:15:34');
INSERT INTO `my_content_active_member` VALUES ('13', '1', '6', 'CD呵呵', '/Public/uploadfile/file/2016-08-18/57b5625485ef8.jpg', '/Public/uploadfile/file/2016-08-18/57b5625485ef8.jpg', '0', '福化学符号', '0', '84645694', '13194799870', '分分合合在', '81', '2016-08-18 15:23:14');
INSERT INTO `my_content_active_member` VALUES ('14', '2', '2', '唐生', '/Public/uploadfile/file/2016-08-18/57b56dcf0a668.jpg', '/Public/uploadfile/file/2016-08-18/57b56dcf0a668.jpg', '0', '你懂的', '0', '543488318', '15198888888', '不知道', '81', '2016-08-18 16:12:46');
INSERT INTO `my_content_active_member` VALUES ('15', '1', '7', '北京', '/Public/uploadfile/file/2016-08-18/57b573337a9b8.jpg', '/Public/uploadfile/file/2016-08-18/57b573337a9b8.jpg', '0', '看看', '0', '5555333', '13333665445', '急急急', '85', '2016-08-18 16:35:39');

-- -----------------------------
-- Table structure for `my_content_active_vote`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_active_vote`;
CREATE TABLE `my_content_active_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `playerid` int(11) DEFAULT NULL COMMENT '选手id',
  `voteid` int(11) DEFAULT NULL COMMENT '投票id',
  `times` int(11) NOT NULL DEFAULT '0' COMMENT '投票次数',
  `votetime` date DEFAULT NULL COMMENT '投票时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='投票备注表';

-- -----------------------------
-- Records of `my_content_active_vote`
-- -----------------------------
INSERT INTO `my_content_active_vote` VALUES ('7', '6', '3', '1', '2016-08-11');
INSERT INTO `my_content_active_vote` VALUES ('8', '5', '3', '1', '2016-08-11');
INSERT INTO `my_content_active_vote` VALUES ('9', '4', '3', '1', '2016-08-11');
INSERT INTO `my_content_active_vote` VALUES ('10', '7', '19', '1', '2016-08-11');
INSERT INTO `my_content_active_vote` VALUES ('11', '7', '21', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('12', '3', '21', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('13', '8', '21', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('14', '3', '20', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('15', '7', '20', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('16', '8', '20', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('17', '7', '25', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('18', '8', '25', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('19', '3', '25', '1', '2016-08-12');
INSERT INTO `my_content_active_vote` VALUES ('20', '8', '21', '1', '2016-08-13');
INSERT INTO `my_content_active_vote` VALUES ('21', '5', '20', '1', '2016-08-13');
INSERT INTO `my_content_active_vote` VALUES ('22', '4', '20', '1', '2016-08-13');
INSERT INTO `my_content_active_vote` VALUES ('23', '7', '20', '1', '2016-08-13');
INSERT INTO `my_content_active_vote` VALUES ('24', '3', '3', '1', '2016-08-15');
INSERT INTO `my_content_active_vote` VALUES ('25', '7', '3', '1', '2016-08-15');
INSERT INTO `my_content_active_vote` VALUES ('26', '8', '3', '1', '2016-08-15');
INSERT INTO `my_content_active_vote` VALUES ('27', '3', '20', '1', '2016-08-16');
INSERT INTO `my_content_active_vote` VALUES ('28', '4', '20', '1', '2016-08-16');
INSERT INTO `my_content_active_vote` VALUES ('29', '8', '63', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('30', '7', '63', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('31', '3', '63', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('32', '8', '64', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('33', '7', '64', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('34', '7', '62', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('35', '3', '64', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('36', '3', '62', '1', '2016-08-17');
INSERT INTO `my_content_active_vote` VALUES ('37', '10', '76', '1', '2016-08-18');
INSERT INTO `my_content_active_vote` VALUES ('38', '5', '89', '1', '2016-08-18');
INSERT INTO `my_content_active_vote` VALUES ('39', '8', '81', '1', '2016-08-18');
INSERT INTO `my_content_active_vote` VALUES ('40', '7', '81', '1', '2016-08-18');
INSERT INTO `my_content_active_vote` VALUES ('41', '9', '81', '1', '2016-08-18');

-- -----------------------------
-- Table structure for `my_content_express`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_express`;
CREATE TABLE `my_content_express` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `title` varchar(255) DEFAULT NULL COMMENT '公司名称',
  `indexpic` varchar(250) DEFAULT NULL COMMENT '形象图',
  `telephone` varchar(255) DEFAULT NULL COMMENT '联系电话',
  `siteurl` varchar(255) DEFAULT NULL COMMENT '查询网址',
  `content` varchar(255) DEFAULT '' COMMENT '公司备注',
  `sort` int(11) DEFAULT NULL COMMENT '0',
  `status` tinyint(3) DEFAULT NULL COMMENT '状态：0-待审核，1-已审核，2-审核未通过',
  `isresume` tinyint(3) DEFAULT '0',
  `description` varchar(500) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='物流快递表';

-- -----------------------------
-- Records of `my_content_express`
-- -----------------------------
INSERT INTO `my_content_express` VALUES ('1', '2015-07-26 09:14:18', '中通', '', '13511112222', 'http://m.kuaidi100.com/index_all.html?type=中通&postid=POSTID', '', '1', '1', '0', '');
INSERT INTO `my_content_express` VALUES ('2', '2015-07-26 09:24:46', '顺风', '', '4000111111', 'http://m.kuaidi100.com/index_all.html?type=顺风&postid=POSTID', '', '2', '1', '0', '');
INSERT INTO `my_content_express` VALUES ('3', '2015-08-10 13:29:52', '韵达', '', '13512341234', 'www.yundaex.com', '', '3', '1', '0', '');
INSERT INTO `my_content_express` VALUES ('4', '2016-08-15 16:17:04', '韵达快递', '', '15196636494', 'www.yundaex.com', '', '4', '1', '0', '');
INSERT INTO `my_content_express` VALUES ('5', '2016-11-11 10:20:21', 'EMS', '', '', 'http://www.kuaidi100.com/all/ems.shtml?from=openv', '', '5', '1', '0', '');

-- -----------------------------
-- Table structure for `my_content_info`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_info`;
CREATE TABLE `my_content_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(250) DEFAULT '',
  `pid` tinyint(4) NOT NULL DEFAULT '0',
  `indexpic` varchar(250) DEFAULT NULL,
  `keywords` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  `content` longtext,
  `source` varchar(250) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL COMMENT '0',
  `linkurl` varchar(250) DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(50) DEFAULT NULL,
  `sort` int(11) DEFAULT '0' COMMENT '0',
  `status` tinyint(4) DEFAULT NULL COMMENT '1',
  `isresume` tinyint(3) DEFAULT '0',
  `sortpath` varchar(250) DEFAULT NULL,
  `images` varchar(1024) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `star1` int(11) DEFAULT '0' COMMENT '体验指数',
  `star2` int(11) DEFAULT '0' COMMENT '刺激指数',
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='单页信息表';

-- -----------------------------
-- Records of `my_content_info`
-- -----------------------------
INSERT INTO `my_content_info` VALUES ('1', '', '公司介绍', '1', '', '公司介绍', '公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍...', '<p>公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍公司介绍</p>', '', '', '2', '', '2016-12-08 16:56:22', '', '1', '1', '0', '0,1,', '[\"\"]', '关于我们', '0', '0');
INSERT INTO `my_content_info` VALUES ('2', '', '企业文化', '1', '', '企业文化', '企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化', '<p>企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化企业文化</p>', '', '', '1', '', '2016-12-08 16:56:33', '', '2', '1', '0', '0,1,', '[\"\"]', '关于我们', '0', '0');
INSERT INTO `my_content_info` VALUES ('3', '', '积分规则', '4', '', '积分规则', '积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则', '<p>积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则积分规则</p>', '', '', '1', '', '2016-12-08 16:58:22', '', '3', '1', '0', '0,4,', '[\"\"]', '积分规则', '0', '0');

-- -----------------------------
-- Table structure for `my_content_news`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_news`;
CREATE TABLE `my_content_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `pid` tinyint(4) NOT NULL DEFAULT '0',
  `indexpic` varchar(250) DEFAULT NULL,
  `keywords` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `content` longtext,
  `source` varchar(250) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL COMMENT '0',
  `linkurl` varchar(250) DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(50) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL COMMENT '0',
  `status` tinyint(4) DEFAULT NULL COMMENT '1',
  `isresume` tinyint(3) DEFAULT '0',
  `sortpath` varchar(250) DEFAULT NULL,
  `images` varchar(1024) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='基础内容表';

-- -----------------------------
-- Records of `my_content_news`
-- -----------------------------
INSERT INTO `my_content_news` VALUES ('1', '', 'test', '8', '', 'test1', 'test2', '<p>test<br/></p>', '4', '5', '6', '3', '2016-01-07 16:42:57', '', '1', '1', '1', '0,1,8,', '[\"1\",\"2\"]', '分类1.1');

-- -----------------------------
-- Table structure for `my_content_product`
-- -----------------------------
DROP TABLE IF EXISTS `my_content_product`;
CREATE TABLE `my_content_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `pid` tinyint(4) NOT NULL DEFAULT '0',
  `indexpic` varchar(250) DEFAULT NULL,
  `keywords` varchar(250) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `content` longtext,
  `source` varchar(250) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL COMMENT '0',
  `linkurl` varchar(250) DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(50) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL COMMENT '0',
  `status` tinyint(4) DEFAULT NULL COMMENT '1',
  `isresume` tinyint(3) DEFAULT '0',
  `sortpath` varchar(250) DEFAULT NULL,
  `images` varchar(1024) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '价格',
  `price1` decimal(10,2) DEFAULT '0.00' COMMENT '市场价',
  `stock` int(11) DEFAULT '0' COMMENT '库存',
  `sold` int(11) DEFAULT '0' COMMENT '销量',
  `unit` varchar(250) DEFAULT NULL COMMENT '单位',
  `code` varchar(255) NOT NULL DEFAULT '' COMMENT '产品编号',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `type` varchar(255) NOT NULL DEFAULT '1' COMMENT '1:商品；2：积分商品',
  `attr` longtext,
  `point` int(11) DEFAULT NULL,
  `first_refee` decimal(10,2) DEFAULT '0.00' COMMENT '第一级返利',
  `second_refee` decimal(10,2) DEFAULT '0.00' COMMENT '第二级返利',
  `third_refee` decimal(10,2) DEFAULT '0.00' COMMENT '第三级返利',
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='产品表';

-- -----------------------------
-- Records of `my_content_product`
-- -----------------------------
INSERT INTO `my_content_product` VALUES ('10', '', '个人定制2', '3', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '2', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,3,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（个人定制）', '0.01', '1000.00', '99', '1', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('3', '', '国宾', '1', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '4', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,1,', '[\"\"]', '茅台上酱（酱香型）', '10.00', '1000.00', '99', '1', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('4', '', '国藏', '1', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '0', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,1,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（酱香型）', '0.01', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('8', '', '个人定制4', '3', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '0', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,3,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（个人定制）', '0.01', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('9', '', '个人定制3', '3', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '0', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,3,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（个人定制）', '0.01', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('11', '', '个人定制1', '3', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '0', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,3,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（个人定制）', '0.01', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('12', '', '鉴赏级浓香', '2', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '1', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,2,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（浓香型）', '0.01', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('13', '', '国粹', '1', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '0', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,1,', '[\"\"]', '茅台上酱（酱香型）', '100.00', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');
INSERT INTO `my_content_product` VALUES ('14', '', '经典浓香', '2', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '国宾', '国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾', '<p>国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾国宾</p>', '', '', '0', '', '2016-12-08 11:27:32', '', '1', '1', '1', '0,2,', '[\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\",\"\\/Public\\/uploadfile\\/file\\/2016-12-08\\/5848d2d68c29c.jpg\"]', '茅台上酱（浓香型）', '0.01', '1000.00', '100', '0', '', '', '0', '1', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '', '0.00', '0.00', '0.00');

-- -----------------------------
-- Table structure for `my_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `my_coupon`;
CREATE TABLE `my_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` int(11) DEFAULT '0' COMMENT '会员ID',
  `no` varchar(255) DEFAULT NULL COMMENT '优惠券号',
  `title` varchar(255) DEFAULT NULL COMMENT '优惠券名称',
  `cost` decimal(10,2) DEFAULT '0.00' COMMENT '消费金额',
  `amount` decimal(10,2) DEFAULT '0.00' COMMENT '优惠金额',
  `pid` int(11) DEFAULT '0' COMMENT '优惠券类型',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '0' COMMENT '消费：0-未消费，1-已消费',
  `usetime` timestamp NULL DEFAULT NULL COMMENT '消费时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '消费备注（订单号）',
  `timefrom` timestamp NULL DEFAULT NULL COMMENT '开始日期',
  `timeto` timestamp NULL DEFAULT NULL COMMENT '结束日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='优惠券表';


-- -----------------------------
-- Table structure for `my_file`
-- -----------------------------
DROP TABLE IF EXISTS `my_file`;
CREATE TABLE `my_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  `fullpath` varchar(255) DEFAULT '' COMMENT '全路径',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=177 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='微信-上传记录表*';

-- -----------------------------
-- Records of `my_file`
-- -----------------------------
INSERT INTO `my_file` VALUES ('50', 'banner.jpg', '5810153e7be50.jpg', '2016-10-26/', 'jpg', 'image/jpeg', '70527', 'fbe4045124356ae4c07f621af308d0fe', '9ab279d04b8d23b6516f319a889d4fa97f6a3c3f', '0', '1477449022', '/Public/uploadfile/file/2016-10-26/5810153e7be50.jpg');
INSERT INTO `my_file` VALUES ('52', 'B10A0029（1）.jpg', '581af9f79a78d.jpg', '2016-11-03/', 'jpg', 'image/jpeg', '1445247', '47690825f148698d2517d7b2f57ac9f5', '92b43252a689e1387b6a892d27055a9d851dadc4', '0', '1478162935', '/Public/uploadfile/file/2016-11-03/581af9f79a78d.jpg');
INSERT INTO `my_file` VALUES ('53', 'B10A0030（1）.jpg', '581afb2931c91.jpg', '2016-11-03/', 'jpg', 'image/jpeg', '1487004', '341c9ea93e0d3907626de16a06f5f9cd', '079da03fbc5243526cc62e01e3f9cd981a82c6aa', '0', '1478163241', '/Public/uploadfile/file/2016-11-03/581afb2931c91.jpg');
INSERT INTO `my_file` VALUES ('54', 'B10A0058（1）.jpg', '581afc81e391c.jpg', '2016-11-03/', 'jpg', 'image/jpeg', '1757170', 'adcf66622fb9c5780474bc68492188bf', '24c93a247078a99309feed24e11ae1af91d97ab7', '0', '1478163585', '/Public/uploadfile/file/2016-11-03/581afc81e391c.jpg');
INSERT INTO `my_file` VALUES ('55', 'B10A0023（1）.jpg', '581afdc3179f6.jpg', '2016-11-03/', 'jpg', 'image/jpeg', '2030687', 'ca9f31da85592a6c6a162042bf12da95', '144b888352c35016653399e57cb71def78fc403a', '0', '1478163907', '/Public/uploadfile/file/2016-11-03/581afdc3179f6.jpg');
INSERT INTO `my_file` VALUES ('56', 'B10A0014（1）.jpg', '581be15bee954.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1536111', '9bcef18c8469a7dc1e31427b58548468', 'f53a8e0d368ed83dde9bd828d5869379e68fe210', '0', '1478222171', '/Public/uploadfile/file/2016-11-04/581be15bee954.jpg');
INSERT INTO `my_file` VALUES ('57', 'B10A0018（1）.jpg', '581be25225d86.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1329849', '06be9bbf5763021f545ad84736d5f4b6', '90222704cb2b5c7a85c23395e279b5171b3f5999', '0', '1478222418', '/Public/uploadfile/file/2016-11-04/581be25225d86.jpg');
INSERT INTO `my_file` VALUES ('58', 'B10A0015（1）.jpg', '581be2a3b87d3.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1340949', 'bb6afeeada13a70e283fd83f5402f1a7', 'dd09dce177772bc1a16be018ace5d4980a3c106e', '0', '1478222499', '/Public/uploadfile/file/2016-11-04/581be2a3b87d3.jpg');
INSERT INTO `my_file` VALUES ('59', 'B10A0005(1).jpg', '581be2dbd00be.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1362977', '2ae0e8304179ab0fded792d621e3c420', 'd571f18ccfff68193933c1e7fbe8e08ea58a7af2', '0', '1478222555', '/Public/uploadfile/file/2016-11-04/581be2dbd00be.jpg');
INSERT INTO `my_file` VALUES ('60', 'B10A0002（1）.jpg', '581be2e3208f4.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1248283', 'eb97fc8067576d93962850554bbac9f0', '831c0d88e8920b3e028985908dd16899ac9a92a2', '0', '1478222563', '/Public/uploadfile/file/2016-11-04/581be2e3208f4.jpg');
INSERT INTO `my_file` VALUES ('61', 'B10A0032（1）.jpg', '581be5122bebf.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1507420', 'a8e1aada6df96edcbc4a1529489e496c', 'e88d217fbaa2b98a0907b28384ca3059e84fb4c1', '0', '1478223122', '/Public/uploadfile/file/2016-11-04/581be5122bebf.jpg');
INSERT INTO `my_file` VALUES ('62', 'B10A0041（1）.jpg', '581be588af230.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1448843', '0bbceb739b68272e82f67407126ef201', 'cc9fa99349103fc8784de1b633da7965e16efcbd', '0', '1478223240', '/Public/uploadfile/file/2016-11-04/581be588af230.jpg');
INSERT INTO `my_file` VALUES ('63', 'B10A0042（1）.jpg', '581be596e370a.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1705604', '14d8f56cd2a08d6d6442f32ce894ca1b', '91791e722b8756ced32068b46d2a9be20cb9d61b', '0', '1478223254', '/Public/uploadfile/file/2016-11-04/581be596e370a.jpg');
INSERT INTO `my_file` VALUES ('64', 'B10A0047（1）.jpg', '581be6eb3b3e6.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1674880', 'e76b959418172de5b9533daa6fbfe434', 'bf30a02b9c1c65f6f617a1565bee387e919e863d', '0', '1478223595', '/Public/uploadfile/file/2016-11-04/581be6eb3b3e6.jpg');
INSERT INTO `my_file` VALUES ('65', 'B10A0048（1）.jpg', '581be6fe5f36c.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '2084344', '9ae9c478e731d393925322368a527315', '980a3a16feff5f0f43d2a606b70b5e93e3dec4d8', '0', '1478223614', '/Public/uploadfile/file/2016-11-04/581be6fe5f36c.jpg');
INSERT INTO `my_file` VALUES ('66', 'B10A0024（1）72.jpg', '581be85851327.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1819845', '9959acbf5242fc2351d52d44256f9177', '156c3082d0e886558bdc9d2d1dd07f6dd8e0f625', '0', '1478223960', '/Public/uploadfile/file/2016-11-04/581be85851327.jpg');
INSERT INTO `my_file` VALUES ('67', 'B10A0049（1）72.jpg', '581be93ca4e53.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1523098', '8bb146e53c46cb1b02fec95f86a279cd', 'd91e8e4e54fd2769921f33424b0f646c55ddf08d', '0', '1478224188', '/Public/uploadfile/file/2016-11-04/581be93ca4e53.jpg');
INSERT INTO `my_file` VALUES ('68', 'B10A0039（1）.jpg', '581beb964ba41.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1508975', 'fc1d3c88b997fbc6b9dc716acf2c5c61', '2ea2b6d47bf356a82de7bbb6748a09e2c99c4bfb', '0', '1478224790', '/Public/uploadfile/file/2016-11-04/581beb964ba41.jpg');
INSERT INTO `my_file` VALUES ('69', 'B10A0040（1）.jpg', '581beb9d787e8.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1769273', '2dd05ba53cfda973230c4a3c16b47a67', '7f026377a4323f728d0ad82775e0b8a0f53c5456', '0', '1478224797', '/Public/uploadfile/file/2016-11-04/581beb9d787e8.jpg');
INSERT INTO `my_file` VALUES ('70', 'B10A0026（1）.jpg', '581bf03db85ee.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '2011882', '8dc98c05c4022aff997f75cd3567702c', '1b4bac7e65fa390640d3b8a769ef5e594091c871', '0', '1478225981', '/Public/uploadfile/file/2016-11-04/581bf03db85ee.jpg');
INSERT INTO `my_file` VALUES ('72', 'B10A0031（1）.jpg', '581c248f74bd5.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1366575', '1d6b082ab05ca5d94097f1e867ada90f', 'e2ee123cf14c852653ac65150b535c22bdef430f', '0', '1478239375', '/Public/uploadfile/file/2016-11-04/581c248f74bd5.jpg');
INSERT INTO `my_file` VALUES ('73', 'B10A0027（1）.jpg', '581c2673271c0.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1837865', '9e310b262cb1760096e2acb3b9e694d6', '452114019656e4e18227cb62dffbf2e8b37c753d', '0', '1478239859', '/Public/uploadfile/file/2016-11-04/581c2673271c0.jpg');
INSERT INTO `my_file` VALUES ('74', 'B10A0055（1）72.jpg', '581c3a466d51d.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1402163', 'abacd1303f85179cb53da8c5f8be1103', '8e2862576cc7beb58e2d69500c9c71a5580a3695', '0', '1478244934', '/Public/uploadfile/file/2016-11-04/581c3a466d51d.jpg');
INSERT INTO `my_file` VALUES ('75', 'B10A0055（2）72.jpg', '581c3bd744721.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1741427', '1a9df2def4bf77c58e992345b08696e7', 'f2fc31483d9e45a82b374c36aacdf4bb55151ce4', '0', '1478245335', '/Public/uploadfile/file/2016-11-04/581c3bd744721.jpg');
INSERT INTO `my_file` VALUES ('76', 'B10A0018（1）72.jpg', '581c3d8e1b042.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1212946', '47a53cbc38041d68ed6f258d16a813d0', '2040b2214c39f777e537bc9cfe8b56a8e5639969', '0', '1478245774', '/Public/uploadfile/file/2016-11-04/581c3d8e1b042.jpg');
INSERT INTO `my_file` VALUES ('79', '明前绿茶.jpg', '581c56268de07.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1136335', '61d8d1096fb727eccc41624546b88359', '5a53e815a54781492bd416242409893ee146a2fd', '0', '1478252070', '/Public/uploadfile/file/2016-11-04/581c56268de07.jpg');
INSERT INTO `my_file` VALUES ('80', '云雾绿茶.jpg', '581c5850ec086.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1136070', '925318353702255af7ba5bfc7561684b', '5ab1b161f2a12dcc9e570b37b4ba2d0dcb516fa5', '0', '1478252624', '/Public/uploadfile/file/2016-11-04/581c5850ec086.jpg');
INSERT INTO `my_file` VALUES ('81', '明前绿茶.jpg', '581c59a45f669.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1153771', 'ac5533400babe20435d0ad986c975c38', '3685092c1bd1a2272b306a60b00464ed1054bd28', '0', '1478252964', '/Public/uploadfile/file/2016-11-04/581c59a45f669.jpg');
INSERT INTO `my_file` VALUES ('82', '红茶.jpg', '581c59d8af29c.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1155260', 'bd40a391625b237fd6139906aa306f20', 'f8bf125f9af8546409ff8f87d9513aa246130862', '0', '1478253016', '/Public/uploadfile/file/2016-11-04/581c59d8af29c.jpg');
INSERT INTO `my_file` VALUES ('83', '1.jpg', '581c5d39f0040.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '299608', '4e3d90835a27c5101c7685add02317a9', '72efff3fb9b7a05a368413730a5a818bef7d4dcc', '0', '1478253881', '/Public/uploadfile/file/2016-11-04/581c5d39f0040.jpg');
INSERT INTO `my_file` VALUES ('84', '2.jpg', '581c5d42454a5.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '212930', 'cc76f473e46ccac3fb774b831bd27dd7', '6cc88c5d327ff3d1410b7f0db81ee33b81b8307b', '0', '1478253890', '/Public/uploadfile/file/2016-11-04/581c5d42454a5.jpg');
INSERT INTO `my_file` VALUES ('85', '单盒.jpg', '581c606612c96.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1055242', 'a540779b3d40f1d75c67c2119da2a951', 'e8e731f7ff6d196b539558339757bb45b79ceccd', '0', '1478254694', '/Public/uploadfile/file/2016-11-04/581c606612c96.jpg');
INSERT INTO `my_file` VALUES ('86', '1.jpg', '581c606c1b2b5.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '884688', '9b5d6f8391aeed41b9d73734d22d3b0b', 'ea68c2ad21d1058121149bee7e02eef69b6190e0', '0', '1478254700', '/Public/uploadfile/file/2016-11-04/581c606c1b2b5.jpg');
INSERT INTO `my_file` VALUES ('87', '2.jpg', '581c60708530a.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1539906', '6ffd79cf082248b8d8774577b3c84458', '521990f292aaa640535e30130524b86761c026f6', '0', '1478254704', '/Public/uploadfile/file/2016-11-04/581c60708530a.jpg');
INSERT INTO `my_file` VALUES ('88', '龙裔生命液.jpg', '581c67802e499.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '405043', 'e7878017d611722d480574bada61bd0f', '39cc2d61f8bdd83b9d2a70b857b5131ffbfaa687', '0', '1478256512', '/Public/uploadfile/file/2016-11-04/581c67802e499.jpg');
INSERT INTO `my_file` VALUES ('89', '水果酵素.jpg', '581c686b7b666.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '391351', '55aab91bf23327feb6daf03821ad7a0c', 'fc0051b8761a507399cb0dcd44dfcf297f88813f', '0', '1478256747', '/Public/uploadfile/file/2016-11-04/581c686b7b666.jpg');
INSERT INTO `my_file` VALUES ('90', '4.jpg', '581c6a45a998a.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '393280', 'df379e821545ae62d74216059bed2729', '13eb1ea7eb0205437aad1edad510b0f16fa76370', '0', '1478257221', '/Public/uploadfile/file/2016-11-04/581c6a45a998a.jpg');
INSERT INTO `my_file` VALUES ('91', '图片7.png', '581c6dc3be516.png', '2016-11-04/', 'png', 'image/png', '1275095', '9f0d46829a3c8f02cf2f462dd387226e', 'b2b82981ed65a6ae8fb7a0514c9cb9e66ce26b4c', '0', '1478258115', '/Public/uploadfile/file/2016-11-04/581c6dc3be516.png');
INSERT INTO `my_file` VALUES ('92', '图片3.png', '581c6de5c1932.png', '2016-11-04/', 'png', 'image/png', '393912', 'a839379409a0ce2baec90e368df3eafb', '7e224d70cd8527a22b6a0f3eb7fadee9524ddad5', '0', '1478258149', '/Public/uploadfile/file/2016-11-04/581c6de5c1932.png');
INSERT INTO `my_file` VALUES ('93', '生产基地.jpg', '581c753217de6.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1707602', '1e0752274155f358b9fd5838c338dfb5', '8dadda4ec93b13e610fbc8935f9c8c86b111681f', '0', '1478260017', '/Public/uploadfile/file/2016-11-04/581c753217de6.jpg');
INSERT INTO `my_file` VALUES ('94', '刚藏.jpg', '581c754613111.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1985052', 'b32c7acb1a13efde8fb0d421161f5b9f', '36656788c9138c083fee234822911186c5681aad', '0', '1478260038', '/Public/uploadfile/file/2016-11-04/581c754613111.jpg');
INSERT INTO `my_file` VALUES ('95', '原材料.jpg', '581c75a619654.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '1738841', '94abcc0edcb742a71c71b91b3ac1a79c', '38a85c5569e135076eed397a2b10aff8be7c1707', '0', '1478260134', '/Public/uploadfile/file/2016-11-04/581c75a619654.jpg');
INSERT INTO `my_file` VALUES ('97', '封面.jpg', '581c7e680c457.jpg', '2016-11-04/', 'jpg', 'image/jpeg', '211197', '1eed942eb90ee91aff88488e8536a132', 'eacc6fe77d0faca43af84e3f3317e9e2c7994fc1', '0', '1478262376', '/Public/uploadfile/file/2016-11-04/581c7e680c457.jpg');
INSERT INTO `my_file` VALUES ('98', '眼霜组合.jpg', '581d92afc6e14.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1853462', 'e17780439fdf21d81c0f688e5b76ad7c', 'a85c16622716447f1ae73d9b94bc26253c327eb6', '0', '1478333103', '/Public/uploadfile/file/2016-11-05/581d92afc6e14.jpg');
INSERT INTO `my_file` VALUES ('99', 'B10A0051（1）.jpg', '581d936cd210f.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1769057', '8892b60dc7f669c1ed39a434278fcb60', '925fd82bed5f209aafddbfe1d056930301d94b07', '0', '1478333292', '/Public/uploadfile/file/2016-11-05/581d936cd210f.jpg');
INSERT INTO `my_file` VALUES ('100', '黃金眼霜1.jpg', '581d940d356e2.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1380736', '5bc43a283d8228a6640a311b18ff925b', '749150a643c0a0acc3f447792eb90460f0180e7f', '0', '1478333453', '/Public/uploadfile/file/2016-11-05/581d940d356e2.jpg');
INSERT INTO `my_file` VALUES ('101', '精华液组合.jpg', '581d943d65c59.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1260593', 'c40e719a9ad13ffb90e96a2ca33a8fa9', '32280c0167d1462b1c16f39472d6f84e691ec988', '0', '1478333501', '/Public/uploadfile/file/2016-11-05/581d943d65c59.jpg');
INSERT INTO `my_file` VALUES ('102', '精华液1.jpg', '581d95314f3ac.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1470861', '80c866226602ce36a85564a5643fca75', '1e0c2f211b2e94cbe9869d19038b6229e6c3092b', '0', '1478333745', '/Public/uploadfile/file/2016-11-05/581d95314f3ac.jpg');
INSERT INTO `my_file` VALUES ('103', '面霜组合.jpg', '581d96729e600.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1862383', 'cbce0b507273f5eb13a93064f94622b3', 'd70428592eb3b72293ff06d0187d8ec870ad2969', '0', '1478334066', '/Public/uploadfile/file/2016-11-05/581d96729e600.jpg');
INSERT INTO `my_file` VALUES ('104', '洁面乳组合.jpg', '581d9716ee3d4.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1304787', 'd0f3630b89eea14faa71e68e5f92353f', '95ddc6b7e06f099eaca3f97eb1141b6d295bc8bf', '0', '1478334230', '/Public/uploadfile/file/2016-11-05/581d9716ee3d4.jpg');
INSERT INTO `my_file` VALUES ('105', '洁面乳1.jpg', '581d97ca7d6ba.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1537140', '182e4aa06022cf1c23a22333e54cf1d1', 'ff926cc9686b9077be01e2ac2ce371b75a1d914a', '0', '1478334410', '/Public/uploadfile/file/2016-11-05/581d97ca7d6ba.jpg');
INSERT INTO `my_file` VALUES ('106', 'BB霜组合.jpg', '581d98bce4718.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1425164', '53b5e61ec395e5fbb6fb136b1ff5cac8', 'fdd19e4e4d031d884390a89adb1e39572246ff8e', '0', '1478334652', '/Public/uploadfile/file/2016-11-05/581d98bce4718.jpg');
INSERT INTO `my_file` VALUES ('107', 'B10A0045（1）.jpg', '581d99435814e.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1685088', '63cf0f9278285eb35e1d2c187391167d', '9125a0fd789aa00de72c0f06ccdad85617316539', '0', '1478334787', '/Public/uploadfile/file/2016-11-05/581d99435814e.jpg');
INSERT INTO `my_file` VALUES ('108', 'BB霜1.jpg', '581d99f4de4d3.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1436312', 'e8fa815992f359acf4d8d53ee3420b98', '4ace119ba8b104a8f676964bee960d5659cf24c3', '0', '1478334964', '/Public/uploadfile/file/2016-11-05/581d99f4de4d3.jpg');
INSERT INTO `my_file` VALUES ('109', '隔离霜组合.jpg', '581d9a3f70266.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1228068', 'ff197261a0b025ad8f19c7aadbaa3c15', 'e90d8cd2829f45bf38bb7144725849436121bf69', '0', '1478335039', '/Public/uploadfile/file/2016-11-05/581d9a3f70266.jpg');
INSERT INTO `my_file` VALUES ('110', 'B10A0043（1）.jpg', '581d9aafc5350.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1414972', '798ef4f6cac5c43c06a97465cd79aa55', '0123a8a80e0ddb60b96829da15949484d7ee58e3', '0', '1478335151', '/Public/uploadfile/file/2016-11-05/581d9aafc5350.jpg');
INSERT INTO `my_file` VALUES ('111', '隔离霜1.jpg', '581d9b37a440e.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '1352261', 'd031272489612a2a5a131c3924b1e829', 'b24a981d611e768ae94c2572f5b332025cf17061', '0', '1478335287', '/Public/uploadfile/file/2016-11-05/581d9b37a440e.jpg');
INSERT INTO `my_file` VALUES ('112', '3.jpg', '581d9f7e1a02c.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '140858', 'e5e7680974e39437bd720006e5ed8a09', 'a1008f874ece1e80c78e48b0037a1b7d3298f9ce', '0', '1478336382', '/Public/uploadfile/file/2016-11-05/581d9f7e1a02c.jpg');
INSERT INTO `my_file` VALUES ('113', '1.jpg', '581da5d53acb2.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '89910', '20e715617bb2ef3c9d1b1e0843afe38c', '03938deda323c6bff53d80477e9ff685069944e3', '0', '1478338005', '/Public/uploadfile/file/2016-11-05/581da5d53acb2.jpg');
INSERT INTO `my_file` VALUES ('114', '4.jpg', '581da5f8e685c.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '160687', '448788ff1fd5cb73c0a797a671eb56ba', 'a69410425d25d43a6f7117718665f46734dffa15', '0', '1478338040', '/Public/uploadfile/file/2016-11-05/581da5f8e685c.jpg');
INSERT INTO `my_file` VALUES ('115', '2.jpg', '581da6333dc57.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '110244', '43b3bff1764846ac11bc8ea0dfa5b7ff', 'cec02654ae167cb556c092fd2d756f2014135c5e', '0', '1478338099', '/Public/uploadfile/file/2016-11-05/581da6333dc57.jpg');
INSERT INTO `my_file` VALUES ('116', '1.jpg', '581da96949c06.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '78989', '3f6208d12bcc692c2f28ecc79849be1e', '22fa8844ac3b3632c9a4d42f65c2dfd89076a7e1', '0', '1478338921', '/Public/uploadfile/file/2016-11-05/581da96949c06.jpg');
INSERT INTO `my_file` VALUES ('117', '3.jpg', '581da96e34cdd.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '99700', '2f87834a953ed0ffb047bd041f63206a', '6455ddf60476ccab2c9f63ef66b6b7452620e4f4', '0', '1478338926', '/Public/uploadfile/file/2016-11-05/581da96e34cdd.jpg');
INSERT INTO `my_file` VALUES ('118', '2.jpg', '581da97e48894.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '136704', 'd4f0caf4bb2650cafa1d3990742cbc65', 'c6094e18c1899807115febbee86941560ab56950', '0', '1478338942', '/Public/uploadfile/file/2016-11-05/581da97e48894.jpg');
INSERT INTO `my_file` VALUES ('119', '1.jpg', '581daaf0a11ae.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '116455', '86bde716195e2edc0e0ab5a4725797e8', 'cef835f2d2a0c87fe40ad1f0663afd7a94c45632', '0', '1478339312', '/Public/uploadfile/file/2016-11-05/581daaf0a11ae.jpg');
INSERT INTO `my_file` VALUES ('120', '2.jpg', '581dab069d956.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '192105', '79a3bd1a290fc4ff88f36fbb0167c528', '79ec707eb7a05c5b224bd880ee8f4c03a81a3897', '0', '1478339334', '/Public/uploadfile/file/2016-11-05/581dab069d956.jpg');
INSERT INTO `my_file` VALUES ('121', '3.jpg', '581dab0c97b2f.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '132162', 'f69d155402b4f71ad0e475ca1b4f2fbe', '49ee0afb641ee7d0a1f9594ec36e52694653b8ae', '0', '1478339340', '/Public/uploadfile/file/2016-11-05/581dab0c97b2f.jpg');
INSERT INTO `my_file` VALUES ('122', '化妆品套盒banner.jpg', '581dc74171858.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '175854', 'c4558cd9be032c84c86e73bc231458df', 'e2de6666d5c975d4b22d93e57d6cc2f68a79fe45', '0', '1478346561', '/Public/uploadfile/file/2016-11-05/581dc74171858.jpg');
INSERT INTO `my_file` VALUES ('123', '蓝琪订制茶banner.jpg', '581dc771f2079.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '239806', 'ccf35aa558d43c080989a0e05a2a32b7', 'bd02baa563381801f3965f402a35f73ce7ce7c7f', '0', '1478346609', '/Public/uploadfile/file/2016-11-05/581dc771f2079.jpg');
INSERT INTO `my_file` VALUES ('124', '龙裔.jpg', '581dc7c47ff5e.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '476044', '26bd89f9bc8f0de0961ee02cd0925f17', '73903717580e5854e3c9353700b51331e1fb69ea', '0', '1478346692', '/Public/uploadfile/file/2016-11-05/581dc7c47ff5e.jpg');
INSERT INTO `my_file` VALUES ('125', '龙裔.jpg', '581dc87c93587.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '479992', 'dbc0d79d8ab11addde8d234f9812e7b3', '6e32a769235cd09d9201cc22b73644f7083b0e39', '0', '1478346876', '/Public/uploadfile/file/2016-11-05/581dc87c93587.jpg');
INSERT INTO `my_file` VALUES ('126', '化妆品套盒banner.jpg', '581dcb517e721.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '175066', '996923f5ca5aad8700830bc9969cfacd', '74080297ca3ce240ca0709492f5fd01c8f9eca66', '0', '1478347601', '/Public/uploadfile/file/2016-11-05/581dcb517e721.jpg');
INSERT INTO `my_file` VALUES ('127', '龙裔.jpg', '581dcb5ed7181.jpg', '2016-11-05/', 'jpg', 'image/jpeg', '247178', 'c9826d0ca78990c0a1676669cb17b6ad', '26bc6be53d6ef0aa0fd6fe66d5f98af5433ba430', '0', '1478347614', '/Public/uploadfile/file/2016-11-05/581dcb5ed7181.jpg');
INSERT INTO `my_file` VALUES ('131', '封面.jpg', '581fe9c420182.jpg', '2016-11-07/', 'jpg', 'image/jpeg', '199463', '09b40fe3118bf736e0cfaa7309c06023', '55365c13f702ff057bb91fbe529459b0980cabb0', '0', '1478486468', '/Public/uploadfile/file/2016-11-07/581fe9c420182.jpg');
INSERT INTO `my_file` VALUES ('132', 'longyi.jpg', '58200ffd1d9a3.jpg', '2016-11-07/', 'jpg', 'image/jpeg', '77788', '5865413400904116b0b2fa171c937481', 'b7bd796f5d7cabc586ed29edfe87966a98a13b0d', '0', '1478496253', '/Public/uploadfile/file/2016-11-07/58200ffd1d9a3.jpg');
INSERT INTO `my_file` VALUES ('133', '2.jpg', '582012671b099.jpg', '2016-11-07/', 'jpg', 'image/jpeg', '27786', '8ccffe434ca94f806209b148c243ad2e', '91db23da2f6c6b40e8485dfffddcbb6164332bc0', '0', '1478496871', '/Public/uploadfile/file/2016-11-07/582012671b099.jpg');
INSERT INTO `my_file` VALUES ('134', 'sod.png', '582040d947e0a.png', '2016-11-07/', 'png', 'image/png', '109887', '5dec624146780d63230a370bdb5a172c', '5332623ea245cafd8f4e4fb2c939765d882bcc8a', '0', '1478508761', '/Public/uploadfile/file/2016-11-07/582040d947e0a.png');
INSERT INTO `my_file` VALUES ('136', 'together.jpg', '58213d1a83f39.jpg', '2016-11-08/', 'jpg', 'image/jpeg', '13104', '2df3e4eb7a17d9d9b0eb1cdc0e31a03e', '9b970f93e1cb6e38bc89a42ff66a0773ab2c442c', '0', '1478573338', '/Public/uploadfile/file/2016-11-08/58213d1a83f39.jpg');
INSERT INTO `my_file` VALUES ('137', '合作.jpg', '5821418c0d6d6.jpg', '2016-11-08/', 'jpg', 'image/jpeg', '15628', '0390a89331d5c18f097e1b027c490549', '29a5e1530e398a150eea9da40b36601350e782d9', '0', '1478574476', '/Public/uploadfile/file/2016-11-08/5821418c0d6d6.jpg');
INSERT INTO `my_file` VALUES ('140', '开业.jpg', '5823cb3fa74cd.jpg', '2016-11-10/', 'jpg', 'image/jpeg', '182100', '65146ac535c5a99b6a06649f5a37a92c', '79e94c382ae8f59231ab45ad893312df0b23fa42', '0', '1478740799', '/Public/uploadfile/file/2016-11-10/5823cb3fa74cd.jpg');
INSERT INTO `my_file` VALUES ('141', '隔离霜组合1.jpg', '5829690d8dd4e.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '113481', '9191e9297289081ff01b3f7156207f09', '3cea8d9424fa1820467fc77c6bee0c0d736724f3', '0', '1479108877', '/Public/uploadfile/file/2016-11-14/5829690d8dd4e.jpg');
INSERT INTO `my_file` VALUES ('142', 'BB霜组合1.jpg', '5829692587b24.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '124051', 'd189ac0032447c78e1d83f5655928b65', '73eb1b6b65c41323d0f57bfbd0802b9d5df50ce0', '0', '1479108901', '/Public/uploadfile/file/2016-11-14/5829692587b24.jpg');
INSERT INTO `my_file` VALUES ('143', '红茶1.jpg', '5829694ddfe9a.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '429943', '7eacebf73117c4acdb86a0cc5c875cbb', 'b1700b7014face01febd6acd2b1302d7515d8390', '0', '1479108941', '/Public/uploadfile/file/2016-11-14/5829694ddfe9a.jpg');
INSERT INTO `my_file` VALUES ('144', '明前绿茶1.jpg', '5829698d3f436.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '427888', '2c67d44b0fa4c280d5bcc3ec25766137', '7ab893b3fd94c835bc1fde411fad5875dec761c2', '0', '1479109005', '/Public/uploadfile/file/2016-11-14/5829698d3f436.jpg');
INSERT INTO `my_file` VALUES ('145', '眼霜组合1.jpg', '582969a387734.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '163728', 'e57fef5840ce3b6119e3fc435d1155da', 'f44e25042f5e58ad5a8cb20a5790412907226693', '0', '1479109027', '/Public/uploadfile/file/2016-11-14/582969a387734.jpg');
INSERT INTO `my_file` VALUES ('146', '精华液组合1.jpg', '582969be49e32.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '111398', '9c17783f89e97504796a8add9a8e353a', '85a887e229d6da7bf54196adbfcb773a29c4eaa2', '0', '1479109054', '/Public/uploadfile/file/2016-11-14/582969be49e32.jpg');
INSERT INTO `my_file` VALUES ('147', '面霜组合1.jpg', '582969eb944f8.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '158226', '456c18744747d5c4194eb471a92011df', 'e5603eec62af57b8c7867af2f7eda3575097a9f6', '0', '1479109099', '/Public/uploadfile/file/2016-11-14/582969eb944f8.jpg');
INSERT INTO `my_file` VALUES ('148', '洁面乳组合1.jpg', '58296a050e5b4.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '114552', 'bf9af6c238d05fcd211e08338651d6f5', '13ecbda371a7538ca13772dff4b2987e09fc0822', '0', '1479109125', '/Public/uploadfile/file/2016-11-14/58296a050e5b4.jpg');
INSERT INTO `my_file` VALUES ('149', '套盒1.jpg', '58296e331a632.jpg', '2016-11-14/', 'jpg', 'image/jpeg', '155503', '8ef28c16052400b1cd38eedfeee4cb11', '4be46d51dee7af2db0c1187162ff7912be37a28f', '0', '1479110195', '/Public/uploadfile/file/2016-11-14/58296e331a632.jpg');
INSERT INTO `my_file` VALUES ('150', '化妆品外盒外观1.jpg', '582a7d32dd5ac.jpg', '2016-11-15/', 'jpg', 'image/jpeg', '287332', '0be1a9cf1f3c492b8c172699ae8946bd', '14b5aaa70e44f7e4c0782f05729af5e5d2574133', '0', '1479179570', '/Public/uploadfile/file/2016-11-15/582a7d32dd5ac.jpg');
INSERT INTO `my_file` VALUES ('151', 'B10A0018（1）72-small.jpg', '582a80120f534.jpg', '2016-11-15/', 'jpg', 'image/jpeg', '263630', '4e08f5ff063abf41b44de1d5024733d5', 'fb382f4dac892556532970a96fef84e1609dc17e', '0', '1479180306', '/Public/uploadfile/file/2016-11-15/582a80120f534.jpg');
INSERT INTO `my_file` VALUES ('152', '化妆品套盒提袋.jpg', '582a81d46398e.jpg', '2016-11-15/', 'jpg', 'image/jpeg', '321520', 'fd4ae38b8a206ee8e6d684c668310438', '1d057e4dedaa3ac87852aed5e8a141ece494568c', '0', '1479180756', '/Public/uploadfile/file/2016-11-15/582a81d46398e.jpg');
INSERT INTO `my_file` VALUES ('153', 'B10A0008(1)small.jpg', '582a8328497dd.jpg', '2016-11-15/', 'jpg', 'image/jpeg', '287683', 'b959d16a5b5c88ff3b08e6d7e760c8ba', '0a61940908c76f643ea454375cfcd2d0d653b8b9', '0', '1479181096', '/Public/uploadfile/file/2016-11-15/582a8328497dd.jpg');
INSERT INTO `my_file` VALUES ('154', 'B10A0018（1）small.jpg', '582bc4f3bd8a9.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '202169', '2adb40468c5061a818c1188d909720dd', 'a47c2a97908243cd44fca2701de718108307327b', '0', '1479263475', '/Public/uploadfile/file/2016-11-16/582bc4f3bd8a9.jpg');
INSERT INTO `my_file` VALUES ('155', 'B10A0005(1)small.jpg', '582bc4fc8a0e8.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '226727', '7f1c7b2253b41f6b016a0c4eb9c72e40', '80545131b8acd3e904716b7c762accaa7b5b3c74', '0', '1479263484', '/Public/uploadfile/file/2016-11-16/582bc4fc8a0e8.jpg');
INSERT INTO `my_file` VALUES ('156', 'B10A0015（1）small.jpg', '582bc5dea0fd4.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '193176', '4fd08c2cbb1371664e5dfd197f1e2716', 'c994a8422267df5e02262fe7019af3b3bacc33aa', '0', '1479263710', '/Public/uploadfile/file/2016-11-16/582bc5dea0fd4.jpg');
INSERT INTO `my_file` VALUES ('157', 'B10A0002（1）small.jpg', '582bc603dd9d5.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '202378', '11e647ee74c59c06df9d6caa4333f735', 'ee99b96dea62048ecec760d3205b576648cd6c71', '0', '1479263747', '/Public/uploadfile/file/2016-11-16/582bc603dd9d5.jpg');
INSERT INTO `my_file` VALUES ('158', '明前绿茶1.jpg', '582bc82bdbe66.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '257077', '099ee3466e8076c30f62820bc82593c2', 'f42c2989e411f2431121401aee7075fa684939e6', '0', '1479264299', '/Public/uploadfile/file/2016-11-16/582bc82bdbe66.jpg');
INSERT INTO `my_file` VALUES ('159', 'B10A0058（1）small.jpg', '582bc83ed0f1f.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '271397', '3097fa25af4c439abf66ad27cc2696ce', 'c1528b32d385bd8aacf646ce1964005d5dc188f5', '0', '1479264318', '/Public/uploadfile/file/2016-11-16/582bc83ed0f1f.jpg');
INSERT INTO `my_file` VALUES ('160', '2small.jpg', '582bc84900cc7.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '485578', '6ba75787161a55a3c00617af10675f03', '3fed87e59408a6d53e6ab119a1bd30ed0f376c17', '0', '1479264328', '/Public/uploadfile/file/2016-11-16/582bc84900cc7.jpg');
INSERT INTO `my_file` VALUES ('161', 'BB霜small.jpg', '582bcd5335d26.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '305661', '117215a291e177c832d8b0147c20d895', '9abd6d1027396e8e1c7bb438c7e82eaa7da7ee0a', '0', '1479265619', '/Public/uploadfile/file/2016-11-16/582bcd5335d26.jpg');
INSERT INTO `my_file` VALUES ('162', 'BB霜small.jpg', '582bcd70db010.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '295838', '283b5aa3853beccf9b772c036fffc629', 'bad8c23b12201155a031a0dc2994163e4d82bd48', '0', '1479265648', '/Public/uploadfile/file/2016-11-16/582bcd70db010.jpg');
INSERT INTO `my_file` VALUES ('163', '精华液small.jpg', '582bcdb34e729.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '280328', 'ff80656bad2d59d5875ab9acc2e24630', 'bceaea069f4c03cc31c2dea0b837634af297d874', '0', '1479265715', '/Public/uploadfile/file/2016-11-16/582bcdb34e729.jpg');
INSERT INTO `my_file` VALUES ('164', '精华液small.jpg', '582bcdc4e13aa.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '277195', '5f65315b5a4832817ccb2f5bad8bbb03', '1eafe5708a6ba055b4ee23b908a21aba86a9a32a', '0', '1479265732', '/Public/uploadfile/file/2016-11-16/582bcdc4e13aa.jpg');
INSERT INTO `my_file` VALUES ('165', '洁面乳small.jpg', '582bce02a551f.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '286240', 'c30e019c30f5c77644edafc711046233', '07965fe9b60e6a8146a50f66455c0ffe3dc58ae9', '0', '1479265794', '/Public/uploadfile/file/2016-11-16/582bce02a551f.jpg');
INSERT INTO `my_file` VALUES ('166', '洁面乳small.jpg', '582bce1a9dde5.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '284726', 'f618e3071909792f6216b20700bc6d9a', 'f2c1d4bac74fda3298466f70fb6dad3ef919b199', '0', '1479265818', '/Public/uploadfile/file/2016-11-16/582bce1a9dde5.jpg');
INSERT INTO `my_file` VALUES ('167', '眼霜small.jpg', '582bcf0facf40.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '311424', 'a8411d9ed27fd4ad59f5b681d1eccc45', '626a72a0ba772bbe5fe36e46eaa6635ca0572352', '0', '1479266063', '/Public/uploadfile/file/2016-11-16/582bcf0facf40.jpg');
INSERT INTO `my_file` VALUES ('168', '面霜侧small.jpg', '582bcf14c7f83.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '394396', '2eebec75a32672fa5c50157bbd5c6f66', '5ca49d899ef80d5a1c0c52d6feffea76732c5284', '0', '1479266068', '/Public/uploadfile/file/2016-11-16/582bcf14c7f83.jpg');
INSERT INTO `my_file` VALUES ('169', '眼霜侧small.jpg', '582bcf21b4cff.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '397847', 'a4b8176950c37d31ea9a6da7e2969849', '1362a59b115bba5ba49b63ed30ddeb3467904376', '0', '1479266081', '/Public/uploadfile/file/2016-11-16/582bcf21b4cff.jpg');
INSERT INTO `my_file` VALUES ('170', '眼霜small.jpg', '582bcf9ea9cbd.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '332620', '87a14d80d418afbe168e1af99009e573', '3edb7cc84d583e529c4326cd834aa6d8500861ce', '0', '1479266206', '/Public/uploadfile/file/2016-11-16/582bcf9ea9cbd.jpg');
INSERT INTO `my_file` VALUES ('171', '面霜small.jpg', '582bcfbae3c4d.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '339645', '5ee8417db1bcade9a920bc1d29106fc4', 'ba91b1aebd1ca9a54a3ca7646b07de0de347f92c', '0', '1479266234', '/Public/uploadfile/file/2016-11-16/582bcfbae3c4d.jpg');
INSERT INTO `my_file` VALUES ('172', '面霜small.jpg', '582bcfd5f34b9.jpg', '2016-11-16/', 'jpg', 'image/jpeg', '347734', '369c476b597db3129f41685becb2ed59', '811093cd9be4f8850b98387cbb23e054fc847533', '0', '1479266261', '/Public/uploadfile/file/2016-11-16/582bcfd5f34b9.jpg');
INSERT INTO `my_file` VALUES ('173', 'BB霜small1.jpg', '584778c4992af.jpg', '2016-12-07/', 'jpg', 'image/jpeg', '129204', 'f0252fca73f8855bce11875f092b3516', 'd3c0d03919395b60be5faee010b220ac2644cda5', '0', '1481078980', '/Public/uploadfile/file/2016-12-07/584778c4992af.jpg');
INSERT INTO `my_file` VALUES ('174', '1753053531.jpg', '5848d2d68c29c.jpg', '2016-12-08/', 'jpg', 'application/octet-stream', '24494', 'ad1fe03024e8c2eb9c90abf1da551020', 'd50122d25a76e36613bdc3d0b8b1812ac1198511', '0', '1481167574', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg');
INSERT INTO `my_file` VALUES ('175', 'banner1.jpg', '5848d4d509e2d.jpg', '2016-12-08/', 'jpg', 'application/octet-stream', '89879', 'cfe5b33ac38eed3ae6a706749b77f67d', 'd5c51f8023ae8e42aabcb0bed8fdb7bf9a4f4eb6', '0', '1481168084', '/Public/uploadfile/file/2016-12-08/5848d4d509e2d.jpg');
INSERT INTO `my_file` VALUES ('176', 'banner2.jpg', '5848d4df56c9e.jpg', '2016-12-08/', 'jpg', 'application/octet-stream', '78332', '3a5972d59c6b38c29d41e16f783e7ea9', 'fd5361d02fa69497336a65b7c565e4197e956682', '0', '1481168095', '/Public/uploadfile/file/2016-12-08/5848d4df56c9e.jpg');

-- -----------------------------
-- Table structure for `my_label`
-- -----------------------------
DROP TABLE IF EXISTS `my_label`;
CREATE TABLE `my_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `info` text,
  `sort` int(11) DEFAULT NULL COMMENT '0',
  `status` tinyint(4) DEFAULT NULL COMMENT '1',
  `pid` int(11) DEFAULT NULL COMMENT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `my_label`
-- -----------------------------
INSERT INTO `my_label` VALUES ('1', 'copyright', '版权说明', '©2016  龙翔国际', '1', '1', '1');
INSERT INTO `my_label` VALUES ('2', 'telephone', '服务热线电话', '028-86040608', '2', '1', '1');
INSERT INTO `my_label` VALUES ('3', 'banner', '首页幻灯', 'a:2:{i:0;a:4:{i:0;s:52:\"/Public/uploadfile/file/2016-12-08/5848d4d509e2d.jpg\";i:1;s:1:\"#\";i:2;s:0:\"\";i:3;s:1:\"3\";}i:1;a:4:{i:0;s:52:\"/Public/uploadfile/file/2016-12-08/5848d4df56c9e.jpg\";i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:1:\"3\";}}', '3', '1', '2');
INSERT INTO `my_label` VALUES ('4', 'zcxy', '注册协议', '注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议注册协议', '4', '1', '1');

-- -----------------------------
-- Table structure for `my_member`
-- -----------------------------
DROP TABLE IF EXISTS `my_member`;
CREATE TABLE `my_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(255) DEFAULT '',
  `username` varchar(255) DEFAULT NULL COMMENT '用户填写的真实姓名',
  `userpwd` varchar(255) DEFAULT NULL COMMENT '登录密码',
  `userreal` varchar(255) DEFAULT NULL COMMENT '用户填写的真实姓名',
  `idcard` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `qq` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL COMMENT '生日',
  `provinceid` int(11) DEFAULT '0',
  `cityid` int(11) DEFAULT '0',
  `districtid` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `info` varchar(255) DEFAULT NULL COMMENT '自我简介',
  `subscribe` tinyint(3) DEFAULT '0',
  `nickname` varchar(255) DEFAULT NULL,
  `sex` tinyint(3) DEFAULT '0',
  `language` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `headimgurl` varchar(255) DEFAULT NULL,
  `subscribe_time` int(11) DEFAULT '0',
  `unionid` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL COMMENT '备注名',
  `status` tinyint(3) DEFAULT '1' COMMENT '状态，启用禁用',
  `credit` decimal(10,2) DEFAULT '0.00' COMMENT '消费积分（在线充值，消费返积分，可以消费，账户无变动36个月之后可以提现）',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '佣金积分（下级消费返利，可以提现，可以充值成为消费积分）',
  `mobile` varchar(255) DEFAULT NULL COMMENT '手机号',
  `ismobilevalid` tinyint(3) DEFAULT '0' COMMENT '手机号是否验证：0-未验证，1-已验证',
  `paypwd` varchar(255) DEFAULT '' COMMENT '支付密码',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `lasttime` int(11) NOT NULL COMMENT '最后交互时间',
  `unsubscribetime` int(11) DEFAULT NULL COMMENT '最后取消关注时间',
  `fid` int(11) DEFAULT '0' COMMENT '推广人ID',
  `pid` int(11) DEFAULT '1' COMMENT '用户类别（1:普通会员，2:推广会员）默认为普通会员，消费之后自动成为推广会员拥有推广二维码',
  `sortpath` varchar(45) DEFAULT NULL,
  `point` int(11) DEFAULT '0',
  `alipay` varchar(45) DEFAULT NULL COMMENT '支付宝账号',
  `industry` varchar(45) DEFAULT NULL,
  `bought` text COMMENT '已经购买过的大类',
  `seelower` tinyint(1) DEFAULT '0' COMMENT '是否可以查看下级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员-有openid的访客信息表';

-- -----------------------------
-- Records of `my_member`
-- -----------------------------
INSERT INTO `my_member` VALUES ('1', 'oh88rt5C6riSctfJveq2Q3T8sBTQ', '叶俊_1', '', '测试员', '513922199108154654', '13548745874', '256487458', '', '2016-12-08', '0', '0', '0', '', '', '1', '叶俊', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/QIH6oaCUHBKAXg4Uoqe4jh7jSF5QIXTrsefQIcRT0kt5L6MpAsSEPPeroiaqvI2y6KbIra18ic1oPyh8pgdV7HHRMCllRyosEv/0', '1481168046', '', '', '1', '589.99', '500.00', '', '0', '', '2016-12-08 10:55:09', '0', '', '0', '2', '0,1', '0', '', '', '', '1');
INSERT INTO `my_member` VALUES ('2', 'oh88rt1n4TGKA73xkSur20ZAoxHE', '恰恰_2', '', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '恰恰', '1', 'zh_CN', '广州', '广东', '中国', 'http://wx.qlogo.cn/mmopen/pK37EoRGUAKxbv3JlPo72dI0FwDQg1Oddbmc11LQ4RUUu8JbST5E8iaK15OAyv1vc7LZFM8wKynmiagkRuNP9PN63Xh0XOibmU2/0', '1481175904', '', '', '1', '0.00', '0.00', '', '0', '', '2016-12-08 13:45:16', '0', '', '0', '1', '0,2', '0', '', '', '', '0');
INSERT INTO `my_member` VALUES ('3', 'oh88rt-QO3gaLfNPWFgn-1AXH9PE', '~覃~_3', '', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '~覃~', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/TrHzNodiaxbfIlyI5AUv3sw0RmOYcAtibiassQI3UvNSBR57ZlMZqut9h0upLCExTg8lome2SibE0g3V694moVtkFXAia7cG4UGkq/0', '1474962304', '', '', '1', '0.00', '0.00', '', '0', '', '2016-12-08 16:33:12', '0', '', '1', '1', '0,1,3', '0', '', '', '', '0');

-- -----------------------------
-- Table structure for `my_member1`
-- -----------------------------
DROP TABLE IF EXISTS `my_member1`;
CREATE TABLE `my_member1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(255) DEFAULT '',
  `username` varchar(255) DEFAULT NULL COMMENT '用户填写的真实姓名',
  `userpwd` varchar(255) DEFAULT NULL COMMENT '登录密码',
  `userreal` varchar(255) DEFAULT NULL COMMENT '用户填写的真实姓名',
  `telephone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `qq` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL COMMENT '生日',
  `provinceid` int(11) DEFAULT '0',
  `cityid` int(11) DEFAULT '0',
  `districtid` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `info` varchar(255) DEFAULT NULL COMMENT '自我简介',
  `subscribe` tinyint(3) DEFAULT '0',
  `nickname` varchar(255) DEFAULT NULL,
  `sex` tinyint(3) DEFAULT '0',
  `language` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `headimgurl` varchar(255) DEFAULT NULL,
  `subscribe_time` int(11) DEFAULT '0',
  `unionid` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL COMMENT '备注名',
  `status` tinyint(3) DEFAULT '1' COMMENT '状态，启用禁用',
  `credit` decimal(10,2) DEFAULT '0.00' COMMENT '账户余额（在线充值，不能体现，只能消费）',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '推广佣金（下级消费返利，只能体现，不能消费）',
  `mobile` varchar(255) DEFAULT NULL COMMENT '手机号',
  `ismobilevalid` tinyint(3) DEFAULT '0' COMMENT '手机号是否验证：0-未验证，1-已验证',
  `paypwd` varchar(255) DEFAULT '' COMMENT '支付密码',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `lasttime` int(11) NOT NULL COMMENT '最后交互时间',
  `unsubscribetime` int(11) DEFAULT NULL COMMENT '最后取消关注时间',
  `fid` int(11) DEFAULT '0' COMMENT '推广人ID',
  `pid` int(11) DEFAULT '1' COMMENT '用户类别',
  `sortpath` varchar(45) DEFAULT NULL,
  `point` int(11) DEFAULT '0',
  `alipay` varchar(45) DEFAULT NULL COMMENT '支付宝账号',
  `industry` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`lasttime`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='会员-有openid的访客信息表';

-- -----------------------------
-- Records of `my_member1`
-- -----------------------------
INSERT INTO `my_member1` VALUES ('3', 'oFyoRt_ywOgGSrRjt7-9VH9hehfc', '_3', '', 'yejun', '13564646464', '510458695', '589456548@qq.com', '2011-08-15', '0', '0', '0', '', '', '0', '叶俊', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/uBRw3icAiccNSXo1l9aJEEeMLVNkWESBXzj8FFicKdOYhh0FhyhJlSic5ROe7ErNUABHSdys5xbj4jVJMoX9UnG0OB5IBp9QIJqP/0', '1470376791', '', '', '1', '56.00', '494.00', '', '0', '', '2016-08-05 09:27:43', '0', '1471247292', '', '1', '0,3', '94668', '', '杜甫');
INSERT INTO `my_member1` VALUES ('4', 'oFyoRt2CTUrNbOXKexJgboWu-9ag', ' 彩红  _4', '', '', '', '', '', '', '0', '0', '0', '', '', '1', ' 彩红  ', '2', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/qoib2cicRAsSQ32gDpTibeqibcLKhYHNrLThv3v7zcFOiajX85tltOicj43E3yqf20QpbdJWjFbc8LOt2ib5ZSSTdtbHQPaZicXmQbYb/0', '1464947592', '', '', '1', '0.00', '70.00', '', '0', '', '2016-08-05 14:31:11', '0', '', '', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('11', 'oFyoRt6xnDgUBk7ecZpth-QtDN7E', '军_11', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '军', '1', 'zh_CN', '宝山', '上海', '中国', 'http://wx.qlogo.cn/mmopen/Mo0wRoP6ZM4QydkqKZshgIHXzoSInD0Wrq7Z4fbLia0M8ahn61hv5uzOMRSQy5TpELRXPZUSCZhIDMCu6vw37mRHtAmVK8u7D/0', '1465201316', '', '', '1', '0.00', '7.00', '', '0', '', '2016-08-05 14:31:22', '0', '', '', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('12', 'oFyoRt1F_Pjm7wZO7LEVqLhlzoRU', '四叶草_12', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '四叶草', '2', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/qoib2cicRAsSTCGfZgosuuwlqu4SbPJO6YcxrXcIic6j9VNdVyKAS8n2UicYJ3wGjLYiaRXnqIWDeYX6QiaANOoTbOqEB49h22k4Wl/0', '1470378023', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-05 14:31:48', '0', '', '', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('19', 'oFyoRt_lGlXqqS5RpkhqKgOOWvFg', '~覃~_19', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '~覃~', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/TrU5nn5oFhur9o1UfRgDRpXoI3tmP1bYpz5a32R5rsAPC5ibSxQySnkFgJoKjliaIz1LJ8ILnFvxjMS1D4T7ztAHkgeoMDhib6y/0', '1471245588', '', '', '1', '1.99', '20.00', '', '0', '', '2016-08-05 16:04:41', '0', '1471245364', '20', '1', '0,20,19', '300', '', '');
INSERT INTO `my_member1` VALUES ('20', 'oFyoRt8r-YlD7lrNISsLMXO2fibg', '李_20', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '李', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/TrU5nn5oFhugs3JLjbTTHjibn0193erapxNLc7tsaDTIBZGXzFl79sO7Rh39vZnsYibNhia2221SZKiabh5LCuHSsselc4O8DpDM/0', '1471245549', '', '', '1', '0.99', '20.00', '', '0', '', '2016-08-08 16:48:36', '0', '1471245457', '24', '1', '0,20', '60', '', '');
INSERT INTO `my_member1` VALUES ('21', 'oFyoRt8oKTn4jlweLYPq23uEEEl0', '静听风雨声_21', '', '肖', '15196636494', '563881594', '', '', '0', '0', '0', '', '', '1', '静听风雨声', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/qoib2cicRAsSSWVjx9VLIicC7ASaKQQKlFAIs2qJ7OWH3oPL4eFmzXHB9rsTrmkJv4ticicLHXQNs9gkd1nPVS5tfwOs6sQXic5rwp/0', '1471245718', '', '', '1', '1.01', '0.00', '', '0', '', '2016-08-08 16:48:59', '0', '1471245686', '20', '1', '20,19,24,21', '0', '', '');
INSERT INTO `my_member1` VALUES ('22', 'oFyoRtwnjYI2RyWY8Kph_PcMCByA', '_22', '', '', '', '', '', '', '0', '0', '0', '', '', '0', '', '0', '', '', '', '', '', '0', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-10 14:45:23', '0', '', '', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('23', 'oFyoRt3Ioj6uBZ9OwajjPa9b2ZJk', 'A-微行王波_23', '', '', '', '', '', '', '0', '0', '0', '', '', '1', 'A-微行王波', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/qoib2cicRAsSQ32gDpTibeqibUfPFZ0E3Vxhuiah9DzknauCkPwCsfyBibBADyGsmkqXUaibL6Afw7icSPsRJSXfel0qen9AUZ8DSv4a/0', '1470901861', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-11 15:49:39', '0', '1470901806', '', '1', '', '10', '', '');
INSERT INTO `my_member1` VALUES ('24', 'oFyoRtzieEvGy5ff8Bgb5h9I_Q1M', 'Coin_24', '', '', '', '', '', '', '0', '0', '0', '', '', '1', 'Coin', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/cyuKv0ib2zDsIayE9GvtqOic67gRTXZPIH13ECXtgjO8wWVicGkLylPoe422aAfzicInG4oqib1ZC9yibKeiaCsqBt9thqfrYZxjUWJ/0', '1471245631', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-11 16:48:42', '0', '1471245393', '19', '1', '0,20,19,24', '100', '', '');
INSERT INTO `my_member1` VALUES ('25', 'oFyoRt8nF6Ne_7lqbfCkMY_5pgqc', 'Burning_25', '', '某', '12466587897', '25887889', '', '', '0', '0', '0', '', '', '1', 'Burning', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/TrU5nn5oFhtPOBpHGMEjfAV1eANSatuv8NicCMGqJ19SqMSWDJOYpn5DhNicyHpU1hmfVNZwmFnQLKdI4IXmf6NQGu3RkSvkiaf/0', '1470988729', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-12 14:35:38', '0', '', '21', '1', '19,24,21,25', '0', '', '');
INSERT INTO `my_member1` VALUES ('26', 'oFyoRt9VJMsjZkv_4o7XNciLEsf4', '_26', '', '', '', '', '', '', '0', '0', '0', '', '', '0', '', '0', '', '', '', '', '', '0', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-12 14:39:12', '0', '', '', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('27', 'oFyoRtzQO_QrIs73UMwho9aYf-Ac', 'outsider_27', '', '', '', '', '', '', '0', '0', '0', '', '', '1', 'outsider', '2', 'zh_CN', '', '', '', 'http://wx.qlogo.cn/mmopen/qoib2cicRAsSQh6EWna3lIGLialUzTqpw3zJacI3Hg2okIrz1UPhA1cib5evPd4a97Bpb0XNIkQsJibrz66bdUdLIa2hJTDIBgfDe/0', '1470995890', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-12 17:56:52', '0', '1470995831', '', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('29', 'oFyoRt1HwroLaoxbkDM1S3aXAP9k', 'Gyd化妆造型_29', '', '', '', '', '', '', '0', '0', '0', '', '', '1', 'Gyd化妆造型', '2', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/Mo0wRoP6ZM7nz4iat0Y0tNI4kNLzAYiaCZQErTxzGiaYZlll54ZlQSK2icd3AvXI8nfQzp82nRjwAH7nwceOZfzF3fBzLne7Wnhz/0', '1471245823', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-15 15:23:37', '0', '', '21', '1', '19,24,21,29', '0', '', '');
INSERT INTO `my_member1` VALUES ('32', 'oFyoRt8mNiM3_zpYTbNnhh-fasGg', '', '', '', '', '', '', '', '0', '0', '0', '', '', '1', '穿越国境的脚印', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/NYOQdq4ic9K3KxfOuuPIaLoK6t2CeLK0nNKgBUZmqHkgBGVkfA6X3V5iaIeqOAgUtYymb2W5Siaze8Ly0kGsEqibC7dKSvDewFz7/0', '1471248388', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-15 16:06:21', '0', '', '3', '1', '', '0', '', '');
INSERT INTO `my_member1` VALUES ('34', 'oFyoRtyGknruvY2li_elii2RS-ak', '_34', '', '', '', '', '', '', '0', '0', '0', '', '', '0', 'ajiu', '1', 'zh_CN', '成都', '四川', '中国', 'http://wx.qlogo.cn/mmopen/qoib2cicRAsSQ32gDpTibeqibYMuic1iahAibjETGQ1ZRoojqTVu1GWAnCs50XBQ728sibVcTDumnEKRcNQO76ebMGMC4YXHDoKsL3K1/0', '1471249759', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-15 16:29:13', '0', '1471250043', '3', '1', '0,34', '0', '', '');
INSERT INTO `my_member1` VALUES ('37', '', 'fsadsfds', '', '', '', '', '', '', '0', '0', '0', '', '', '0', '', '0', '', '', '', '', '', '0', '', '', '1', '0.00', '0.00', '', '0', '', '2016-08-15 16:49:07', '0', '', '0', '1', '', '0', '', '');

-- -----------------------------
-- Table structure for `my_member_balance`
-- -----------------------------
DROP TABLE IF EXISTS `my_member_balance`;
CREATE TABLE `my_member_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` int(11) DEFAULT '0' COMMENT '会员ID-标识字段',
  `username` varchar(255) DEFAULT NULL,
  `prebalance` int(11) DEFAULT '0' COMMENT '之前余额',
  `amount` int(11) DEFAULT '0' COMMENT '收支金额',
  `balance` int(11) DEFAULT '0' COMMENT '本次余额',
  `balancetype` varchar(1) DEFAULT NULL COMMENT '0-支出，1-收入',
  `balancetypeid` tinyint(3) DEFAULT '0' COMMENT '收支类型ID，决定是收还是支',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(50) DEFAULT NULL,
  `status` tinyint(3) DEFAULT '1',
  `remark` varchar(1024) DEFAULT NULL COMMENT '收支备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='会员-用户余额表';


-- -----------------------------
-- Table structure for `my_member_balance_type`
-- -----------------------------
DROP TABLE IF EXISTS `my_member_balance_type`;
CREATE TABLE `my_member_balance_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `depth` tinyint(4) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `sortpath` varchar(100) DEFAULT NULL,
  `sorttype` tinyint(4) DEFAULT NULL,
  `indexpic` varchar(100) DEFAULT NULL,
  `type` tinyint(3) DEFAULT '0' COMMENT '0-支出，1-收入',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员-用户余额收支类型表';

-- -----------------------------
-- Records of `my_member_balance_type`
-- -----------------------------
INSERT INTO `my_member_balance_type` VALUES ('1', '在线充值消费积分', '', '1', '1', '1', '0', '0,1,', '0', '', '1');
INSERT INTO `my_member_balance_type` VALUES ('2', '订单消费', '', '2', '1', '1', '0', '0,2,', '0', '', '0');
INSERT INTO `my_member_balance_type` VALUES ('3', '订单退款', '', '3', '0', '1', '0', '0,3,', '0', '', '1');
INSERT INTO `my_member_balance_type` VALUES ('4', '用户提现', '', '4', '1', '1', '0', '0,4,', '0', '', '0');
INSERT INTO `my_member_balance_type` VALUES ('5', '佣金积分', '', '5', '1', '1', '0', '0,5,', '0', '', '1');
INSERT INTO `my_member_balance_type` VALUES ('6', '使用佣金积分', '', '6', '1', '2', '0', '0,6,', '0', '', '0');

-- -----------------------------
-- Table structure for `my_member_cash`
-- -----------------------------
DROP TABLE IF EXISTS `my_member_cash`;
CREATE TABLE `my_member_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` int(11) DEFAULT '0' COMMENT '会员ID-标识字段',
  `amount` decimal(10,2) DEFAULT '0.00' COMMENT '提现金额',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1' COMMENT '0-待审，1-已审，2-失败',
  `remark` varchar(1024) DEFAULT NULL COMMENT '提现备注',
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='会员-用户提现表';

-- -----------------------------
-- Records of `my_member_cash`
-- -----------------------------
INSERT INTO `my_member_cash` VALUES ('1', '1', '1000.00', '2016-12-08 15:41:08', '0', '', '叶俊_1');

-- -----------------------------
-- Table structure for `my_node`
-- -----------------------------
DROP TABLE IF EXISTS `my_node`;
CREATE TABLE `my_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `super` tinyint(3) DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `isresume` tinyint(3) DEFAULT '0' COMMENT '常用菜单',
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `name` (`name`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `my_node`
-- -----------------------------
INSERT INTO `my_node` VALUES ('1', 'Admin', '后台管理', '1', '', '1', '0', '1', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('2', 'Rbac', '权限管理', '1', '', '2', '1', '2', '', '0', 'fa fa-key', '0');
INSERT INTO `my_node` VALUES ('3', 'System', '系统设置', '1', '', '3', '1', '2', '', '0', 'fa fa-cogs', '0');
INSERT INTO `my_node` VALUES ('4', 'Content', '内容管理', '1', '', '4', '1', '2', '', '0', 'fa fa-folder-open', '0');
INSERT INTO `my_node` VALUES ('5', 'Label', '标签管理', '1', '', '5', '1', '2', '', '0', 'fa fa-bookmark', '0');
INSERT INTO `my_node` VALUES ('6', 'Setting', '分类管理', '1', '', '3', '1', '2', '', '0', 'fa fa-reorder', '0');
INSERT INTO `my_node` VALUES ('7', 'Member', '会员订单', '1', '', '7', '1', '2', '', '0', 'fa fa-user', '0');
INSERT INTO `my_node` VALUES ('8', 'Wechat', '微信平台', '1', '', '8', '1', '2', '', '0', 'fa fa-wechat', '0');
INSERT INTO `my_node` VALUES ('9', 'role', '角色管理', '1', '', '9', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('10', 'addRole', '添加角色', '0', '', '10', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('11', 'editRole', '修改角色', '0', '', '11', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('12', 'deleteRole', '删除角色', '0', '', '12', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('13', 'user', '用户管理', '1', '', '13', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('14', 'addUser', '添加用户', '0', '', '14', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('15', 'editUser', '修改用户', '0', '', '15', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('16', 'deleteUser', '删除用户', '0', '', '16', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('17', 'node', '节点管理', '1', '', '17', '2', '3', '', '1', '', '0');
INSERT INTO `my_node` VALUES ('18', 'addNode', '添加节点', '0', '', '18', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('19', 'editNode', '修改节点', '0', '', '19', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('20', 'deleteNode', '删除节点', '0', '', '20', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('21', 'config', '配置管理', '1', '', '21', '3', '3', '', '1', '', '0');
INSERT INTO `my_node` VALUES ('22', 'addConfig', '添加配置', '0', '', '22', '3', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('23', 'editConfig', '修改配置', '0', '', '23', '3', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('24', 'deleteConfig', '删除配置', '0', '', '24', '3', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('25', 'setting', '参数设置', '1', '', '25', '3', '3', '', '0', '', '1');
INSERT INTO `my_node` VALUES ('26', 'database', '数据备份', '1', '', '26', '3', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('27', 'pwd', '修改密码', '1', '', '27', '3', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('28', 'label', '标签管理', '1', '', '28', '5', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('29', 'addLabel', '添加标签', '1', '', '29', '5', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('30', 'editLabel', '修改标签', '0', '', '30', '5', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('31', 'deleteLabel', '删除标签', '0', '', '31', '5', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('32', 'access', '授权操作', '0', '', '32', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('33', 'batch', '批量操作', '0', '', '33', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('34', 'ajax', 'Ajax操作', '0', '', '34', '2', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('35', 'index', '后台首页', '0', '', '35', '2', '3', 'Index/index', '0', '', '0');
INSERT INTO `my_node` VALUES ('36', 'setting', '公众号设置', '1', '', '36', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('37', 'material', '素材管理', '1', '', '37', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('38', 'keyword', '关键词回复', '1', '', '38', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('39', 'menu', '自定义菜单', '1', '', '39', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('40', 'message', '信息群发', '0', '', '40', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('41', 'getMenu', '获取菜单', '0', '', '41', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('42', 'setMenu', '设置菜单', '0', '', '42', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('43', 'news', '图文素材管理', '0', '', '43', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('44', 'single', '单图文消息', '0', '', '44', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('45', 'multi', '多图文消息', '0', '', '45', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('46', 'editKeyword', '修改关键词', '0', '', '46', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('47', 'deleteMaterial', '删除素材', '0', '', '47', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('48', 'modal', '选择素材', '0', '', '48', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('49', 'news', '资讯分类', '0', '', '49', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('50', 'addNews', '添加资讯分类', '0', '', '50', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('51', 'editNews', '修改资讯分类', '0', '', '51', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('52', 'deleteNews', '删除资讯分类', '0', '', '52', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('53', 'info', '单页分类', '1', '', '53', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('54', 'addInfo', '添加单页分类', '0', '', '54', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('55', 'editInfo', '修改单页分类', '0', '', '55', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('56', 'deleteInfo', '删除单页分类', '0', '', '56', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('57', 'news', '资讯列表', '0', '', '57', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('58', 'addNews', '添加资讯', '0', '', '58', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('59', 'editNews', '修改资讯', '0', '', '59', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('60', 'deleteNews', '删除资讯', '0', '', '60', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('61', 'info', '单页列表', '1', '', '61', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('62', 'addInfo', '添加单页', '0', '', '62', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('63', 'editInfo', '修改单页', '0', '', '63', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('64', 'deleteInfo', '删除单页', '0', '', '64', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('65', 'modal', '素材选择', '0', '', '65', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('66', 'product', '产品分类', '1', '', '48', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('67', 'addProduct', '添加产品分类', '0', '', '67', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('68', 'editProduct', '修改产品分类', '0', '', '68', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('69', 'deleteProduct', '删除产品分类', '0', '', '69', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('70', 'product', '产品列表', '1', '', '60', '4', '3', '', '0', '', '1');
INSERT INTO `my_node` VALUES ('71', 'addProduct', '添加产品', '0', '', '71', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('72', 'editProduct', '修改产品', '0', '', '72', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('73', 'deleteProduct', '删除产品', '0', '', '73', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('74', 'member', '会员列表', '1', '', '74', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('75', 'addMember', '添加会员', '0', '', '75', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('76', 'editMember', '修改会员', '0', '', '76', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('77', 'deleteMember', '删除会员', '0', '', '77', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('78', 'order', '订单列表', '1', '', '78', '7', '3', '', '0', '', '1');
INSERT INTO `my_node` VALUES ('79', 'addOrder', '添加订单', '0', '', '79', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('80', 'editOrder', '修改订单', '0', '', '80', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('81', 'deleteOrder', '删除订单', '0', '', '81', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('82', 'member', '会员分类', '0', '', '82', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('83', 'addMember', '添加会员分类', '0', '', '83', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('84', 'editMember', '修改会员分类', '0', '', '84', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('85', 'deleteMember', '删除会员分类', '0', '', '85', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('86', 'express', '快递列表', '1', '', '86', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('87', 'addExpress', '添加快递', '0', '', '87', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('88', 'editExpress', '修改快递', '0', '', '88', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('89', 'deleteExpress', '删除快递', '0', '', '89', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('90', 'balance', '余额记录', '0', '', '90', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('91', 'coupon', '优惠券列表', '0', '', '91', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('92', 'addCoupon', '添加优惠券', '0', '', '92', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('93', 'editCoupon', '修改优惠券', '0', '', '93', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('94', 'deleteCoupon', '删除优惠券', '0', '', '94', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('95', 'coupon', '优惠券分类', '0', '', '95', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('96', 'addCoupon', '添加优惠券分类', '0', '', '96', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('97', 'editCoupon', '修改优惠券分类', '0', '', '97', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('98', 'deleteCoupon', '删除优惠券分类', '0', '', '98', '6', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('99', 'cash', '提现列表', '1', '', '99', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('100', 'addCash', '添加提现', '0', '', '100', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('101', 'editCash', '修改提现', '0', '', '101', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('102', 'deleteCash', '删除提现', '0', '', '102', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('103', 'statistic', '订单统计', '0', '', '103', '7', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('104', 'pointproduct', '积分产品', '0', '积分产品', '104', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('105', 'addpointProduct', '添加积分产品', '0', '', '105', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('106', 'editpointProduct', '编辑积分产品', '0', '', '106', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('107', 'active', '活动列表', '0', '', '107', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('108', 'addactive', '添加活动', '0', '', '108', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('109', 'editactive', '编辑活动', '0', '', '109', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('110', 'deleteactive', '删除活动', '0', '', '110', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('111', 'activemember', '活动参加选手', '0', '', '111', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('112', 'memberview', '参赛选手详细', '0', '', '112', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('113', 'deleteactivemember', '删除参赛选手', '0', '', '113', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('114', 'addKeyword', '添加关键词', '0', '', '114', '8', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('115', 'deletepointProduct', '删除积分产品', '0', '', '115', '4', '3', '', '0', '', '0');
INSERT INTO `my_node` VALUES ('116', 'exportorder', '导出订单', '0', '', '116', '7', '3', '', '0', '', '0');

-- -----------------------------
-- Table structure for `my_order`
-- -----------------------------
DROP TABLE IF EXISTS `my_order`;
CREATE TABLE `my_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderno` varchar(255) DEFAULT NULL COMMENT '订单编号',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '订单名称',
  `memberid` int(11) DEFAULT '0' COMMENT '会员ID',
  `nickname` varchar(255) DEFAULT NULL,
  `headimgurl` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '0' COMMENT '0-未付款,1-待发货,2-已发货,3-已完成,4-已取消,5-已退款',
  `ordertimes` varchar(255) DEFAULT NULL COMMENT '订单状态时间',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '订购数量',
  `username` varchar(255) DEFAULT NULL COMMENT '用户填写的真实姓名',
  `telephone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `addressid` int(11) DEFAULT '0' COMMENT '收货地址ID',
  `provinceid` int(11) DEFAULT '0',
  `cityid` int(11) DEFAULT '0',
  `districtid` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT '' COMMENT '详细地址',
  `remark` text COMMENT '订单备注',
  `amount` decimal(10,2) DEFAULT '0.00' COMMENT '订单实付金额',
  `total` decimal(10,2) DEFAULT '0.00' COMMENT '商品总额',
  `shipfee` decimal(10,2) DEFAULT '0.00' COMMENT '运费',
  `discount` decimal(10,2) DEFAULT '0.00' COMMENT '折扣金额',
  `paystatus` tinyint(3) DEFAULT '0' COMMENT '支付状态：0-未付款，1-已付款',
  `paytime` timestamp NULL DEFAULT NULL COMMENT '支付时间',
  `paymethod` tinyint(3) DEFAULT '0' COMMENT '支付方式：0-到店支付，1-微信支付',
  `tradeno` varchar(255) DEFAULT '' COMMENT '交易流水号',
  `payinfo` longtext COMMENT '支付详细',
  `refundinfo` varchar(1024) DEFAULT '' COMMENT '退款详细',
  `refundqueryinfo` varchar(1024) DEFAULT '' COMMENT '退款查询详细',
  `replyinfo` varchar(255) DEFAULT NULL COMMENT '处理意见',
  `replytime` timestamp NULL DEFAULT NULL COMMENT '处理时间',
  `guid` varchar(255) DEFAULT NULL COMMENT '会员标识',
  `expressid` int(11) DEFAULT '0' COMMENT '物流公司ID',
  `expressno` varchar(255) DEFAULT NULL COMMENT '物流单号',
  `couponno` varchar(255) DEFAULT NULL COMMENT '优惠券号',
  `type` int(11) DEFAULT '1' COMMENT '1：商品订单，2：积分订单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='订单表';

-- -----------------------------
-- Records of `my_order`
-- -----------------------------
INSERT INTO `my_order` VALUES ('27', '1612088584', '个人定制2,', '1', '叶俊', 'http://wx.qlogo.cn/mmopen/QIH6oaCUHBKAXg4Uoqe4jh7jSF5QIXTrsefQIcRT0kt5L6MpAsSEPPeroiaqvI2y6KbIra18ic1oPyh8pgdV7HHRMCllRyosEv/0', '2016-12-08 14:07:00', '1', '', '1', 'yejun', '13564646787', '72', '11', '1101', '110103', '详细地址', '', '0.01', '0.01', '0.00', '0.00', '1', '2016-12-08 14:07:00', '2', '', '', '', '', '', '', '', '', '', '', '1');
INSERT INTO `my_order` VALUES ('28', '1612085DF1', '国宾,', '1', '叶俊', 'http://wx.qlogo.cn/mmopen/QIH6oaCUHBKAXg4Uoqe4jh7jSF5QIXTrsefQIcRT0kt5L6MpAsSEPPeroiaqvI2y6KbIra18ic1oPyh8pgdV7HHRMCllRyosEv/0', '2016-12-08 14:09:46', '1', '', '1', 'yejun', '13564646787', '72', '11', '1101', '110103', '详细地址', '', '10.00', '10.00', '0.00', '0.00', '1', '2016-12-08 14:09:46', '2', '', '', '', '', '', '', '', '', '', '', '1');

-- -----------------------------
-- Table structure for `my_order_detail`
-- -----------------------------
DROP TABLE IF EXISTS `my_order_detail`;
CREATE TABLE `my_order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderno` varchar(255) DEFAULT NULL COMMENT '订单编号',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `productid` int(11) DEFAULT '0' COMMENT '产品ID',
  `firstpid` int(11) DEFAULT '0',
  `specification` varchar(255) NOT NULL DEFAULT '' COMMENT '产品规格',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '产品名称',
  `indexpic` varchar(255) NOT NULL DEFAULT '' COMMENT '形象图',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `num` int(10) NOT NULL DEFAULT '0' COMMENT '订购数量',
  `status` tinyint(3) DEFAULT '0' COMMENT '0-未付款,1-待发货,2-已发货,3-已完成,4-已取消,5-已退款',
  `weight` int(11) DEFAULT '0' COMMENT '重量（克）',
  `attrs` longtext COMMENT '属性',
  `secondbuy` int(11) DEFAULT '0' COMMENT '0:第一次购买该大类下产品，1：第二次购买该大类下产品',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='订单详细表';

-- -----------------------------
-- Records of `my_order_detail`
-- -----------------------------
INSERT INTO `my_order_detail` VALUES ('35', '1612088584', '2016-12-08 14:07:00', '10', '0', '', '个人定制2', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '0.01', '1', '1', '0', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '0');
INSERT INTO `my_order_detail` VALUES ('36', '1612085DF1', '2016-12-08 14:09:46', '3', '0', '', '国宾', '/Public/uploadfile/file/2016-12-08/5848d2d68c29c.jpg', '10.00', '1', '1', '0', '{\"酒精度\":\"53%vol\",\"净含量\":\"500ml\"}', '0');

-- -----------------------------
-- Table structure for `my_order_history`
-- -----------------------------
DROP TABLE IF EXISTS `my_order_history`;
CREATE TABLE `my_order_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderno` varchar(255) DEFAULT NULL COMMENT '订单号',
  `status` tinyint(3) DEFAULT '0' COMMENT '订单状态',
  `content` text COMMENT '订单内容',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='订单修改记录';


-- -----------------------------
-- Table structure for `my_pcd`
-- -----------------------------
DROP TABLE IF EXISTS `my_pcd`;
CREATE TABLE `my_pcd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) DEFAULT '0',
  `pid` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `level` tinyint(1) DEFAULT '0',
  `status` int(10) DEFAULT '0',
  `ext` int(10) DEFAULT '0',
  `sort` int(10) DEFAULT '0',
  `en` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3568 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='全国省市区街道';

-- -----------------------------
-- Records of `my_pcd`
-- -----------------------------
INSERT INTO `my_pcd` VALUES ('1', '11', '0', '北京市', '1', '1', '0', '11', 'B');
INSERT INTO `my_pcd` VALUES ('2', '1101', '11', '市辖区', '2', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3', '110101', '1101', '东城区', '3', '1', '0', '1', 'D');
INSERT INTO `my_pcd` VALUES ('4', '110102', '1101', '西城区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('5', '110103', '1101', '崇文区', '3', '1', '0', '3', 'C');
INSERT INTO `my_pcd` VALUES ('6', '110104', '1101', '宣武区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('7', '110105', '1101', '朝阳区', '3', '1', '0', '5', 'C');
INSERT INTO `my_pcd` VALUES ('8', '110106', '1101', '丰台区', '3', '1', '0', '6', 'F');
INSERT INTO `my_pcd` VALUES ('9', '110107', '1101', '石景山区', '3', '1', '0', '7', 'S');
INSERT INTO `my_pcd` VALUES ('10', '110108', '1101', '海淀区', '3', '1', '0', '8', 'H');
INSERT INTO `my_pcd` VALUES ('11', '110109', '1101', '门头沟区', '3', '1', '0', '9', 'M');
INSERT INTO `my_pcd` VALUES ('12', '110111', '1101', '房山区', '3', '1', '0', '11', 'F');
INSERT INTO `my_pcd` VALUES ('13', '110112', '1101', '通州区', '3', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('14', '110113', '1101', '顺义区', '3', '1', '0', '13', 'S');
INSERT INTO `my_pcd` VALUES ('15', '110114', '1101', '昌平区', '3', '1', '0', '14', 'C');
INSERT INTO `my_pcd` VALUES ('16', '110115', '1101', '大兴区', '3', '1', '0', '15', 'D');
INSERT INTO `my_pcd` VALUES ('17', '110116', '1101', '怀柔区', '3', '1', '0', '16', 'H');
INSERT INTO `my_pcd` VALUES ('18', '110117', '1101', '平谷区', '3', '1', '0', '17', 'P');
INSERT INTO `my_pcd` VALUES ('19', '1102', '11', '县', '2', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('20', '110228', '1102', '密云县', '3', '1', '0', '28', 'M');
INSERT INTO `my_pcd` VALUES ('21', '110229', '1102', '延庆县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('22', '12', '0', '天津市', '1', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('23', '1201', '12', '市辖区', '2', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('24', '120101', '1201', '和平区', '3', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('25', '120102', '1201', '河东区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('26', '120103', '1201', '河西区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('27', '120104', '1201', '南开区', '3', '1', '0', '4', 'N');
INSERT INTO `my_pcd` VALUES ('28', '120105', '1201', '河北区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('29', '120106', '1201', '红桥区', '3', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('30', '120107', '1201', '塘沽区', '3', '1', '0', '7', 'T');
INSERT INTO `my_pcd` VALUES ('31', '120108', '1201', '汉沽区', '3', '1', '0', '8', 'H');
INSERT INTO `my_pcd` VALUES ('32', '120109', '1201', '大港区', '3', '1', '0', '9', 'D');
INSERT INTO `my_pcd` VALUES ('33', '120110', '1201', '东丽区', '3', '1', '0', '10', 'D');
INSERT INTO `my_pcd` VALUES ('34', '120111', '1201', '西青区', '3', '1', '0', '11', 'X');
INSERT INTO `my_pcd` VALUES ('35', '120112', '1201', '津南区', '3', '1', '0', '12', 'J');
INSERT INTO `my_pcd` VALUES ('36', '120113', '1201', '北辰区', '3', '1', '0', '13', 'B');
INSERT INTO `my_pcd` VALUES ('37', '120114', '1201', '武清区', '3', '1', '0', '14', 'W');
INSERT INTO `my_pcd` VALUES ('38', '120115', '1201', '宝坻区', '3', '1', '0', '15', 'B');
INSERT INTO `my_pcd` VALUES ('39', '1202', '12', '市辖县', '2', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('40', '120221', '1202', '宁河县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('41', '120223', '1202', '静海县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('42', '120225', '1202', '蓟县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('43', '13', '0', '河北省', '3', '1', '0', '13', 'H');
INSERT INTO `my_pcd` VALUES ('44', '1301', '13', '石家庄市', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('45', '130101', '1301', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('46', '130102', '1301', '长安区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('47', '130103', '1301', '桥东区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('48', '130104', '1301', '桥西区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('49', '130105', '1301', '新华区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('50', '130107', '1301', '井陉矿区', '3', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('51', '130108', '1301', '裕华区', '3', '1', '0', '8', 'Y');
INSERT INTO `my_pcd` VALUES ('52', '130121', '1301', '井陉县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('53', '130123', '1301', '正定县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('54', '130124', '1301', '栾城县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('55', '130125', '1301', '行唐县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('56', '130126', '1301', '灵寿县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('57', '130127', '1301', '高邑县', '3', '1', '0', '27', 'G');
INSERT INTO `my_pcd` VALUES ('58', '130128', '1301', '深泽县', '3', '1', '0', '28', 'S');
INSERT INTO `my_pcd` VALUES ('59', '130129', '1301', '赞皇县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('60', '130130', '1301', '无极县', '3', '1', '0', '30', 'W');
INSERT INTO `my_pcd` VALUES ('61', '130131', '1301', '平山县', '3', '1', '0', '31', 'P');
INSERT INTO `my_pcd` VALUES ('62', '130132', '1301', '元氏县', '3', '1', '0', '32', 'Y');
INSERT INTO `my_pcd` VALUES ('63', '130133', '1301', '赵县', '3', '1', '0', '33', 'Z');
INSERT INTO `my_pcd` VALUES ('64', '130181', '1301', '辛集市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('65', '130182', '1301', '藁城市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('66', '130183', '1301', '晋州市', '3', '1', '0', '83', 'J');
INSERT INTO `my_pcd` VALUES ('67', '130184', '1301', '新乐市', '3', '1', '0', '84', 'X');
INSERT INTO `my_pcd` VALUES ('68', '130185', '1301', '鹿泉市', '3', '1', '0', '85', 'L');
INSERT INTO `my_pcd` VALUES ('69', '1302', '13', '唐山市', '2', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('70', '130201', '1302', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('71', '130202', '1302', '路南区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('72', '130203', '1302', '路北区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('73', '130204', '1302', '古冶区', '3', '1', '0', '4', 'G');
INSERT INTO `my_pcd` VALUES ('74', '130205', '1302', '开平区', '3', '1', '0', '5', 'K');
INSERT INTO `my_pcd` VALUES ('75', '130207', '1302', '丰南区', '3', '1', '0', '7', 'F');
INSERT INTO `my_pcd` VALUES ('76', '130208', '1302', '丰润区', '3', '1', '0', '8', 'F');
INSERT INTO `my_pcd` VALUES ('77', '130223', '1302', '滦县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('78', '130224', '1302', '滦南县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('79', '130225', '1302', '乐亭县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('80', '130227', '1302', '迁西县', '3', '1', '0', '27', 'Q');
INSERT INTO `my_pcd` VALUES ('81', '130229', '1302', '玉田县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('82', '130230', '1302', '唐海县', '3', '1', '0', '30', 'T');
INSERT INTO `my_pcd` VALUES ('83', '130281', '1302', '遵化市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('84', '130283', '1302', '迁安市', '3', '1', '0', '83', 'Q');
INSERT INTO `my_pcd` VALUES ('85', '1303', '13', '秦皇岛市', '2', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('86', '130301', '1303', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('87', '130302', '1303', '海港区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('88', '130303', '1303', '山海关区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('89', '130304', '1303', '北戴河区', '3', '1', '0', '4', 'B');
INSERT INTO `my_pcd` VALUES ('90', '130321', '1303', '青龙满族自治县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('91', '130322', '1303', '昌黎县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('92', '130323', '1303', '抚宁县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('93', '130324', '1303', '卢龙县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('94', '1304', '13', '邯郸市', '2', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('95', '130401', '1304', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('96', '130402', '1304', '邯山区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('97', '130403', '1304', '丛台区', '3', '1', '0', '3', 'C');
INSERT INTO `my_pcd` VALUES ('98', '130404', '1304', '复兴区', '3', '1', '0', '4', 'F');
INSERT INTO `my_pcd` VALUES ('99', '130406', '1304', '峰峰矿区', '3', '1', '0', '6', 'F');
INSERT INTO `my_pcd` VALUES ('100', '130421', '1304', '邯郸县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('101', '130423', '1304', '临漳县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('102', '130424', '1304', '成安县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('103', '130425', '1304', '大名县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('104', '130426', '1304', '涉县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('105', '130427', '1304', '磁县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('106', '130428', '1304', '肥乡县', '3', '1', '0', '28', 'F');
INSERT INTO `my_pcd` VALUES ('107', '130429', '1304', '永年县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('108', '130430', '1304', '邱县', '3', '1', '0', '30', 'Q');
INSERT INTO `my_pcd` VALUES ('109', '130431', '1304', '鸡泽县', '3', '1', '0', '31', 'J');
INSERT INTO `my_pcd` VALUES ('110', '130432', '1304', '广平县', '3', '1', '0', '32', 'G');
INSERT INTO `my_pcd` VALUES ('111', '130433', '1304', '馆陶县', '3', '1', '0', '33', 'G');
INSERT INTO `my_pcd` VALUES ('112', '130434', '1304', '魏县', '3', '1', '0', '34', 'W');
INSERT INTO `my_pcd` VALUES ('113', '130435', '1304', '曲周县', '3', '1', '0', '35', 'Q');
INSERT INTO `my_pcd` VALUES ('114', '130481', '1304', '武安市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('115', '1305', '13', '邢台市', '2', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('116', '130501', '1305', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('117', '130502', '1305', '桥东区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('118', '130503', '1305', '桥西区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('119', '130521', '1305', '邢台县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('120', '130522', '1305', '临城县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('121', '130523', '1305', '内邱县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('122', '130524', '1305', '柏乡县', '3', '1', '0', '24', 'B');
INSERT INTO `my_pcd` VALUES ('123', '130525', '1305', '隆尧县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('124', '130526', '1305', '任县', '3', '1', '0', '26', 'R');
INSERT INTO `my_pcd` VALUES ('125', '130527', '1305', '南和县', '3', '1', '0', '27', 'N');
INSERT INTO `my_pcd` VALUES ('126', '130528', '1305', '宁晋县', '3', '1', '0', '28', 'N');
INSERT INTO `my_pcd` VALUES ('127', '130529', '1305', '巨鹿县', '3', '1', '0', '29', 'J');
INSERT INTO `my_pcd` VALUES ('128', '130530', '1305', '新河县', '3', '1', '0', '30', 'X');
INSERT INTO `my_pcd` VALUES ('129', '130531', '1305', '广宗县', '3', '1', '0', '31', 'G');
INSERT INTO `my_pcd` VALUES ('130', '130532', '1305', '平乡县', '3', '1', '0', '32', 'P');
INSERT INTO `my_pcd` VALUES ('131', '130533', '1305', '威县', '3', '1', '0', '33', 'W');
INSERT INTO `my_pcd` VALUES ('132', '130534', '1305', '清河县', '3', '1', '0', '34', 'Q');
INSERT INTO `my_pcd` VALUES ('133', '130535', '1305', '临西县', '3', '1', '0', '35', 'L');
INSERT INTO `my_pcd` VALUES ('134', '130581', '1305', '南宫市', '3', '1', '0', '81', 'N');
INSERT INTO `my_pcd` VALUES ('135', '130582', '1305', '沙河市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('136', '1306', '13', '保定市', '2', '1', '0', '6', 'B');
INSERT INTO `my_pcd` VALUES ('137', '130601', '1306', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('138', '130602', '1306', '新市区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('139', '130603', '1306', '北市区', '3', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('140', '130604', '1306', '南市区', '3', '1', '0', '4', 'N');
INSERT INTO `my_pcd` VALUES ('141', '130621', '1306', '满城县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('142', '130622', '1306', '清苑县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('143', '130623', '1306', '涞水县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('144', '130624', '1306', '阜平县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('145', '130625', '1306', '徐水县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('146', '130626', '1306', '定兴县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('147', '130627', '1306', '唐县', '3', '1', '0', '27', 'T');
INSERT INTO `my_pcd` VALUES ('148', '130628', '1306', '高阳县', '3', '1', '0', '28', 'G');
INSERT INTO `my_pcd` VALUES ('149', '130629', '1306', '容城县', '3', '1', '0', '29', 'R');
INSERT INTO `my_pcd` VALUES ('150', '130630', '1306', '涞源县', '3', '1', '0', '30', 'Z');
INSERT INTO `my_pcd` VALUES ('151', '130631', '1306', '望都县', '3', '1', '0', '31', 'W');
INSERT INTO `my_pcd` VALUES ('152', '130632', '1306', '安新县', '3', '1', '0', '32', 'A');
INSERT INTO `my_pcd` VALUES ('153', '130633', '1306', '易县', '3', '1', '0', '33', 'Y');
INSERT INTO `my_pcd` VALUES ('154', '130634', '1306', '曲阳县', '3', '1', '0', '34', 'Q');
INSERT INTO `my_pcd` VALUES ('155', '130635', '1306', '蠡县', '3', '1', '0', '35', 'Z');
INSERT INTO `my_pcd` VALUES ('156', '130636', '1306', '顺平县', '3', '1', '0', '36', 'S');
INSERT INTO `my_pcd` VALUES ('157', '130637', '1306', '博野县', '3', '1', '0', '37', 'B');
INSERT INTO `my_pcd` VALUES ('158', '130638', '1306', '雄县', '3', '1', '0', '38', 'X');
INSERT INTO `my_pcd` VALUES ('159', '130681', '1306', '涿州市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('160', '130682', '1306', '定州市', '3', '1', '0', '82', 'D');
INSERT INTO `my_pcd` VALUES ('161', '130683', '1306', '安国市', '3', '1', '0', '83', 'A');
INSERT INTO `my_pcd` VALUES ('162', '130684', '1306', '高碑店市', '3', '1', '0', '84', 'G');
INSERT INTO `my_pcd` VALUES ('163', '1307', '13', '张家口市', '2', '1', '0', '7', 'Z');
INSERT INTO `my_pcd` VALUES ('164', '130701', '1307', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('165', '130702', '1307', '桥东区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('166', '130703', '1307', '桥西区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('167', '130705', '1307', '宣化区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('168', '130706', '1307', '下花园区', '3', '1', '0', '6', 'X');
INSERT INTO `my_pcd` VALUES ('169', '130721', '1307', '宣化县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('170', '130722', '1307', '张北县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('171', '130723', '1307', '康保县', '3', '1', '0', '23', 'K');
INSERT INTO `my_pcd` VALUES ('172', '130724', '1307', '沽源县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('173', '130725', '1307', '尚义县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('174', '130726', '1307', '蔚县', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('175', '130727', '1307', '阳原县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('176', '130728', '1307', '怀安县', '3', '1', '0', '28', 'H');
INSERT INTO `my_pcd` VALUES ('177', '130729', '1307', '万全县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('178', '130730', '1307', '怀来县', '3', '1', '0', '30', 'H');
INSERT INTO `my_pcd` VALUES ('179', '130731', '1307', '涿鹿县', '3', '1', '0', '31', 'Z');
INSERT INTO `my_pcd` VALUES ('180', '130732', '1307', '赤城县', '3', '1', '0', '32', 'C');
INSERT INTO `my_pcd` VALUES ('181', '130733', '1307', '崇礼县', '3', '1', '0', '33', 'C');
INSERT INTO `my_pcd` VALUES ('182', '1308', '13', '承德市', '2', '1', '0', '8', 'C');
INSERT INTO `my_pcd` VALUES ('183', '130801', '1308', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('184', '130802', '1308', '双桥区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('185', '130803', '1308', '双滦区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('186', '130804', '1308', '鹰手营子矿区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('187', '130821', '1308', '承德县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('188', '130822', '1308', '兴隆县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('189', '130823', '1308', '平泉县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('190', '130824', '1308', '滦平县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('191', '130825', '1308', '隆化县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('192', '130826', '1308', '丰宁满族自治县', '3', '1', '0', '26', 'F');
INSERT INTO `my_pcd` VALUES ('193', '130827', '1308', '宽城满族自治县', '3', '1', '0', '27', 'K');
INSERT INTO `my_pcd` VALUES ('194', '130828', '1308', '围场满族蒙古族自治县', '3', '1', '0', '28', 'W');
INSERT INTO `my_pcd` VALUES ('195', '1309', '13', '沧州市', '2', '1', '0', '9', 'C');
INSERT INTO `my_pcd` VALUES ('196', '130901', '1309', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('197', '130902', '1309', '新华区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('198', '130903', '1309', '运河区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('199', '130921', '1309', '沧县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('200', '130922', '1309', '青县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('201', '130923', '1309', '东光县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('202', '130924', '1309', '海兴县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('203', '130925', '1309', '盐山县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('204', '130926', '1309', '肃宁县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('205', '130927', '1309', '南皮县', '3', '1', '0', '27', 'N');
INSERT INTO `my_pcd` VALUES ('206', '130928', '1309', '吴桥县', '3', '1', '0', '28', 'W');
INSERT INTO `my_pcd` VALUES ('207', '130929', '1309', '献县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('208', '130930', '1309', '孟村回族自治县', '3', '1', '0', '30', 'M');
INSERT INTO `my_pcd` VALUES ('209', '130981', '1309', '泊头市', '3', '1', '0', '81', 'B');
INSERT INTO `my_pcd` VALUES ('210', '130982', '1309', '任邱市', '3', '1', '0', '82', 'R');
INSERT INTO `my_pcd` VALUES ('211', '130983', '1309', '黄骅市', '3', '1', '0', '83', 'H');
INSERT INTO `my_pcd` VALUES ('212', '130984', '1309', '河间市', '3', '1', '0', '84', 'H');
INSERT INTO `my_pcd` VALUES ('213', '1310', '13', '廊坊市', '2', '1', '0', '10', 'L');
INSERT INTO `my_pcd` VALUES ('214', '131001', '1310', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('215', '131002', '1310', '安次区', '3', '1', '0', '2', 'A');
INSERT INTO `my_pcd` VALUES ('216', '131003', '1310', '广阳区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('217', '131022', '1310', '固安县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('218', '131023', '1310', '永清县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('219', '131024', '1310', '香河县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('220', '131025', '1310', '大城县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('221', '131026', '1310', '文安县', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('222', '131028', '1310', '大厂回族自治县', '3', '1', '0', '28', 'D');
INSERT INTO `my_pcd` VALUES ('223', '131081', '1310', '霸州市', '3', '1', '0', '81', 'B');
INSERT INTO `my_pcd` VALUES ('224', '131082', '1310', '三河市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('225', '1311', '13', '衡水市', '2', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('226', '131101', '1311', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('227', '131102', '1311', '桃城区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('228', '131121', '1311', '枣强县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('229', '131122', '1311', '武邑县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('230', '131123', '1311', '武强县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('231', '131124', '1311', '饶阳县', '3', '1', '0', '24', 'R');
INSERT INTO `my_pcd` VALUES ('232', '131125', '1311', '安平县', '3', '1', '0', '25', 'A');
INSERT INTO `my_pcd` VALUES ('233', '131126', '1311', '故城县', '3', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('234', '131127', '1311', '景县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('235', '131128', '1311', '阜城县', '3', '1', '0', '28', 'F');
INSERT INTO `my_pcd` VALUES ('236', '131181', '1311', '冀州市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('237', '131182', '1311', '深州市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('238', '14', '0', '山西', '1', '1', '0', '14', 'S');
INSERT INTO `my_pcd` VALUES ('239', '1401', '14', '太原市', '2', '1', '0', '1', 'T');
INSERT INTO `my_pcd` VALUES ('240', '140101', '1401', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('241', '140105', '1401', '小店区(人口含高新经济区)', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('242', '140106', '1401', '迎泽区', '3', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('243', '140107', '1401', '杏花岭区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('244', '140108', '1401', '尖草坪区', '3', '1', '0', '8', 'J');
INSERT INTO `my_pcd` VALUES ('245', '140109', '1401', '万柏林区', '3', '1', '0', '9', 'W');
INSERT INTO `my_pcd` VALUES ('246', '140110', '1401', '晋源区', '3', '1', '0', '10', 'J');
INSERT INTO `my_pcd` VALUES ('247', '140121', '1401', '清徐县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('248', '140122', '1401', '阳曲县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('249', '140123', '1401', '娄烦县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('250', '140181', '1401', '古交市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('251', '1402', '14', '大同市', '2', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('252', '140201', '1402', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('253', '140202', '1402', '大同市城区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('254', '140203', '1402', '矿区', '3', '1', '0', '3', 'K');
INSERT INTO `my_pcd` VALUES ('255', '140211', '1402', '南郊区', '3', '1', '0', '11', 'N');
INSERT INTO `my_pcd` VALUES ('256', '140212', '1402', '新荣区', '3', '1', '0', '12', 'X');
INSERT INTO `my_pcd` VALUES ('257', '140221', '1402', '阳高县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('258', '140222', '1402', '天镇县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('259', '140223', '1402', '广灵县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('260', '140224', '1402', '灵丘县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('261', '140225', '1402', '浑源县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('262', '140226', '1402', '左云县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('263', '140227', '1402', '大同县', '3', '1', '0', '27', 'D');
INSERT INTO `my_pcd` VALUES ('264', '1403', '14', '阳泉市', '2', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('265', '140301', '1403', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('266', '140302', '1403', '城区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('267', '140303', '1403', '矿区', '3', '1', '0', '3', 'K');
INSERT INTO `my_pcd` VALUES ('268', '140311', '1403', '郊区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('269', '140321', '1403', '平定县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('270', '140322', '1403', '盂县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('271', '1404', '14', '长治市', '2', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('272', '140401', '1404', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('273', '140402', '1404', '长治市城区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('274', '140411', '1404', '长治市郊区', '3', '1', '0', '11', 'C');
INSERT INTO `my_pcd` VALUES ('275', '140421', '1404', '长治县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('276', '140423', '1404', '襄垣县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('277', '140424', '1404', '屯留县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('278', '140425', '1404', '平顺县', '3', '1', '0', '25', 'P');
INSERT INTO `my_pcd` VALUES ('279', '140426', '1404', '黎城县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('280', '140427', '1404', '壶关县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('281', '140428', '1404', '长子县', '3', '1', '0', '28', 'C');
INSERT INTO `my_pcd` VALUES ('282', '140429', '1404', '武乡县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('283', '140430', '1404', '沁县', '3', '1', '0', '30', 'Q');
INSERT INTO `my_pcd` VALUES ('284', '140431', '1404', '沁源县', '3', '1', '0', '31', 'Q');
INSERT INTO `my_pcd` VALUES ('285', '140481', '1404', '潞城市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('286', '1405', '14', '晋城市', '2', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('287', '140501', '1405', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('288', '140502', '1405', '晋城市城区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('289', '140521', '1405', '沁水县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('290', '140522', '1405', '阳城县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('291', '140524', '1405', '陵川县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('292', '140525', '1405', '泽州县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('293', '140581', '1405', '高平市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('294', '1406', '14', '朔州市', '2', '1', '0', '6', 'S');
INSERT INTO `my_pcd` VALUES ('295', '140601', '1406', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('296', '140602', '1406', '朔城区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('297', '140603', '1406', '平鲁区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('298', '140621', '1406', '山阴县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('299', '140622', '1406', '应县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('300', '140623', '1406', '右玉县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('301', '140624', '1406', '怀仁县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('302', '1407', '14', '晋中市', '2', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('303', '140701', '1407', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('304', '140702', '1407', '榆次区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('305', '140721', '1407', '榆社县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('306', '140722', '1407', '左权县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('307', '140723', '1407', '和顺县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('308', '140724', '1407', '昔阳县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('309', '140725', '1407', '寿阳县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('310', '140726', '1407', '太谷县', '3', '1', '0', '26', 'T');
INSERT INTO `my_pcd` VALUES ('311', '140727', '1407', '祁县', '3', '1', '0', '27', 'Q');
INSERT INTO `my_pcd` VALUES ('312', '140728', '1407', '平遥县', '3', '1', '0', '28', 'P');
INSERT INTO `my_pcd` VALUES ('313', '140729', '1407', '灵石县', '3', '1', '0', '29', 'L');
INSERT INTO `my_pcd` VALUES ('314', '140781', '1407', '介休市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('315', '1408', '14', '运城市', '2', '1', '0', '8', 'Y');
INSERT INTO `my_pcd` VALUES ('316', '140801', '1408', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('317', '140802', '1408', '盐湖区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('318', '140821', '1408', '临猗县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('319', '140822', '1408', '万荣县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('320', '140823', '1408', '闻喜县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('321', '140824', '1408', '稷山县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('322', '140825', '1408', '新绛县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('323', '140826', '1408', '绛县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('324', '140827', '1408', '垣曲县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('325', '140828', '1408', '夏县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('326', '140829', '1408', '平陆县', '3', '1', '0', '29', 'P');
INSERT INTO `my_pcd` VALUES ('327', '140830', '1408', '芮城县', '3', '1', '0', '30', 'Z');
INSERT INTO `my_pcd` VALUES ('328', '140881', '1408', '永济市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('329', '140882', '1408', '河津市', '3', '1', '0', '82', 'H');
INSERT INTO `my_pcd` VALUES ('330', '1409', '14', '忻州市', '2', '1', '0', '9', 'X');
INSERT INTO `my_pcd` VALUES ('331', '140901', '1409', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('332', '140902', '1409', '忻府区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('333', '140921', '1409', '定襄县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('334', '140922', '1409', '五台县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('335', '140923', '1409', '代县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('336', '140924', '1409', '繁峙县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('337', '140925', '1409', '宁武县', '3', '1', '0', '25', 'N');
INSERT INTO `my_pcd` VALUES ('338', '140926', '1409', '静乐县', '3', '1', '0', '26', 'J');
INSERT INTO `my_pcd` VALUES ('339', '140927', '1409', '神池县', '3', '1', '0', '27', 'S');
INSERT INTO `my_pcd` VALUES ('340', '140928', '1409', '五寨县', '3', '1', '0', '28', 'W');
INSERT INTO `my_pcd` VALUES ('341', '140929', '1409', '岢岚县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('342', '140930', '1409', '河曲县', '3', '1', '0', '30', 'H');
INSERT INTO `my_pcd` VALUES ('343', '140931', '1409', '保德县', '3', '1', '0', '31', 'B');
INSERT INTO `my_pcd` VALUES ('344', '140932', '1409', '偏关县', '3', '1', '0', '32', 'P');
INSERT INTO `my_pcd` VALUES ('345', '140981', '1409', '原平市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('346', '1410', '14', '临汾市', '2', '1', '0', '10', 'L');
INSERT INTO `my_pcd` VALUES ('347', '141001', '1410', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('348', '141002', '1410', '尧都区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('349', '141021', '1410', '曲沃县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('350', '141022', '1410', '翼城县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('351', '141023', '1410', '襄汾县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('352', '141024', '1410', '洪洞县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('353', '141025', '1410', '古县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('354', '141026', '1410', '安泽县', '3', '1', '0', '26', 'A');
INSERT INTO `my_pcd` VALUES ('355', '141027', '1410', '浮山县', '3', '1', '0', '27', 'F');
INSERT INTO `my_pcd` VALUES ('356', '141028', '1410', '吉县', '3', '1', '0', '28', 'J');
INSERT INTO `my_pcd` VALUES ('357', '141029', '1410', '乡宁县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('358', '141030', '1410', '大宁县', '3', '1', '0', '30', 'D');
INSERT INTO `my_pcd` VALUES ('359', '141031', '1410', '隰县', '3', '1', '0', '31', 'Z');
INSERT INTO `my_pcd` VALUES ('360', '141032', '1410', '永和县', '3', '1', '0', '32', 'Y');
INSERT INTO `my_pcd` VALUES ('361', '141033', '1410', '蒲县', '3', '1', '0', '33', 'P');
INSERT INTO `my_pcd` VALUES ('362', '141034', '1410', '汾西县', '3', '1', '0', '34', 'F');
INSERT INTO `my_pcd` VALUES ('363', '141081', '1410', '侯马市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('364', '141082', '1410', '霍州市', '3', '1', '0', '82', 'H');
INSERT INTO `my_pcd` VALUES ('365', '1411', '14', '吕梁市', '2', '1', '0', '11', 'L');
INSERT INTO `my_pcd` VALUES ('366', '141101', '1411', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('367', '141102', '1411', '离石区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('368', '141121', '1411', '文水县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('369', '141122', '1411', '交城县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('370', '141123', '1411', '兴县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('371', '141124', '1411', '临县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('372', '141125', '1411', '柳林县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('373', '141126', '1411', '石楼县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('374', '141127', '1411', '岚县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('375', '141128', '1411', '方山县', '3', '1', '0', '28', 'F');
INSERT INTO `my_pcd` VALUES ('376', '141129', '1411', '中阳县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('377', '141130', '1411', '交口县', '3', '1', '0', '30', 'J');
INSERT INTO `my_pcd` VALUES ('378', '141181', '1411', '孝义市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('379', '141182', '1411', '汾阳市', '3', '1', '0', '82', 'F');
INSERT INTO `my_pcd` VALUES ('380', '15', '0', '内蒙古自治区', '1', '1', '0', '15', 'N');
INSERT INTO `my_pcd` VALUES ('381', '1501', '15', '呼和浩特市', '2', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('382', '150101', '1501', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('383', '150102', '1501', '新城区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('384', '150103', '1501', '回民区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('385', '150104', '1501', '玉泉区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('386', '150105', '1501', '赛罕区', '3', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('387', '150121', '1501', '土左旗', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('388', '150122', '1501', '托克托县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('389', '150123', '1501', '和林格尔县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('390', '150124', '1501', '清水河县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('391', '150125', '1501', '武川县', '3', '1', '0', '25', 'W');
INSERT INTO `my_pcd` VALUES ('392', '1502', '15', '包头市', '2', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('393', '150201', '1502', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('394', '150202', '1502', '东河区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('395', '150203', '1502', '昆都仑区', '3', '1', '0', '3', 'K');
INSERT INTO `my_pcd` VALUES ('396', '150204', '1502', '青山区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('397', '150205', '1502', '石拐区', '3', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('398', '150206', '1502', '白云鄂博矿区', '3', '1', '0', '6', 'B');
INSERT INTO `my_pcd` VALUES ('399', '150207', '1502', '九原区', '3', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('400', '150221', '1502', '土默特右旗', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('401', '150222', '1502', '固阳县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('402', '150223', '1502', '达茂联合旗', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('403', '1503', '15', '乌海市', '2', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('404', '150301', '1503', '乌海市辖区', '3', '1', '0', '1', 'W');
INSERT INTO `my_pcd` VALUES ('405', '150302', '1503', '海勃湾区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('406', '150303', '1503', '海南区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('407', '150304', '1503', '乌达区', '3', '1', '0', '4', 'W');
INSERT INTO `my_pcd` VALUES ('408', '1504', '15', '赤峰市', '2', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('409', '150401', '1504', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('410', '150402', '1504', '红山区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('411', '150403', '1504', '元宝山区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('412', '150404', '1504', '松山区', '3', '1', '0', '4', 'S');
INSERT INTO `my_pcd` VALUES ('413', '150421', '1504', '阿鲁科尔沁旗', '3', '1', '0', '21', 'A');
INSERT INTO `my_pcd` VALUES ('414', '150422', '1504', '巴林左旗', '3', '1', '0', '22', 'B');
INSERT INTO `my_pcd` VALUES ('415', '150423', '1504', '巴林右旗', '3', '1', '0', '23', 'B');
INSERT INTO `my_pcd` VALUES ('416', '150424', '1504', '林西县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('417', '150425', '1504', '克什克腾旗', '3', '1', '0', '25', 'K');
INSERT INTO `my_pcd` VALUES ('418', '150426', '1504', '翁牛特旗', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('419', '150428', '1504', '喀喇沁旗', '3', '1', '0', '28', 'K');
INSERT INTO `my_pcd` VALUES ('420', '150429', '1504', '宁城县', '3', '1', '0', '29', 'N');
INSERT INTO `my_pcd` VALUES ('421', '150430', '1504', '敖汉旗', '3', '1', '0', '30', 'A');
INSERT INTO `my_pcd` VALUES ('422', '1505', '15', '通辽市', '2', '1', '0', '5', 'T');
INSERT INTO `my_pcd` VALUES ('423', '150501', '1505', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('424', '150502', '1505', '科尔沁区', '3', '1', '0', '2', 'K');
INSERT INTO `my_pcd` VALUES ('425', '150521', '1505', '科尔沁左翼中旗', '3', '1', '0', '21', 'K');
INSERT INTO `my_pcd` VALUES ('426', '150522', '1505', '科左后旗', '3', '1', '0', '22', 'K');
INSERT INTO `my_pcd` VALUES ('427', '150523', '1505', '开鲁县', '3', '1', '0', '23', 'K');
INSERT INTO `my_pcd` VALUES ('428', '150524', '1505', '库伦旗', '3', '1', '0', '24', 'K');
INSERT INTO `my_pcd` VALUES ('429', '150525', '1505', '奈曼旗', '3', '1', '0', '25', 'N');
INSERT INTO `my_pcd` VALUES ('430', '150526', '1505', '扎鲁特旗', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('431', '150581', '1505', '霍林郭勒市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('432', '1506', '15', '鄂尔多斯市', '2', '1', '0', '6', 'E');
INSERT INTO `my_pcd` VALUES ('433', '150602', '1506', '东胜区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('434', '150621', '1506', '达拉特旗', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('435', '150622', '1506', '准格尔旗', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('436', '150623', '1506', '鄂托克前旗', '3', '1', '0', '23', 'E');
INSERT INTO `my_pcd` VALUES ('437', '150624', '1506', '鄂托克旗', '3', '1', '0', '24', 'E');
INSERT INTO `my_pcd` VALUES ('438', '150625', '1506', '杭锦旗', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('439', '150626', '1506', '乌审旗', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('440', '150627', '1506', '伊金霍洛旗', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('441', '1507', '15', '呼伦贝尔市', '2', '1', '0', '7', 'H');
INSERT INTO `my_pcd` VALUES ('442', '150701', '1507', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('443', '150702', '1507', '海拉尔区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('444', '150721', '1507', '阿荣旗', '3', '1', '0', '21', 'A');
INSERT INTO `my_pcd` VALUES ('445', '150722', '1507', '莫力达瓦达斡尔族自治旗', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('446', '150723', '1507', '鄂伦春自治旗', '3', '1', '0', '23', 'E');
INSERT INTO `my_pcd` VALUES ('447', '150724', '1507', '鄂温克族自治旗', '3', '1', '0', '24', 'E');
INSERT INTO `my_pcd` VALUES ('448', '150725', '1507', '陈巴尔虎旗镇', '3', '1', '0', '25', 'C');
INSERT INTO `my_pcd` VALUES ('449', '150726', '1507', '新巴尔虎左旗', '3', '1', '0', '26', 'X');
INSERT INTO `my_pcd` VALUES ('450', '150727', '1507', '新巴尔虎右旗', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('451', '150781', '1507', '满洲里市', '3', '1', '0', '81', 'M');
INSERT INTO `my_pcd` VALUES ('452', '150782', '1507', '牙克石市', '3', '1', '0', '82', 'Y');
INSERT INTO `my_pcd` VALUES ('453', '150783', '1507', '扎兰屯市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('454', '150784', '1507', '额尔古纳市', '3', '1', '0', '84', 'E');
INSERT INTO `my_pcd` VALUES ('455', '150785', '1507', '根河市', '3', '1', '0', '85', 'G');
INSERT INTO `my_pcd` VALUES ('456', '1508', '15', '巴彦淖尔市', '2', '1', '0', '8', 'B');
INSERT INTO `my_pcd` VALUES ('457', '150801', '1508', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('458', '150802', '1508', '临河区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('459', '150821', '1508', '五原县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('460', '150822', '1508', '磴口县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('461', '150823', '1508', '乌拉特前旗', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('462', '150824', '1508', '乌拉特中旗', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('463', '150825', '1508', '乌拉特后旗', '3', '1', '0', '25', 'W');
INSERT INTO `my_pcd` VALUES ('464', '150826', '1508', '杭锦后旗', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('465', '1509', '15', '乌兰察布市', '2', '1', '0', '9', 'W');
INSERT INTO `my_pcd` VALUES ('466', '150901', '1509', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('467', '150902', '1509', '集宁区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('468', '150921', '1509', '卓资县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('469', '150922', '1509', '化德县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('470', '150923', '1509', '商都县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('471', '150924', '1509', '兴和县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('472', '150925', '1509', '凉城县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('473', '150926', '1509', '察哈尔右翼前旗', '3', '1', '0', '26', 'C');
INSERT INTO `my_pcd` VALUES ('474', '150927', '1509', '察右中旗', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('475', '150928', '1509', '察哈尔右翼后旗', '3', '1', '0', '28', 'C');
INSERT INTO `my_pcd` VALUES ('476', '150929', '1509', '四子王旗', '3', '1', '0', '29', 'S');
INSERT INTO `my_pcd` VALUES ('477', '150981', '1509', '丰镇市', '3', '1', '0', '81', 'F');
INSERT INTO `my_pcd` VALUES ('478', '1522', '15', '兴安盟', '2', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('479', '152201', '1522', '乌兰浩特市', '3', '1', '0', '1', 'W');
INSERT INTO `my_pcd` VALUES ('480', '152202', '1522', '阿尔山市', '3', '1', '0', '2', 'A');
INSERT INTO `my_pcd` VALUES ('481', '152221', '1522', '科右前旗', '3', '1', '0', '21', 'K');
INSERT INTO `my_pcd` VALUES ('482', '152222', '1522', '科右中旗', '3', '1', '0', '22', 'K');
INSERT INTO `my_pcd` VALUES ('483', '152223', '1522', '扎赉特旗', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('484', '152224', '1522', '突泉县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('485', '1525', '15', '锡林郭勒盟', '2', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('486', '152501', '1525', '二连浩特市', '3', '1', '0', '1', 'E');
INSERT INTO `my_pcd` VALUES ('487', '152502', '1525', '锡林浩特市', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('488', '152522', '1525', '阿巴嘎旗', '3', '1', '0', '22', 'A');
INSERT INTO `my_pcd` VALUES ('489', '152523', '1525', '苏尼特左旗', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('490', '152524', '1525', '苏尼特右旗', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('491', '152525', '1525', '东乌珠穆沁旗', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('492', '152526', '1525', '西乌珠穆沁旗', '3', '1', '0', '26', 'X');
INSERT INTO `my_pcd` VALUES ('493', '152527', '1525', '太仆寺旗', '3', '1', '0', '27', 'T');
INSERT INTO `my_pcd` VALUES ('494', '152528', '1525', '镶黄旗', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('495', '152529', '1525', '正镶白旗', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('496', '152530', '1525', '正蓝旗', '3', '1', '0', '30', 'Z');
INSERT INTO `my_pcd` VALUES ('497', '152531', '1525', '多伦县', '3', '1', '0', '31', 'D');
INSERT INTO `my_pcd` VALUES ('498', '1529', '15', '阿拉善盟', '2', '1', '0', '29', 'A');
INSERT INTO `my_pcd` VALUES ('499', '152921', '1529', '阿拉善左旗', '3', '1', '0', '21', 'A');
INSERT INTO `my_pcd` VALUES ('500', '152922', '1529', '阿拉善右旗', '3', '1', '0', '22', 'A');
INSERT INTO `my_pcd` VALUES ('501', '152923', '1529', '额济纳旗', '3', '1', '0', '23', 'E');
INSERT INTO `my_pcd` VALUES ('502', '21', '0', '辽宁省', '1', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('503', '2101', '21', '沈阳市', '2', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('504', '210101', '2101', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('505', '210102', '2101', '和平区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('506', '210103', '2101', '沈河区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('507', '210104', '2101', '大东区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('508', '210105', '2101', '皇姑区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('509', '210106', '2101', '铁西区', '3', '1', '0', '6', 'T');
INSERT INTO `my_pcd` VALUES ('510', '210111', '2101', '苏家屯区', '3', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('511', '210112', '2101', '东陵区', '3', '1', '0', '12', 'D');
INSERT INTO `my_pcd` VALUES ('512', '210113', '2101', '新城子区', '3', '1', '0', '13', 'X');
INSERT INTO `my_pcd` VALUES ('513', '210114', '2101', '于洪区', '3', '1', '0', '14', 'Y');
INSERT INTO `my_pcd` VALUES ('514', '210122', '2101', '辽中县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('515', '210123', '2101', '康平县', '3', '1', '0', '23', 'K');
INSERT INTO `my_pcd` VALUES ('516', '210124', '2101', '法库县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('517', '210181', '2101', '新民市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('518', '2102', '21', '大连市', '2', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('519', '210201', '2102', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('520', '210202', '2102', '中山区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('521', '210203', '2102', '西岗区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('522', '210204', '2102', '沙河口区', '3', '1', '0', '4', 'S');
INSERT INTO `my_pcd` VALUES ('523', '210211', '2102', '甘井子区', '3', '1', '0', '11', 'G');
INSERT INTO `my_pcd` VALUES ('524', '210212', '2102', '旅顺口区', '3', '1', '0', '12', 'L');
INSERT INTO `my_pcd` VALUES ('525', '210213', '2102', '金州区', '3', '1', '0', '13', 'J');
INSERT INTO `my_pcd` VALUES ('526', '210224', '2102', '长海县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('527', '210281', '2102', '瓦房店市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('528', '210282', '2102', '普兰店市', '3', '1', '0', '82', 'P');
INSERT INTO `my_pcd` VALUES ('529', '210283', '2102', '庄河市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('530', '2103', '21', '鞍山市', '2', '1', '0', '3', 'A');
INSERT INTO `my_pcd` VALUES ('531', '210301', '2103', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('532', '210302', '2103', '铁东区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('533', '210303', '2103', '铁西区', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('534', '210304', '2103', '立山区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('535', '210311', '2103', '千山区', '3', '1', '0', '11', 'Q');
INSERT INTO `my_pcd` VALUES ('536', '210321', '2103', '台安县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('537', '210323', '2103', '岫岩县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('538', '210381', '2103', '海城市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('539', '2104', '21', '抚顺市', '2', '1', '0', '4', 'F');
INSERT INTO `my_pcd` VALUES ('540', '210401', '2104', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('541', '210402', '2104', '新抚区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('542', '210403', '2104', '东洲区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('543', '210404', '2104', '望花区', '3', '1', '0', '4', 'W');
INSERT INTO `my_pcd` VALUES ('544', '210411', '2104', '顺城区', '3', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('545', '210421', '2104', '抚顺县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('546', '210422', '2104', '新宾满族自治县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('547', '210423', '2104', '清原满族自治县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('548', '2105', '21', '本溪市', '2', '1', '0', '5', 'B');
INSERT INTO `my_pcd` VALUES ('549', '210501', '2105', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('550', '210502', '2105', '平山区', '3', '1', '0', '2', 'P');
INSERT INTO `my_pcd` VALUES ('551', '210503', '2105', '溪湖区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('552', '210504', '2105', '明山区', '3', '1', '0', '4', 'M');
INSERT INTO `my_pcd` VALUES ('553', '210505', '2105', '南芬区', '3', '1', '0', '5', 'N');
INSERT INTO `my_pcd` VALUES ('554', '210521', '2105', '本溪满族自治县', '3', '1', '0', '21', 'B');
INSERT INTO `my_pcd` VALUES ('555', '210522', '2105', '桓仁满族自治县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('556', '2106', '21', '丹东市', '2', '1', '0', '6', 'D');
INSERT INTO `my_pcd` VALUES ('557', '210601', '2106', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('558', '210602', '2106', '元宝区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('559', '210603', '2106', '振兴区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('560', '210604', '2106', '振安区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('561', '210624', '2106', '宽甸满族自治县', '3', '1', '0', '24', 'K');
INSERT INTO `my_pcd` VALUES ('562', '210681', '2106', '东港市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('563', '210682', '2106', '凤城市', '3', '1', '0', '82', 'F');
INSERT INTO `my_pcd` VALUES ('564', '2107', '21', '锦州市', '2', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('565', '210701', '2107', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('566', '210702', '2107', '古塔区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('567', '210703', '2107', '凌河区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('568', '210711', '2107', '太和区', '3', '1', '0', '11', 'T');
INSERT INTO `my_pcd` VALUES ('569', '210726', '2107', '黑山县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('570', '210727', '2107', '义县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('571', '210781', '2107', '凌海市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('572', '210782', '2107', '北镇市', '3', '1', '0', '82', 'B');
INSERT INTO `my_pcd` VALUES ('573', '2108', '21', '营口市', '2', '1', '0', '8', 'Y');
INSERT INTO `my_pcd` VALUES ('574', '210801', '2108', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('575', '210802', '2108', '站前区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('576', '210803', '2108', '西市区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('577', '210804', '2108', '鲅鱼圈区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('578', '210811', '2108', '老边区', '3', '1', '0', '11', 'L');
INSERT INTO `my_pcd` VALUES ('579', '210881', '2108', '盖州市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('580', '210882', '2108', '大石桥市', '3', '1', '0', '82', 'D');
INSERT INTO `my_pcd` VALUES ('581', '2109', '21', '阜新市', '2', '1', '0', '9', 'F');
INSERT INTO `my_pcd` VALUES ('582', '210901', '2109', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('583', '210902', '2109', '海州区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('584', '210903', '2109', '新邱区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('585', '210904', '2109', '太平区', '3', '1', '0', '4', 'T');
INSERT INTO `my_pcd` VALUES ('586', '210905', '2109', '清河门区', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('587', '210911', '2109', '细河区', '3', '1', '0', '11', 'X');
INSERT INTO `my_pcd` VALUES ('588', '210921', '2109', '阜新蒙古族自治县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('589', '210922', '2109', '彰武县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('590', '2110', '21', '辽阳市', '2', '1', '0', '10', 'L');
INSERT INTO `my_pcd` VALUES ('591', '211001', '2110', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('592', '211002', '2110', '白塔区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('593', '211003', '2110', '文圣区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('594', '211004', '2110', '宏伟区', '3', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('595', '211005', '2110', '弓长岭区', '3', '1', '0', '5', 'G');
INSERT INTO `my_pcd` VALUES ('596', '211011', '2110', '太子河区', '3', '1', '0', '11', 'T');
INSERT INTO `my_pcd` VALUES ('597', '211021', '2110', '辽阳县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('598', '211081', '2110', '灯塔市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('599', '2111', '21', '盘锦市', '2', '1', '0', '11', 'P');
INSERT INTO `my_pcd` VALUES ('600', '211101', '2111', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('601', '211102', '2111', '双台子区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('602', '211103', '2111', '兴隆台区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('603', '211121', '2111', '大洼县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('604', '211122', '2111', '盘山县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('605', '2112', '21', '铁岭市', '2', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('606', '211201', '2112', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('607', '211202', '2112', '银州区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('608', '211204', '2112', '清河区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('609', '211221', '2112', '铁岭县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('610', '211223', '2112', '西丰县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('611', '211224', '2112', '昌图县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('612', '211281', '2112', '调兵山市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('613', '211282', '2112', '开原市', '3', '1', '0', '82', 'K');
INSERT INTO `my_pcd` VALUES ('614', '2113', '21', '朝阳市', '2', '1', '0', '13', 'C');
INSERT INTO `my_pcd` VALUES ('615', '211301', '2113', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('616', '211302', '2113', '双塔区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('617', '211303', '2113', '龙城区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('618', '211321', '2113', '朝阳县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('619', '211322', '2113', '建平县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('620', '211324', '2113', '喀喇沁左翼蒙古族自治县', '3', '1', '0', '24', 'K');
INSERT INTO `my_pcd` VALUES ('621', '211381', '2113', '北票市', '3', '1', '0', '81', 'B');
INSERT INTO `my_pcd` VALUES ('622', '211382', '2113', '凌源市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('623', '2114', '21', '葫芦岛市', '2', '1', '0', '14', 'H');
INSERT INTO `my_pcd` VALUES ('624', '211401', '2114', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('625', '211402', '2114', '连山区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('626', '211403', '2114', '龙港区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('627', '211404', '2114', '南票区', '3', '1', '0', '4', 'N');
INSERT INTO `my_pcd` VALUES ('628', '211421', '2114', '绥中县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('629', '211422', '2114', '建昌县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('630', '211481', '2114', '兴城市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('631', '22', '0', '吉林省', '1', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('632', '2201', '22', '长春市', '2', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('633', '220101', '2201', '长春市辖区', '3', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('634', '220102', '2201', '南关区', '3', '1', '0', '2', 'N');
INSERT INTO `my_pcd` VALUES ('635', '220103', '2201', '宽城区', '3', '1', '0', '3', 'K');
INSERT INTO `my_pcd` VALUES ('636', '220104', '2201', '朝阳区', '3', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('637', '220105', '2201', '二道区', '3', '1', '0', '5', 'E');
INSERT INTO `my_pcd` VALUES ('638', '220106', '2201', '绿园区', '3', '1', '0', '6', 'L');
INSERT INTO `my_pcd` VALUES ('639', '220112', '2201', '双阳区', '3', '1', '0', '12', 'S');
INSERT INTO `my_pcd` VALUES ('640', '220122', '2201', '农安县', '3', '1', '0', '22', 'N');
INSERT INTO `my_pcd` VALUES ('641', '220181', '2201', '九台市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('642', '220182', '2201', '榆树市', '3', '1', '0', '82', 'Y');
INSERT INTO `my_pcd` VALUES ('643', '220183', '2201', '德惠市', '3', '1', '0', '83', 'D');
INSERT INTO `my_pcd` VALUES ('644', '2202', '22', '吉林市', '2', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('645', '220201', '2202', '吉林市辖区', '3', '1', '0', '1', 'J');
INSERT INTO `my_pcd` VALUES ('646', '220202', '2202', '昌邑区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('647', '220203', '2202', '龙潭区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('648', '220204', '2202', '船营区', '3', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('649', '220211', '2202', '丰满区', '3', '1', '0', '11', 'F');
INSERT INTO `my_pcd` VALUES ('650', '220221', '2202', '永吉县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('651', '220281', '2202', '蛟河市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('652', '220282', '2202', '桦甸市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('653', '220283', '2202', '舒兰市', '3', '1', '0', '83', 'S');
INSERT INTO `my_pcd` VALUES ('654', '220284', '2202', '磐石市', '3', '1', '0', '84', 'P');
INSERT INTO `my_pcd` VALUES ('655', '2203', '22', '四平市', '2', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('656', '220301', '2203', '四平市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('657', '220302', '2203', '铁西区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('658', '220303', '2203', '铁东区', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('659', '220322', '2203', '梨树县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('660', '220323', '2203', '伊通满族自治县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('661', '220381', '2203', '公主岭市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('662', '220382', '2203', '双辽市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('663', '2204', '22', '辽源市', '2', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('664', '220401', '2204', '辽源市辖区', '3', '1', '0', '1', 'L');
INSERT INTO `my_pcd` VALUES ('665', '220402', '2204', '龙山区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('666', '220403', '2204', '西安区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('667', '220421', '2204', '东丰县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('668', '220422', '2204', '东辽县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('669', '2205', '22', '通化市', '2', '1', '0', '5', 'T');
INSERT INTO `my_pcd` VALUES ('670', '220501', '2205', '通化市辖区', '3', '1', '0', '1', 'T');
INSERT INTO `my_pcd` VALUES ('671', '220502', '2205', '东昌区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('672', '220503', '2205', '二道江区', '3', '1', '0', '3', 'E');
INSERT INTO `my_pcd` VALUES ('673', '220521', '2205', '通化县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('674', '220523', '2205', '辉南县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('675', '220524', '2205', '柳河县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('676', '220581', '2205', '梅河口市', '3', '1', '0', '81', 'M');
INSERT INTO `my_pcd` VALUES ('677', '220582', '2205', '集安市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('678', '2206', '22', '白山市', '2', '1', '0', '6', 'B');
INSERT INTO `my_pcd` VALUES ('679', '220601', '2206', '白山市辖区', '3', '1', '0', '1', 'B');
INSERT INTO `my_pcd` VALUES ('680', '220602', '2206', '八道江区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('681', '220604', '2206', '江源区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('682', '220621', '2206', '抚松县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('683', '220622', '2206', '靖宇县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('684', '220623', '2206', '长白朝鲜族自治县', '3', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('685', '220681', '2206', '临江市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('686', '2207', '22', '松原市', '2', '1', '0', '7', 'S');
INSERT INTO `my_pcd` VALUES ('687', '220701', '2207', '松原市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('688', '220702', '2207', '宁江区', '3', '1', '0', '2', 'N');
INSERT INTO `my_pcd` VALUES ('689', '220721', '2207', '前郭尔罗斯蒙古族自治县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('690', '220722', '2207', '长岭县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('691', '220723', '2207', '乾安县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('692', '220724', '2207', '扶余县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('693', '2208', '22', '白城市', '2', '1', '0', '8', 'B');
INSERT INTO `my_pcd` VALUES ('694', '220801', '2208', '白城市辖区', '3', '1', '0', '1', 'B');
INSERT INTO `my_pcd` VALUES ('695', '220802', '2208', '洮北区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('696', '220821', '2208', '镇赉县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('697', '220822', '2208', '通榆县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('698', '220881', '2208', '洮南市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('699', '220882', '2208', '大安市', '3', '1', '0', '82', 'D');
INSERT INTO `my_pcd` VALUES ('700', '2224', '22', '延边朝鲜族自治州', '2', '1', '0', '24', 'Y');
INSERT INTO `my_pcd` VALUES ('701', '222401', '2224', '延吉市', '3', '1', '0', '1', 'Y');
INSERT INTO `my_pcd` VALUES ('702', '222402', '2224', '图们市', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('703', '222403', '2224', '敦化市', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('704', '222404', '2224', '珲春市', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('705', '222405', '2224', '龙井市', '3', '1', '0', '5', 'L');
INSERT INTO `my_pcd` VALUES ('706', '222406', '2224', '和龙市', '3', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('707', '222424', '2224', '汪清县', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('708', '222426', '2224', '安图县', '3', '1', '0', '26', 'A');
INSERT INTO `my_pcd` VALUES ('709', '23', '0', '黑龙江省', '1', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('710', '2301', '23', '哈尔滨市', '2', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('711', '230101', '2301', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('712', '230102', '2301', '道里区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('713', '230103', '2301', '南岗区', '3', '1', '0', '3', 'N');
INSERT INTO `my_pcd` VALUES ('714', '230104', '2301', '道外区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('715', '230108', '2301', '平房区', '3', '1', '0', '8', 'P');
INSERT INTO `my_pcd` VALUES ('716', '230109', '2301', '松北区', '3', '1', '0', '9', 'S');
INSERT INTO `my_pcd` VALUES ('717', '230110', '2301', '香坊区', '3', '1', '0', '10', 'X');
INSERT INTO `my_pcd` VALUES ('718', '230111', '2301', '呼兰区', '3', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('719', '230112', '2301', '阿城区', '3', '1', '0', '12', 'A');
INSERT INTO `my_pcd` VALUES ('720', '230123', '2301', '依兰县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('721', '230124', '2301', '方正县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('722', '230125', '2301', '宾县', '3', '1', '0', '25', 'B');
INSERT INTO `my_pcd` VALUES ('723', '230126', '2301', '巴彦县', '3', '1', '0', '26', 'B');
INSERT INTO `my_pcd` VALUES ('724', '230127', '2301', '木兰县', '3', '1', '0', '27', 'M');
INSERT INTO `my_pcd` VALUES ('725', '230128', '2301', '通河县', '3', '1', '0', '28', 'T');
INSERT INTO `my_pcd` VALUES ('726', '230129', '2301', '延寿县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('727', '230182', '2301', '双城市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('728', '230183', '2301', '尚志市', '3', '1', '0', '83', 'S');
INSERT INTO `my_pcd` VALUES ('729', '230184', '2301', '五常市', '3', '1', '0', '84', 'W');
INSERT INTO `my_pcd` VALUES ('730', '2302', '23', '齐齐哈尔市', '2', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('731', '230201', '2302', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('732', '230202', '2302', '龙沙区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('733', '230203', '2302', '建华区', '3', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('734', '230204', '2302', '铁锋区', '3', '1', '0', '4', 'T');
INSERT INTO `my_pcd` VALUES ('735', '230205', '2302', '昂昂溪区', '3', '1', '0', '5', 'A');
INSERT INTO `my_pcd` VALUES ('736', '230206', '2302', '富拉尔基区', '3', '1', '0', '6', 'F');
INSERT INTO `my_pcd` VALUES ('737', '230207', '2302', '碾子山区', '3', '1', '0', '7', 'N');
INSERT INTO `my_pcd` VALUES ('738', '230208', '2302', '梅里斯达斡尔族区', '3', '1', '0', '8', 'M');
INSERT INTO `my_pcd` VALUES ('739', '230221', '2302', '龙江县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('740', '230223', '2302', '依安县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('741', '230224', '2302', '泰来县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('742', '230225', '2302', '甘南县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('743', '230227', '2302', '富裕县', '3', '1', '0', '27', 'F');
INSERT INTO `my_pcd` VALUES ('744', '230229', '2302', '克山县', '3', '1', '0', '29', 'K');
INSERT INTO `my_pcd` VALUES ('745', '230230', '2302', '克东县', '3', '1', '0', '30', 'K');
INSERT INTO `my_pcd` VALUES ('746', '230231', '2302', '拜泉县', '3', '1', '0', '31', 'B');
INSERT INTO `my_pcd` VALUES ('747', '230281', '2302', '讷河市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('748', '2303', '23', '鸡西市', '2', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('749', '230301', '2303', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('750', '230302', '2303', '鸡冠区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('751', '230303', '2303', '恒山区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('752', '230304', '2303', '滴道区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('753', '230305', '2303', '梨树区', '3', '1', '0', '5', 'L');
INSERT INTO `my_pcd` VALUES ('754', '230306', '2303', '城子河区', '3', '1', '0', '6', 'C');
INSERT INTO `my_pcd` VALUES ('755', '230307', '2303', '麻山区', '3', '1', '0', '7', 'M');
INSERT INTO `my_pcd` VALUES ('756', '230321', '2303', '鸡东县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('757', '230381', '2303', '虎林市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('758', '230382', '2303', '密山市', '3', '1', '0', '82', 'M');
INSERT INTO `my_pcd` VALUES ('759', '2304', '23', '鹤岗市', '2', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('760', '230401', '2304', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('761', '230402', '2304', '向阳区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('762', '230403', '2304', '工农区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('763', '230404', '2304', '南山区', '3', '1', '0', '4', 'N');
INSERT INTO `my_pcd` VALUES ('764', '230405', '2304', '兴安区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('765', '230406', '2304', '东山区', '3', '1', '0', '6', 'D');
INSERT INTO `my_pcd` VALUES ('766', '230407', '2304', '兴山区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('767', '230421', '2304', '萝北县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('768', '230422', '2304', '绥滨县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('769', '2305', '23', '双鸭山市', '2', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('770', '230501', '2305', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('771', '230502', '2305', '尖山区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('772', '230503', '2305', '岭东区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('773', '230505', '2305', '四方台区', '3', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('774', '230506', '2305', '宝山区', '3', '1', '0', '6', 'B');
INSERT INTO `my_pcd` VALUES ('775', '230521', '2305', '集贤县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('776', '230522', '2305', '友谊县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('777', '230523', '2305', '宝清县', '3', '1', '0', '23', 'B');
INSERT INTO `my_pcd` VALUES ('778', '230524', '2305', '饶河县', '3', '1', '0', '24', 'R');
INSERT INTO `my_pcd` VALUES ('779', '2306', '23', '大庆市', '2', '1', '0', '6', 'D');
INSERT INTO `my_pcd` VALUES ('780', '230601', '2306', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('781', '230602', '2306', '萨尔图区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('782', '230603', '2306', '龙凤区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('783', '230604', '2306', '让胡路区', '3', '1', '0', '4', 'R');
INSERT INTO `my_pcd` VALUES ('784', '230605', '2306', '红岗区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('785', '230606', '2306', '大同区', '3', '1', '0', '6', 'D');
INSERT INTO `my_pcd` VALUES ('786', '230621', '2306', '肇州县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('787', '230622', '2306', '肇源县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('788', '230623', '2306', '林甸县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('789', '230624', '2306', '杜尔伯特县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('790', '2307', '23', '伊春市', '2', '1', '0', '7', 'Y');
INSERT INTO `my_pcd` VALUES ('791', '230701', '2307', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('792', '230702', '2307', '伊春区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('793', '230703', '2307', '南岔区', '3', '1', '0', '3', 'N');
INSERT INTO `my_pcd` VALUES ('794', '230704', '2307', '友好区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('795', '230705', '2307', '西林区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('796', '230706', '2307', '翠峦区', '3', '1', '0', '6', 'C');
INSERT INTO `my_pcd` VALUES ('797', '230707', '2307', '新青区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('798', '230708', '2307', '美溪区', '3', '1', '0', '8', 'M');
INSERT INTO `my_pcd` VALUES ('799', '230709', '2307', '金山屯区', '3', '1', '0', '9', 'J');
INSERT INTO `my_pcd` VALUES ('800', '230710', '2307', '五营区', '3', '1', '0', '10', 'W');
INSERT INTO `my_pcd` VALUES ('801', '230711', '2307', '乌马河区', '3', '1', '0', '11', 'W');
INSERT INTO `my_pcd` VALUES ('802', '230712', '2307', '汤旺河区', '3', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('803', '230713', '2307', '带岭区', '3', '1', '0', '13', 'D');
INSERT INTO `my_pcd` VALUES ('804', '230714', '2307', '乌伊岭区', '3', '1', '0', '14', 'W');
INSERT INTO `my_pcd` VALUES ('805', '230715', '2307', '红星区', '3', '1', '0', '15', 'H');
INSERT INTO `my_pcd` VALUES ('806', '230716', '2307', '上甘岭区', '3', '1', '0', '16', 'S');
INSERT INTO `my_pcd` VALUES ('807', '230722', '2307', '嘉荫县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('808', '230781', '2307', '铁力市', '3', '1', '0', '81', 'T');
INSERT INTO `my_pcd` VALUES ('809', '2308', '23', '佳木斯市', '2', '1', '0', '8', 'J');
INSERT INTO `my_pcd` VALUES ('810', '230801', '2308', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('811', '230803', '2308', '向阳区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('812', '230804', '2308', '前进区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('813', '230805', '2308', '东风区', '3', '1', '0', '5', 'D');
INSERT INTO `my_pcd` VALUES ('814', '230811', '2308', '郊区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('815', '230822', '2308', '桦南县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('816', '230826', '2308', '桦川县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('817', '230828', '2308', '汤原县', '3', '1', '0', '28', 'T');
INSERT INTO `my_pcd` VALUES ('818', '230833', '2308', '抚远县', '3', '1', '0', '33', 'F');
INSERT INTO `my_pcd` VALUES ('819', '230881', '2308', '同江市', '3', '1', '0', '81', 'T');
INSERT INTO `my_pcd` VALUES ('820', '230882', '2308', '富锦市', '3', '1', '0', '82', 'F');
INSERT INTO `my_pcd` VALUES ('821', '2309', '23', '七台河市', '2', '1', '0', '9', 'Q');
INSERT INTO `my_pcd` VALUES ('822', '230901', '2309', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('823', '230902', '2309', '新兴区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('824', '230903', '2309', '桃山区', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('825', '230904', '2309', '茄子河区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('826', '230921', '2309', '勃利县', '3', '1', '0', '21', 'B');
INSERT INTO `my_pcd` VALUES ('827', '2310', '23', '牡丹江市', '2', '1', '0', '10', 'M');
INSERT INTO `my_pcd` VALUES ('828', '231001', '2310', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('829', '231002', '2310', '东安区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('830', '231003', '2310', '阳明区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('831', '231004', '2310', '爱民区', '3', '1', '0', '4', 'A');
INSERT INTO `my_pcd` VALUES ('832', '231005', '2310', '西安区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('833', '231024', '2310', '东宁县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('834', '231025', '2310', '林口县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('835', '231081', '2310', '绥芬河市', '3', '1', '0', '81', 'S');
INSERT INTO `my_pcd` VALUES ('836', '231083', '2310', '海林市', '3', '1', '0', '83', 'H');
INSERT INTO `my_pcd` VALUES ('837', '231084', '2310', '宁安市', '3', '1', '0', '84', 'N');
INSERT INTO `my_pcd` VALUES ('838', '231085', '2310', '穆棱市', '3', '1', '0', '85', 'M');
INSERT INTO `my_pcd` VALUES ('839', '2311', '23', '黑河市', '2', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('840', '231101', '2311', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('841', '231102', '2311', '爱辉区', '3', '1', '0', '2', 'A');
INSERT INTO `my_pcd` VALUES ('842', '231121', '2311', '嫩江县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('843', '231123', '2311', '逊克县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('844', '231124', '2311', '孙吴县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('845', '231181', '2311', '北安市', '3', '1', '0', '81', 'B');
INSERT INTO `my_pcd` VALUES ('846', '231182', '2311', '五大连池市', '3', '1', '0', '82', 'W');
INSERT INTO `my_pcd` VALUES ('847', '2312', '23', '绥化市', '2', '1', '0', '12', 'S');
INSERT INTO `my_pcd` VALUES ('848', '231201', '2312', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('849', '231202', '2312', '北林区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('850', '231221', '2312', '望奎县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('851', '231222', '2312', '兰西县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('852', '231223', '2312', '青冈县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('853', '231224', '2312', '庆安县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('854', '231225', '2312', '明水县', '3', '1', '0', '25', 'M');
INSERT INTO `my_pcd` VALUES ('855', '231226', '2312', '绥棱县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('856', '231281', '2312', '安达市', '3', '1', '0', '81', 'A');
INSERT INTO `my_pcd` VALUES ('857', '231282', '2312', '肇东市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('858', '231283', '2312', '海伦市', '3', '1', '0', '83', 'H');
INSERT INTO `my_pcd` VALUES ('859', '2327', '23', '大兴安岭地区', '2', '1', '0', '27', 'D');
INSERT INTO `my_pcd` VALUES ('860', '232701', '2327', '加格达奇区', '3', '1', '0', '1', 'J');
INSERT INTO `my_pcd` VALUES ('861', '232702', '2327', '松岭区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('862', '232703', '2327', '新林区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('863', '232704', '2327', '呼中区', '3', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('864', '232721', '2327', '呼玛县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('865', '232722', '2327', '塔河县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('866', '232723', '2327', '漠河县', '3', '1', '0', '23', 'M');
INSERT INTO `my_pcd` VALUES ('867', '31', '0', '上海市', '1', '1', '0', '31', 'S');
INSERT INTO `my_pcd` VALUES ('868', '3101', '31', '市辖区', '2', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('869', '310101', '3101', '黄浦区', '3', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('870', '310103', '3101', '卢湾区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('871', '310104', '3101', '徐汇区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('872', '310105', '3101', '长宁区', '3', '1', '0', '5', 'C');
INSERT INTO `my_pcd` VALUES ('873', '310106', '3101', '静安区', '3', '1', '0', '6', 'J');
INSERT INTO `my_pcd` VALUES ('874', '310107', '3101', '普陀区', '3', '1', '0', '7', 'P');
INSERT INTO `my_pcd` VALUES ('875', '310108', '3101', '闸北区', '3', '1', '0', '8', 'Z');
INSERT INTO `my_pcd` VALUES ('876', '310109', '3101', '虹口区', '3', '1', '0', '9', 'H');
INSERT INTO `my_pcd` VALUES ('877', '310110', '3101', '杨浦区', '3', '1', '0', '10', 'Y');
INSERT INTO `my_pcd` VALUES ('878', '310112', '3101', '闵行区', '3', '1', '0', '12', 'Z');
INSERT INTO `my_pcd` VALUES ('879', '310113', '3101', '宝山区', '3', '1', '0', '13', 'B');
INSERT INTO `my_pcd` VALUES ('880', '310114', '3101', '嘉定区', '3', '1', '0', '14', 'J');
INSERT INTO `my_pcd` VALUES ('881', '310115', '3101', '浦东新区', '3', '1', '0', '15', 'P');
INSERT INTO `my_pcd` VALUES ('882', '310116', '3101', '金山区', '3', '1', '0', '16', 'J');
INSERT INTO `my_pcd` VALUES ('883', '310117', '3101', '松江区', '3', '1', '0', '17', 'S');
INSERT INTO `my_pcd` VALUES ('884', '310118', '3101', '青浦区', '3', '1', '0', '18', 'Q');
INSERT INTO `my_pcd` VALUES ('885', '310119', '3101', '南汇区', '3', '1', '0', '19', 'N');
INSERT INTO `my_pcd` VALUES ('886', '310120', '3101', '奉贤区', '3', '1', '0', '20', 'F');
INSERT INTO `my_pcd` VALUES ('887', '3102', '31', '县', '2', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('888', '310230', '3102', '崇明县', '3', '1', '0', '30', 'C');
INSERT INTO `my_pcd` VALUES ('889', '32', '0', '江苏省', '1', '1', '0', '32', 'J');
INSERT INTO `my_pcd` VALUES ('890', '3201', '32', '南京市', '2', '1', '0', '1', 'N');
INSERT INTO `my_pcd` VALUES ('891', '320101', '3201', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('892', '320102', '3201', '玄武区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('893', '320103', '3201', '白下区', '3', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('894', '320104', '3201', '秦淮区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('895', '320105', '3201', '建邺区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('896', '320106', '3201', '鼓楼区', '3', '1', '0', '6', 'G');
INSERT INTO `my_pcd` VALUES ('897', '320107', '3201', '下关区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('898', '320111', '3201', '浦口区', '3', '1', '0', '11', 'P');
INSERT INTO `my_pcd` VALUES ('899', '320113', '3201', '栖霞区', '3', '1', '0', '13', 'Q');
INSERT INTO `my_pcd` VALUES ('900', '320114', '3201', '雨花台区', '3', '1', '0', '14', 'Y');
INSERT INTO `my_pcd` VALUES ('901', '320115', '3201', '江宁区', '3', '1', '0', '15', 'J');
INSERT INTO `my_pcd` VALUES ('902', '320116', '3201', '六合区', '3', '1', '0', '16', 'L');
INSERT INTO `my_pcd` VALUES ('903', '320124', '3201', '溧水县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('904', '320125', '3201', '高淳县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('905', '3202', '32', '无锡市', '2', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('906', '320201', '3202', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('907', '320202', '3202', '崇安区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('908', '320203', '3202', '南长区', '3', '1', '0', '3', 'N');
INSERT INTO `my_pcd` VALUES ('909', '320204', '3202', '北塘区', '3', '1', '0', '4', 'B');
INSERT INTO `my_pcd` VALUES ('910', '320205', '3202', '锡山区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('911', '320206', '3202', '惠山区', '3', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('912', '320211', '3202', '滨湖区', '3', '1', '0', '11', 'B');
INSERT INTO `my_pcd` VALUES ('913', '320281', '3202', '江阴市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('914', '320282', '3202', '宜兴市', '3', '1', '0', '82', 'Y');
INSERT INTO `my_pcd` VALUES ('915', '3203', '32', '徐州市', '2', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('916', '320301', '3203', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('917', '320302', '3203', '鼓楼区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('918', '320303', '3203', '云龙区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('919', '320304', '3203', '九里区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('920', '320305', '3203', '贾汪区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('921', '320311', '3203', '泉山区', '3', '1', '0', '11', 'Q');
INSERT INTO `my_pcd` VALUES ('922', '320321', '3203', '丰县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('923', '320322', '3203', '沛县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('924', '320323', '3203', '铜山县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('925', '320324', '3203', '睢宁县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('926', '320381', '3203', '新沂市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('927', '320382', '3203', '邳州市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('928', '3204', '32', '常州市', '2', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('929', '320401', '3204', '常州市区', '3', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('930', '320402', '3204', '天宁区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('931', '320404', '3204', '钟楼区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('932', '320405', '3204', '戚墅堰区', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('933', '320411', '3204', '新北区', '3', '1', '0', '11', 'X');
INSERT INTO `my_pcd` VALUES ('934', '320412', '3204', '武进区', '3', '1', '0', '12', 'W');
INSERT INTO `my_pcd` VALUES ('935', '320481', '3204', '溧阳市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('936', '320482', '3204', '金坛市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('937', '3205', '32', '苏州市', '2', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('938', '320501', '3205', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('939', '320502', '3205', '沧浪区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('940', '320503', '3205', '平江区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('941', '320504', '3205', '金阊区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('942', '320505', '3205', '苏州高新区虎丘区', '3', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('943', '320506', '3205', '吴中区', '3', '1', '0', '6', 'W');
INSERT INTO `my_pcd` VALUES ('944', '320507', '3205', '相城区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('945', '320581', '3205', '常熟市', '3', '1', '0', '81', 'C');
INSERT INTO `my_pcd` VALUES ('946', '320582', '3205', '张家港市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('947', '320583', '3205', '昆山市', '3', '1', '0', '83', 'K');
INSERT INTO `my_pcd` VALUES ('948', '320584', '3205', '吴江市', '3', '1', '0', '84', 'W');
INSERT INTO `my_pcd` VALUES ('949', '320585', '3205', '太仓市', '3', '1', '0', '85', 'T');
INSERT INTO `my_pcd` VALUES ('950', '3206', '32', '南通市', '2', '1', '0', '6', 'N');
INSERT INTO `my_pcd` VALUES ('951', '320601', '3206', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('952', '320602', '3206', '崇川区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('953', '320611', '3206', '港闸区', '3', '1', '0', '11', 'G');
INSERT INTO `my_pcd` VALUES ('954', '320621', '3206', '海安县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('955', '320623', '3206', '如东', '3', '1', '0', '23', 'R');
INSERT INTO `my_pcd` VALUES ('956', '320681', '3206', '启东市', '3', '1', '0', '81', 'Q');
INSERT INTO `my_pcd` VALUES ('957', '320682', '3206', '\"如皋市', '0', '1', '0', '82', '');
INSERT INTO `my_pcd` VALUES ('958', '320682100', '320682', '\"如城镇', '0', '1', '0', '0', '');
INSERT INTO `my_pcd` VALUES ('959', '320682101', '320682', '\"柴湾镇', '0', '1', '0', '1', '');
INSERT INTO `my_pcd` VALUES ('960', '320682102', '320682', '\"雪岸镇', '0', '1', '0', '2', '');
INSERT INTO `my_pcd` VALUES ('961', '320682103', '320682', '\"东陈镇', '0', '1', '0', '3', '');
INSERT INTO `my_pcd` VALUES ('962', '320682104', '320682', '\"丁堰镇', '0', '1', '0', '4', '');
INSERT INTO `my_pcd` VALUES ('963', '320682105', '320682', '\"白蒲镇', '0', '1', '0', '5', '');
INSERT INTO `my_pcd` VALUES ('964', '320682106', '320682', '\"林梓镇', '0', '1', '0', '6', '');
INSERT INTO `my_pcd` VALUES ('965', '320682107', '320682', '\"下原镇', '0', '1', '0', '7', '');
INSERT INTO `my_pcd` VALUES ('966', '320682108', '320682', '\"九华镇', '0', '1', '0', '8', '');
INSERT INTO `my_pcd` VALUES ('967', '320682109', '320682', '\"郭园镇', '0', '1', '0', '9', '');
INSERT INTO `my_pcd` VALUES ('968', '320682110', '320682', '\"石庄镇', '0', '1', '0', '10', '');
INSERT INTO `my_pcd` VALUES ('969', '320682111', '320682', '\"长江镇', '0', '1', '0', '11', '');
INSERT INTO `my_pcd` VALUES ('970', '320682112', '320682', '\"吴窑镇', '0', '1', '0', '12', '');
INSERT INTO `my_pcd` VALUES ('971', '320682113', '320682', '\"江安镇', '0', '1', '0', '13', '');
INSERT INTO `my_pcd` VALUES ('972', '320682114', '320682', '\"高明镇', '0', '1', '0', '14', '');
INSERT INTO `my_pcd` VALUES ('973', '320682115', '320682', '\"常青镇', '0', '1', '0', '15', '');
INSERT INTO `my_pcd` VALUES ('974', '320682116', '320682', '\"搬经镇', '0', '1', '0', '16', '');
INSERT INTO `my_pcd` VALUES ('975', '320682117', '320682', '\"磨头镇', '0', '1', '0', '17', '');
INSERT INTO `my_pcd` VALUES ('976', '320682118', '320682', '\"桃园镇', '0', '1', '0', '18', '');
INSERT INTO `my_pcd` VALUES ('977', '320682119', '320682', '\"袁桥镇', '0', '1', '0', '19', '');
INSERT INTO `my_pcd` VALUES ('978', '320682401', '320682', '\"如皋港开发区', '0', '1', '0', '1', '');
INSERT INTO `my_pcd` VALUES ('979', '320682403', '320682', '\"如皋市蚕种场', '0', '1', '0', '3', '');
INSERT INTO `my_pcd` VALUES ('980', '320682404', '320682', '\"如皋市良种场', '0', '1', '0', '4', '');
INSERT INTO `my_pcd` VALUES ('981', '320682406', '320682', '\"如皋市种猪场', '0', '1', '0', '6', '');
INSERT INTO `my_pcd` VALUES ('982', '320682407', '320682', '\"如皋市农科所', '0', '1', '0', '7', '');
INSERT INTO `my_pcd` VALUES ('983', '320683', '3206', '通州市', '3', '1', '0', '83', 'T');
INSERT INTO `my_pcd` VALUES ('984', '320684', '3206', '海门市', '3', '1', '0', '84', 'H');
INSERT INTO `my_pcd` VALUES ('985', '3207', '32', '连云港市', '2', '1', '0', '7', 'L');
INSERT INTO `my_pcd` VALUES ('986', '320701', '3207', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('987', '320703', '3207', '连云区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('988', '320705', '3207', '新浦区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('989', '320706', '3207', '海州区', '3', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('990', '320721', '3207', '赣榆县', '3', '1', '0', '21', 'G');
INSERT INTO `my_pcd` VALUES ('991', '320722', '3207', '东海县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('992', '320723', '3207', '灌云县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('993', '320724', '3207', '灌南县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('994', '3208', '32', '淮安市', '2', '1', '0', '8', 'H');
INSERT INTO `my_pcd` VALUES ('995', '320801', '3208', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('996', '320802', '3208', '清河区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('997', '320803', '3208', '楚州区', '3', '1', '0', '3', 'C');
INSERT INTO `my_pcd` VALUES ('998', '320804', '3208', '淮阴区', '3', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('999', '320811', '3208', '清浦区', '3', '1', '0', '11', 'Q');
INSERT INTO `my_pcd` VALUES ('1000', '320826', '3208', '涟水县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('1001', '320829', '3208', '洪泽县', '3', '1', '0', '29', 'H');
INSERT INTO `my_pcd` VALUES ('1002', '320830', '3208', '盱眙县', '3', '1', '0', '30', 'Z');
INSERT INTO `my_pcd` VALUES ('1003', '320831', '3208', '金湖县', '3', '1', '0', '31', 'J');
INSERT INTO `my_pcd` VALUES ('1004', '3209', '32', '盐城市', '2', '1', '0', '9', 'Y');
INSERT INTO `my_pcd` VALUES ('1005', '320901', '3209', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1006', '320902', '3209', '亭湖区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('1007', '320903', '3209', '盐都区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('1008', '320921', '3209', '响水县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('1009', '320922', '3209', '滨海县', '3', '1', '0', '22', 'B');
INSERT INTO `my_pcd` VALUES ('1010', '320923', '3209', '阜宁县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('1011', '320924', '3209', '射阳县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1012', '320925', '3209', '建湖县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('1013', '320981', '3209', '东台市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('1014', '320982', '3209', '大丰市', '3', '1', '0', '82', 'D');
INSERT INTO `my_pcd` VALUES ('1015', '3210', '32', '扬州市', '2', '1', '0', '10', 'Y');
INSERT INTO `my_pcd` VALUES ('1016', '321001', '3210', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1017', '321002', '3210', '广陵区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('1018', '321003', '3210', '邗江区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1019', '321011', '3210', '维扬区', '3', '1', '0', '11', 'W');
INSERT INTO `my_pcd` VALUES ('1020', '321023', '3210', '宝应县', '3', '1', '0', '23', 'B');
INSERT INTO `my_pcd` VALUES ('1021', '321081', '3210', '仪征市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1022', '321084', '3210', '高邮市', '3', '1', '0', '84', 'G');
INSERT INTO `my_pcd` VALUES ('1023', '321088', '3210', '江都市', '3', '1', '0', '88', 'J');
INSERT INTO `my_pcd` VALUES ('1024', '3211', '32', '镇江市', '2', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('1025', '321101', '3211', '市区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1026', '321102', '3211', '京口区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1027', '321111', '3211', '润州区', '3', '1', '0', '11', 'R');
INSERT INTO `my_pcd` VALUES ('1028', '321112', '3211', '丹徒区', '3', '1', '0', '12', 'D');
INSERT INTO `my_pcd` VALUES ('1029', '321181', '3211', '丹阳市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('1030', '321182', '3211', '扬中市', '3', '1', '0', '82', 'Y');
INSERT INTO `my_pcd` VALUES ('1031', '321183', '3211', '句容市', '3', '1', '0', '83', 'J');
INSERT INTO `my_pcd` VALUES ('1032', '3212', '32', '泰州市', '2', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('1033', '321201', '3212', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1034', '321202', '3212', '海陵区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1035', '321203', '3212', '高港区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('1036', '321281', '3212', '兴化市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('1037', '321282', '3212', '靖江市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('1038', '321283', '3212', '泰兴市', '3', '1', '0', '83', 'T');
INSERT INTO `my_pcd` VALUES ('1039', '321284', '3212', '姜堰市', '3', '1', '0', '84', 'J');
INSERT INTO `my_pcd` VALUES ('1040', '3213', '32', '宿迁市', '2', '1', '0', '13', 'S');
INSERT INTO `my_pcd` VALUES ('1041', '321301', '3213', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1042', '321302', '3213', '宿城区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('1043', '321311', '3213', '宿豫区', '3', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('1044', '321322', '3213', '沭阳县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1045', '321323', '3213', '泗阳县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1046', '321324', '3213', '泗洪县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1047', '33', '0', '浙江省', '1', '1', '0', '33', 'Z');
INSERT INTO `my_pcd` VALUES ('1048', '3301', '33', '杭州市', '2', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('1049', '330101', '3301', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1050', '330102', '3301', '上城区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('1051', '330103', '3301', '下城区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('1052', '330104', '3301', '江干区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('1053', '330105', '3301', '拱墅区', '3', '1', '0', '5', 'G');
INSERT INTO `my_pcd` VALUES ('1054', '330106', '3301', '西湖区', '3', '1', '0', '6', 'X');
INSERT INTO `my_pcd` VALUES ('1055', '330108', '3301', '滨江区', '3', '1', '0', '8', 'B');
INSERT INTO `my_pcd` VALUES ('1056', '330109', '3301', '萧山区', '3', '1', '0', '9', 'X');
INSERT INTO `my_pcd` VALUES ('1057', '330110', '3301', '余杭区', '3', '1', '0', '10', 'Y');
INSERT INTO `my_pcd` VALUES ('1058', '330122', '3301', '桐庐县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('1059', '330127', '3301', '淳安县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('1060', '330182', '3301', '建德市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('1061', '330183', '3301', '富阳市', '3', '1', '0', '83', 'F');
INSERT INTO `my_pcd` VALUES ('1062', '330185', '3301', '临安市', '3', '1', '0', '85', 'L');
INSERT INTO `my_pcd` VALUES ('1063', '3302', '33', '宁波市', '2', '1', '0', '2', 'N');
INSERT INTO `my_pcd` VALUES ('1064', '330201', '3302', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1065', '330203', '3302', '海曙区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1066', '330204', '3302', '江东区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('1067', '330205', '3302', '江北区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('1068', '330206', '3302', '北仑区', '3', '1', '0', '6', 'B');
INSERT INTO `my_pcd` VALUES ('1069', '330211', '3302', '镇海区', '3', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('1070', '330212', '3302', '鄞州区', '3', '1', '0', '12', 'Z');
INSERT INTO `my_pcd` VALUES ('1071', '330225', '3302', '象山县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('1072', '330226', '3302', '宁海县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('1073', '330281', '3302', '余姚市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1074', '330282', '3302', '慈溪市', '3', '1', '0', '82', 'C');
INSERT INTO `my_pcd` VALUES ('1075', '330283', '3302', '奉化市', '3', '1', '0', '83', 'F');
INSERT INTO `my_pcd` VALUES ('1076', '3303', '33', '温州市', '2', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('1077', '330301', '3303', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1078', '330302', '3303', '鹿城区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1079', '330303', '3303', '龙湾区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('1080', '330304', '3303', '瓯海区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('1081', '330322', '3303', '洞头县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('1082', '330324', '3303', '永嘉县', '3', '1', '0', '24', 'Y');
INSERT INTO `my_pcd` VALUES ('1083', '330326', '3303', '平阳县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('1084', '330327', '3303', '苍南县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('1085', '330328', '3303', '文成县', '3', '1', '0', '28', 'W');
INSERT INTO `my_pcd` VALUES ('1086', '330329', '3303', '泰顺县', '3', '1', '0', '29', 'T');
INSERT INTO `my_pcd` VALUES ('1087', '330381', '3303', '瑞安市', '3', '1', '0', '81', 'R');
INSERT INTO `my_pcd` VALUES ('1088', '330382', '3303', '乐清市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('1089', '3304', '33', '嘉兴市', '2', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('1090', '330401', '3304', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1091', '330402', '3304', '南湖区', '3', '1', '0', '2', 'N');
INSERT INTO `my_pcd` VALUES ('1092', '330411', '3304', '秀洲区', '3', '1', '0', '11', 'X');
INSERT INTO `my_pcd` VALUES ('1093', '330421', '3304', '嘉善县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('1094', '330424', '3304', '海盐县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('1095', '330481', '3304', '海宁市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('1096', '330482', '3304', '平湖市', '3', '1', '0', '82', 'P');
INSERT INTO `my_pcd` VALUES ('1097', '330483', '3304', '桐乡市', '3', '1', '0', '83', 'T');
INSERT INTO `my_pcd` VALUES ('1098', '3305', '33', '湖州市', '2', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('1099', '330501', '3305', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1100', '330502', '3305', '吴兴区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('1101', '330503', '3305', '南浔区', '3', '1', '0', '3', 'N');
INSERT INTO `my_pcd` VALUES ('1102', '330521', '3305', '德清县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('1103', '330522', '3305', '长兴县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('1104', '330523', '3305', '安吉县', '3', '1', '0', '23', 'A');
INSERT INTO `my_pcd` VALUES ('1105', '3306', '33', '绍兴市', '2', '1', '0', '6', 'S');
INSERT INTO `my_pcd` VALUES ('1106', '330601', '3306', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1107', '330602', '3306', '越城区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1108', '330621', '3306', '绍兴县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('1109', '330624', '3306', '新昌县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('1110', '330681', '3306', '诸暨市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('1111', '330682', '3306', '上虞市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('1112', '330683', '3306', '嵊州市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('1113', '3307', '33', '金华市', '2', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('1114', '330701', '3307', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1115', '330702', '3307', '婺城区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1116', '330703', '3307', '金东区', '3', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('1117', '330723', '3307', '武义县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('1118', '330726', '3307', '浦江县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('1119', '330727', '3307', '磐安县', '3', '1', '0', '27', 'P');
INSERT INTO `my_pcd` VALUES ('1120', '330781', '3307', '兰溪市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1121', '330782', '3307', '义乌市', '3', '1', '0', '82', 'Y');
INSERT INTO `my_pcd` VALUES ('1122', '330783', '3307', '东阳市', '3', '1', '0', '83', 'D');
INSERT INTO `my_pcd` VALUES ('1123', '330784', '3307', '永康市', '3', '1', '0', '84', 'Y');
INSERT INTO `my_pcd` VALUES ('1124', '3308', '33', '衢州市', '2', '1', '0', '8', 'Z');
INSERT INTO `my_pcd` VALUES ('1125', '330801', '3308', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1126', '330802', '3308', '柯城区', '3', '1', '0', '2', 'K');
INSERT INTO `my_pcd` VALUES ('1127', '330803', '3308', '衢江区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1128', '330822', '3308', '常山县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('1129', '330824', '3308', '开化县', '3', '1', '0', '24', 'K');
INSERT INTO `my_pcd` VALUES ('1130', '330825', '3308', '龙游县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('1131', '330881', '3308', '江山市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('1132', '3309', '33', '舟山市', '2', '1', '0', '9', 'Z');
INSERT INTO `my_pcd` VALUES ('1133', '330901', '3309', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1134', '330902', '3309', '定海区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1135', '330903', '3309', '普陀区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('1136', '330921', '3309', '岱山县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('1137', '330922', '3309', '嵊泗县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1138', '3310', '33', '台州市', '2', '1', '0', '10', 'T');
INSERT INTO `my_pcd` VALUES ('1139', '331001', '3310', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1140', '331002', '3310', '椒江区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1141', '331003', '3310', '黄岩区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1142', '331004', '3310', '路桥区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('1143', '331021', '3310', '玉环县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('1144', '331022', '3310', '三门县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('1145', '331023', '3310', '天台县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('1146', '331024', '3310', '仙居县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('1147', '331081', '3310', '温岭市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('1148', '331082', '3310', '临海市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('1149', '3311', '33', '丽水市', '2', '1', '0', '11', 'L');
INSERT INTO `my_pcd` VALUES ('1150', '331101', '3311', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1151', '331102', '3311', '莲都区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1152', '331121', '3311', '青田县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('1153', '331122', '3311', '缙云县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1154', '331123', '3311', '遂昌县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('1155', '331124', '3311', '松阳县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1156', '331125', '3311', '云和县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1157', '331126', '3311', '庆元县', '3', '1', '0', '26', 'Q');
INSERT INTO `my_pcd` VALUES ('1158', '331127', '3311', '景宁畲族自治县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('1159', '331181', '3311', '龙泉市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1160', '34', '0', '安徽省', '1', '1', '0', '34', 'A');
INSERT INTO `my_pcd` VALUES ('1161', '3401', '34', '合肥市', '2', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('1162', '340101', '3401', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1163', '340102', '3401', '瑶海区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1164', '340103', '3401', '庐阳区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('1165', '340104', '3401', '蜀山区', '3', '1', '0', '4', 'S');
INSERT INTO `my_pcd` VALUES ('1166', '340111', '3401', '包河区', '3', '1', '0', '11', 'B');
INSERT INTO `my_pcd` VALUES ('1167', '340121', '3401', '长丰县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('1168', '340122', '3401', '肥东县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('1169', '340123', '3401', '肥西县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('1170', '3402', '34', '芜湖市', '2', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('1171', '340201', '3402', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1172', '340202', '3402', '镜湖区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1173', '340203', '3402', '弋江区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1174', '340207', '3402', '鸠江区', '3', '1', '0', '7', 'Z');
INSERT INTO `my_pcd` VALUES ('1175', '340208', '3402', '三山区', '3', '1', '0', '8', 'S');
INSERT INTO `my_pcd` VALUES ('1176', '340221', '3402', '芜湖县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('1177', '340222', '3402', '繁昌县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('1178', '340223', '3402', '南陵县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('1179', '3403', '34', '蚌埠市', '2', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('1180', '340301', '3403', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1181', '340302', '3403', '龙子湖区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1182', '340303', '3403', '蚌山区', '3', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('1183', '340304', '3403', '禹会区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('1184', '340311', '3403', '淮上区', '3', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('1185', '340321', '3403', '怀远县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('1186', '340322', '3403', '五河县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('1187', '340323', '3403', '固镇县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('1188', '3404', '34', '淮南市', '2', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('1189', '340401', '3404', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1190', '340402', '3404', '大通区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1191', '340403', '3404', '田家庵区', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('1192', '340404', '3404', '谢家集区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('1193', '340405', '3404', '八公山区', '3', '1', '0', '5', 'B');
INSERT INTO `my_pcd` VALUES ('1194', '340406', '3404', '潘集区', '3', '1', '0', '6', 'P');
INSERT INTO `my_pcd` VALUES ('1195', '340421', '3404', '凤台县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('1196', '3405', '34', '马鞍山市', '2', '1', '0', '5', 'M');
INSERT INTO `my_pcd` VALUES ('1197', '340501', '3405', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1198', '340502', '3405', '金家庄区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1199', '340503', '3405', '花山区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1200', '340504', '3405', '雨山区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('1201', '340521', '3405', '当涂县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('1202', '3406', '34', '淮北市', '2', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('1203', '340601', '3406', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1204', '340602', '3406', '杜集区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1205', '340603', '3406', '相山区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('1206', '340604', '3406', '烈山区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('1207', '340621', '3406', '濉溪县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('1208', '3407', '34', '铜陵市', '2', '1', '0', '7', 'T');
INSERT INTO `my_pcd` VALUES ('1209', '340701', '3407', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1210', '340702', '3407', '铜官山区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('1211', '340703', '3407', '狮子山区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1212', '340711', '3407', '铜陵市郊区', '3', '1', '0', '11', 'T');
INSERT INTO `my_pcd` VALUES ('1213', '340721', '3407', '铜陵县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('1214', '3408', '34', '安庆市', '2', '1', '0', '8', 'A');
INSERT INTO `my_pcd` VALUES ('1215', '340801', '3408', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1216', '340802', '3408', '迎江区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1217', '340803', '3408', '大观区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('1218', '340811', '3408', '宜秀区', '3', '1', '0', '11', 'Y');
INSERT INTO `my_pcd` VALUES ('1219', '340822', '3408', '怀宁县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('1220', '340823', '3408', '枞阳县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1221', '340824', '3408', '潜山县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('1222', '340825', '3408', '太湖县', '3', '1', '0', '25', 'T');
INSERT INTO `my_pcd` VALUES ('1223', '340826', '3408', '宿松县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('1224', '340827', '3408', '望江县', '3', '1', '0', '27', 'W');
INSERT INTO `my_pcd` VALUES ('1225', '340828', '3408', '岳西县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('1226', '340881', '3408', '桐城市', '3', '1', '0', '81', 'T');
INSERT INTO `my_pcd` VALUES ('1227', '3410', '34', '黄山市', '2', '1', '0', '10', 'H');
INSERT INTO `my_pcd` VALUES ('1228', '341001', '3410', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1229', '341002', '3410', '屯溪区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('1230', '341003', '3410', '黄山区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1231', '341004', '3410', '徽州区', '3', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('1232', '341021', '3410', '歙县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('1233', '341022', '3410', '休宁县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('1234', '341023', '3410', '黟县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1235', '341024', '3410', '祁门县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('1236', '3411', '34', '滁州市', '2', '1', '0', '11', 'C');
INSERT INTO `my_pcd` VALUES ('1237', '341101', '3411', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1238', '341102', '3411', '琅琊区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1239', '341103', '3411', '南谯区', '3', '1', '0', '3', 'N');
INSERT INTO `my_pcd` VALUES ('1240', '341122', '3411', '来安县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('1241', '341124', '3411', '全椒县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('1242', '341125', '3411', '定远县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('1243', '341126', '3411', '凤阳县', '3', '1', '0', '26', 'F');
INSERT INTO `my_pcd` VALUES ('1244', '341181', '3411', '天长市', '3', '1', '0', '81', 'T');
INSERT INTO `my_pcd` VALUES ('1245', '341182', '3411', '明光市', '3', '1', '0', '82', 'M');
INSERT INTO `my_pcd` VALUES ('1246', '3412', '34', '阜阳市', '2', '1', '0', '12', 'F');
INSERT INTO `my_pcd` VALUES ('1247', '341201', '3412', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1248', '341202', '3412', '颍州区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1249', '341203', '3412', '颍东区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1250', '341204', '3412', '颍泉区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('1251', '341221', '3412', '临泉县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('1252', '341222', '3412', '太和县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('1253', '341225', '3412', '阜南县', '3', '1', '0', '25', 'F');
INSERT INTO `my_pcd` VALUES ('1254', '341226', '3412', '颍上县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1255', '341282', '3412', '界首市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('1256', '3413', '34', '宿州市', '2', '1', '0', '13', 'S');
INSERT INTO `my_pcd` VALUES ('1257', '341301', '3413', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1258', '341302', '3413', '墉桥区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1259', '341321', '3413', '砀山县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('1260', '341322', '3413', '萧县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('1261', '341323', '3413', '灵璧县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('1262', '341324', '3413', '泗县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1263', '3414', '34', '巢湖市', '2', '1', '0', '14', 'C');
INSERT INTO `my_pcd` VALUES ('1264', '341401', '3414', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1265', '341402', '3414', '居巢区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1266', '341421', '3414', '庐江县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('1267', '341422', '3414', '无为县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('1268', '341423', '3414', '含山县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('1269', '341424', '3414', '和县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('1270', '3415', '34', '六安市', '2', '1', '0', '15', 'L');
INSERT INTO `my_pcd` VALUES ('1271', '341501', '3415', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1272', '341502', '3415', '金安区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1273', '341503', '3415', '裕安区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('1274', '341521', '3415', '寿县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('1275', '341522', '3415', '霍邱县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('1276', '341523', '3415', '舒城县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('1277', '341524', '3415', '金寨县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('1278', '341525', '3415', '霍山县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('1279', '3416', '34', '亳州市', '2', '1', '0', '16', 'Z');
INSERT INTO `my_pcd` VALUES ('1280', '341601', '3416', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1281', '341602', '3416', '谯城区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1282', '341621', '3416', '涡阳县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('1283', '341622', '3416', '蒙城县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('1284', '341623', '3416', '利辛县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('1285', '3417', '34', '池州市', '2', '1', '0', '17', 'C');
INSERT INTO `my_pcd` VALUES ('1286', '341701', '3417', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1287', '341702', '3417', '贵池区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('1288', '341721', '3417', '东至县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('1289', '341722', '3417', '石台县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('1290', '341723', '3417', '青阳县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('1291', '3418', '34', '宣城市', '2', '1', '0', '18', 'X');
INSERT INTO `my_pcd` VALUES ('1292', '341801', '3418', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1293', '341802', '3418', '宣州区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1294', '341821', '3418', '郎溪县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('1295', '341822', '3418', '广德县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('1296', '341823', '3418', '泾县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1297', '341824', '3418', '绩溪县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('1298', '341825', '3418', '旌德县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('1299', '341881', '3418', '宁国市', '3', '1', '0', '81', 'N');
INSERT INTO `my_pcd` VALUES ('1300', '35', '0', '福建省', '1', '1', '0', '35', 'F');
INSERT INTO `my_pcd` VALUES ('1301', '3501', '35', '福州市', '2', '1', '0', '1', 'F');
INSERT INTO `my_pcd` VALUES ('1302', '350101', '3501', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1303', '350102', '3501', '鼓楼区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('1304', '350103', '3501', '台江区', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('1305', '350104', '3501', '仓山区', '3', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('1306', '350105', '3501', '马尾区', '3', '1', '0', '5', 'M');
INSERT INTO `my_pcd` VALUES ('1307', '350111', '3501', '晋安区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('1308', '350121', '3501', '闽侯县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('1309', '350122', '3501', '连江县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('1310', '350123', '3501', '罗源县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('1311', '350124', '3501', '闽清县', '3', '1', '0', '24', 'M');
INSERT INTO `my_pcd` VALUES ('1312', '350125', '3501', '永泰县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1313', '350128', '3501', '平潭县', '3', '1', '0', '28', 'P');
INSERT INTO `my_pcd` VALUES ('1314', '350181', '3501', '福清市', '3', '1', '0', '81', 'F');
INSERT INTO `my_pcd` VALUES ('1315', '350182', '3501', '长乐市', '3', '1', '0', '82', 'C');
INSERT INTO `my_pcd` VALUES ('1316', '3502', '35', '厦门市', '2', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1317', '350201', '3502', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1318', '350203', '3502', '思明区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1319', '350205', '3502', '海沧区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('1320', '350206', '3502', '湖里区', '3', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('1321', '350211', '3502', '集美区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('1322', '350212', '3502', '同安区', '3', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('1323', '350213', '3502', '翔安区', '3', '1', '0', '13', 'X');
INSERT INTO `my_pcd` VALUES ('1324', '3503', '35', '莆田市', '2', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('1325', '350301', '3503', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1326', '350302', '3503', '城厢区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('1327', '350303', '3503', '涵江区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1328', '350304', '3503', '荔城区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('1329', '350305', '3503', '秀屿区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('1330', '350322', '3503', '仙游县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('1331', '3504', '35', '三明市', '2', '1', '0', '4', 'S');
INSERT INTO `my_pcd` VALUES ('1332', '350401', '3504', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1333', '350402', '3504', '梅列区', '3', '1', '0', '2', 'M');
INSERT INTO `my_pcd` VALUES ('1334', '350403', '3504', '三元区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1335', '350421', '3504', '明溪县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('1336', '350423', '3504', '清流县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('1337', '350424', '3504', '宁化县', '3', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('1338', '350425', '3504', '大田县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('1339', '350426', '3504', '尤溪县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('1340', '350427', '3504', '沙县', '3', '1', '0', '27', 'S');
INSERT INTO `my_pcd` VALUES ('1341', '350428', '3504', '将乐县', '3', '1', '0', '28', 'J');
INSERT INTO `my_pcd` VALUES ('1342', '350429', '3504', '泰宁县', '3', '1', '0', '29', 'T');
INSERT INTO `my_pcd` VALUES ('1343', '350430', '3504', '建宁县', '3', '1', '0', '30', 'J');
INSERT INTO `my_pcd` VALUES ('1344', '350481', '3504', '永安市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1345', '3505', '35', '泉州市', '2', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('1346', '350501', '3505', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1347', '350502', '3505', '鲤城区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1348', '350503', '3505', '丰泽区', '3', '1', '0', '3', 'F');
INSERT INTO `my_pcd` VALUES ('1349', '350504', '3505', '洛江区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('1350', '350505', '3505', '泉港区', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('1351', '350521', '3505', '惠安县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('1352', '350524', '3505', '安溪县', '3', '1', '0', '24', 'A');
INSERT INTO `my_pcd` VALUES ('1353', '350525', '3505', '永春县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1354', '350526', '3505', '德化县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('1355', '350527', '3505', '金门县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('1356', '350581', '3505', '石狮市', '3', '1', '0', '81', 'S');
INSERT INTO `my_pcd` VALUES ('1357', '350582', '3505', '晋江市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('1358', '350583', '3505', '南安市', '3', '1', '0', '83', 'N');
INSERT INTO `my_pcd` VALUES ('1359', '3506', '35', '漳州市', '2', '1', '0', '6', 'Z');
INSERT INTO `my_pcd` VALUES ('1360', '350601', '3506', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1361', '350602', '3506', '芗城区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1362', '350603', '3506', '龙文区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('1363', '350622', '3506', '云霄县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1364', '350623', '3506', '漳浦县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1365', '350624', '3506', '诏安县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1366', '350625', '3506', '长泰县', '3', '1', '0', '25', 'C');
INSERT INTO `my_pcd` VALUES ('1367', '350626', '3506', '东山县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('1368', '350627', '3506', '南靖县', '3', '1', '0', '27', 'N');
INSERT INTO `my_pcd` VALUES ('1369', '350628', '3506', '平和县', '3', '1', '0', '28', 'P');
INSERT INTO `my_pcd` VALUES ('1370', '350629', '3506', '华安县', '3', '1', '0', '29', 'H');
INSERT INTO `my_pcd` VALUES ('1371', '350681', '3506', '龙海市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1372', '3507', '35', '南平市', '2', '1', '0', '7', 'N');
INSERT INTO `my_pcd` VALUES ('1373', '350701', '3507', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1374', '350702', '3507', '延平区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1375', '350721', '3507', '顺昌县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('1376', '350722', '3507', '浦城县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('1377', '350723', '3507', '光泽县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('1378', '350724', '3507', '松溪县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1379', '350725', '3507', '政和县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('1380', '350725104', '350725', '\"镇前镇', '0', '1', '0', '4', '');
INSERT INTO `my_pcd` VALUES ('1381', '350725202', '350725', '\"杨源乡', '0', '1', '0', '2', '');
INSERT INTO `my_pcd` VALUES ('1382', '350725203', '350725', '\"澄源乡', '0', '1', '0', '3', '');
INSERT INTO `my_pcd` VALUES ('1383', '350725204', '350725', '\"岭腰乡', '0', '1', '0', '4', '');
INSERT INTO `my_pcd` VALUES ('1384', '350781', '3507', '邵武市', '3', '1', '0', '81', 'S');
INSERT INTO `my_pcd` VALUES ('1385', '350782', '3507', '武夷山市', '3', '1', '0', '82', 'W');
INSERT INTO `my_pcd` VALUES ('1386', '350783', '3507', '建瓯市', '3', '1', '0', '83', 'J');
INSERT INTO `my_pcd` VALUES ('1387', '350784', '3507', '建阳市', '3', '1', '0', '84', 'J');
INSERT INTO `my_pcd` VALUES ('1388', '3508', '35', '龙岩市', '2', '1', '0', '8', 'L');
INSERT INTO `my_pcd` VALUES ('1389', '350801', '3508', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1390', '350802', '3508', '新罗区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1391', '350821', '3508', '长汀县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('1392', '350822', '3508', '永定县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1393', '350823', '3508', '上杭县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('1394', '350824', '3508', '武平县', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('1395', '350825', '3508', '连城县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('1396', '350881', '3508', '漳平市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('1397', '3509', '35', '宁德市　', '2', '1', '0', '9', 'N');
INSERT INTO `my_pcd` VALUES ('1398', '350901', '3509', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1399', '350902', '3509', '蕉城区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1400', '350921', '3509', '霞浦县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('1401', '350922', '3509', '古田县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('1402', '350923', '3509', '屏南县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('1403', '350924', '3509', '寿宁县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1404', '350925', '3509', '周宁县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('1405', '350926', '3509', '柘荣县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1406', '350981', '3509', '福安市', '3', '1', '0', '81', 'F');
INSERT INTO `my_pcd` VALUES ('1407', '350982', '3509', '福鼎市', '3', '1', '0', '82', 'F');
INSERT INTO `my_pcd` VALUES ('1408', '36', '0', '江西省', '1', '1', '0', '36', 'J');
INSERT INTO `my_pcd` VALUES ('1409', '3601', '36', '南昌市', '2', '1', '0', '1', 'N');
INSERT INTO `my_pcd` VALUES ('1410', '360101', '3601', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1411', '360102', '3601', '东湖区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1412', '360103', '3601', '西湖区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('1413', '360104', '3601', '青云谱区', '3', '1', '0', '4', 'Q');
INSERT INTO `my_pcd` VALUES ('1414', '360105', '3601', '湾里区', '3', '1', '0', '5', 'W');
INSERT INTO `my_pcd` VALUES ('1415', '360111', '3601', '青山湖区', '3', '1', '0', '11', 'Q');
INSERT INTO `my_pcd` VALUES ('1416', '360111105', '360111', '\"塘山镇', '0', '1', '0', '5', '');
INSERT INTO `my_pcd` VALUES ('1417', '360121', '3601', '南昌县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('1418', '360122', '3601', '新建县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('1419', '360123', '3601', '安义县', '3', '1', '0', '23', 'A');
INSERT INTO `my_pcd` VALUES ('1420', '360123105', '360123', '\"东阳镇', '0', '1', '0', '5', '');
INSERT INTO `my_pcd` VALUES ('1421', '360124', '3601', '进贤县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('1422', '3602', '36', '景德镇市', '2', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1423', '360201', '3602', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1424', '360202', '3602', '昌江区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('1425', '360203', '3602', '珠山区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1426', '360222', '3602', '浮梁县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('1427', '360281', '3602', '乐平市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1428', '3603', '36', '萍乡市', '2', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('1429', '360301', '3603', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1430', '360302', '3603', '安源区', '3', '1', '0', '2', 'A');
INSERT INTO `my_pcd` VALUES ('1431', '360313', '3603', '湘东区', '3', '1', '0', '13', 'X');
INSERT INTO `my_pcd` VALUES ('1432', '360321', '3603', '莲花县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('1433', '360322', '3603', '上栗县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('1434', '360323', '3603', '芦溪县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('1435', '3604', '36', '九江市', '2', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('1436', '360401', '3604', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1437', '360402', '3604', '庐山区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1438', '360403', '3604', '浔阳区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1439', '360421', '3604', '九江县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('1440', '360423', '3604', '武宁县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('1441', '360424', '3604', '修水县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('1442', '360425', '3604', '永修县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1443', '360426', '3604', '德安县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('1444', '360427', '3604', '星子县', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('1445', '360428', '3604', '都昌县', '3', '1', '0', '28', 'D');
INSERT INTO `my_pcd` VALUES ('1446', '360429', '3604', '湖口县', '3', '1', '0', '29', 'H');
INSERT INTO `my_pcd` VALUES ('1447', '360430', '3604', '彭泽县', '3', '1', '0', '30', 'P');
INSERT INTO `my_pcd` VALUES ('1448', '360481', '3604', '瑞昌市', '3', '1', '0', '81', 'R');
INSERT INTO `my_pcd` VALUES ('1449', '3605', '36', '新余市', '2', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('1450', '360501', '3605', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1451', '360502', '3605', '渝水区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1452', '360521', '3605', '分宜县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('1453', '3606', '36', '鹰潭市', '2', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('1454', '360601', '3606', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1455', '360602', '3606', '月湖区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1456', '360622', '3606', '余江县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1457', '360681', '3606', '贵溪市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('1458', '3607', '36', '赣州市', '2', '1', '0', '7', 'G');
INSERT INTO `my_pcd` VALUES ('1459', '360701', '3607', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1460', '360702', '3607', '章贡区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1461', '360721', '3607', '赣县', '3', '1', '0', '21', 'G');
INSERT INTO `my_pcd` VALUES ('1462', '360722', '3607', '信丰县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('1463', '360723', '3607', '大余县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('1464', '360724', '3607', '上犹县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1465', '360725', '3607', '崇义县', '3', '1', '0', '25', 'C');
INSERT INTO `my_pcd` VALUES ('1466', '360726', '3607', '安远县', '3', '1', '0', '26', 'A');
INSERT INTO `my_pcd` VALUES ('1467', '360727', '3607', '龙南县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('1468', '360728', '3607', '定南县', '3', '1', '0', '28', 'D');
INSERT INTO `my_pcd` VALUES ('1469', '360729', '3607', '全南县', '3', '1', '0', '29', 'Q');
INSERT INTO `my_pcd` VALUES ('1470', '360730', '3607', '宁都县', '3', '1', '0', '30', 'N');
INSERT INTO `my_pcd` VALUES ('1471', '360731', '3607', '于都县', '3', '1', '0', '31', 'Y');
INSERT INTO `my_pcd` VALUES ('1472', '360732', '3607', '兴国县', '3', '1', '0', '32', 'X');
INSERT INTO `my_pcd` VALUES ('1473', '360733', '3607', '会昌县', '3', '1', '0', '33', 'H');
INSERT INTO `my_pcd` VALUES ('1474', '360734', '3607', '寻乌县', '3', '1', '0', '34', 'X');
INSERT INTO `my_pcd` VALUES ('1475', '360735', '3607', '石城县', '3', '1', '0', '35', 'S');
INSERT INTO `my_pcd` VALUES ('1476', '360781', '3607', '瑞金市', '3', '1', '0', '81', 'R');
INSERT INTO `my_pcd` VALUES ('1477', '360782', '3607', '南康市', '3', '1', '0', '82', 'N');
INSERT INTO `my_pcd` VALUES ('1478', '3608', '36', '吉安市', '2', '1', '0', '8', 'J');
INSERT INTO `my_pcd` VALUES ('1479', '360801', '3608', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1480', '360802', '3608', '吉州区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1481', '360803', '3608', '青原区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('1482', '360821', '3608', '吉安县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('1483', '360822', '3608', '吉水县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('1484', '360823', '3608', '峡江县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('1485', '360824', '3608', '新干县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('1486', '360825', '3608', '永丰县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1487', '360826', '3608', '泰和县', '3', '1', '0', '26', 'T');
INSERT INTO `my_pcd` VALUES ('1488', '360827', '3608', '遂川县', '3', '1', '0', '27', 'S');
INSERT INTO `my_pcd` VALUES ('1489', '360828', '3608', '万安县', '3', '1', '0', '28', 'W');
INSERT INTO `my_pcd` VALUES ('1490', '360829', '3608', '安福县', '3', '1', '0', '29', 'A');
INSERT INTO `my_pcd` VALUES ('1491', '360830', '3608', '永新县', '3', '1', '0', '30', 'Y');
INSERT INTO `my_pcd` VALUES ('1492', '360881', '3608', '井冈山市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('1493', '3609', '36', '宜春市', '2', '1', '0', '9', 'Y');
INSERT INTO `my_pcd` VALUES ('1494', '360901', '3609', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1495', '360902', '3609', '袁州区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1496', '360921', '3609', '奉新县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('1497', '360922', '3609', '万载县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('1498', '360923', '3609', '上高县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('1499', '360924', '3609', '宜丰县', '3', '1', '0', '24', 'Y');
INSERT INTO `my_pcd` VALUES ('1500', '360925', '3609', '靖安县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('1501', '360926', '3609', '铜鼓县', '3', '1', '0', '26', 'T');
INSERT INTO `my_pcd` VALUES ('1502', '360981', '3609', '丰城市', '3', '1', '0', '81', 'F');
INSERT INTO `my_pcd` VALUES ('1503', '360982', '3609', '樟树市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('1504', '360983', '3609', '高安市', '3', '1', '0', '83', 'G');
INSERT INTO `my_pcd` VALUES ('1505', '3610', '36', '抚州市', '2', '1', '0', '10', 'F');
INSERT INTO `my_pcd` VALUES ('1506', '361001', '3610', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1507', '361002', '3610', '临川区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1508', '361021', '3610', '南城县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('1509', '361022', '3610', '黎川县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('1510', '361023', '3610', '南丰县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('1511', '361024', '3610', '崇仁县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('1512', '361025', '3610', '乐安县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('1513', '361026', '3610', '宜黄县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('1514', '361027', '3610', '金溪县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('1515', '361028', '3610', '资溪县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('1516', '361029', '3610', '东乡县', '3', '1', '0', '29', 'D');
INSERT INTO `my_pcd` VALUES ('1517', '361030', '3610', '广昌县', '3', '1', '0', '30', 'G');
INSERT INTO `my_pcd` VALUES ('1518', '3611', '36', '上饶市', '2', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('1519', '361101', '3611', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1520', '361102', '3611', '信州区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1521', '361121', '3611', '上饶县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('1522', '361122', '3611', '广丰县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('1523', '361123', '3611', '玉山县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('1524', '361124', '3611', '铅山县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('1525', '361125', '3611', '横峰县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('1526', '361126', '3611', '弋阳县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1527', '361127', '3611', '余干县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('1528', '361128', '3611', '鄱阳县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('1529', '361129', '3611', '万年县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('1530', '361130', '3611', '婺源县', '3', '1', '0', '30', 'Z');
INSERT INTO `my_pcd` VALUES ('1531', '361181', '3611', '德兴市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('1532', '37', '0', '山东省', '1', '1', '0', '37', 'S');
INSERT INTO `my_pcd` VALUES ('1533', '3701', '37', '济南市', '2', '1', '0', '1', 'J');
INSERT INTO `my_pcd` VALUES ('1534', '370101', '3701', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1535', '370102', '3701', '历下区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1536', '370103', '3701', '市中区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1537', '370104', '3701', '槐荫区', '3', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('1538', '370105', '3701', '天桥区', '3', '1', '0', '5', 'T');
INSERT INTO `my_pcd` VALUES ('1539', '370112', '3701', '历城区', '3', '1', '0', '12', 'L');
INSERT INTO `my_pcd` VALUES ('1540', '370113', '3701', '长清区', '3', '1', '0', '13', 'C');
INSERT INTO `my_pcd` VALUES ('1541', '370124', '3701', '平阴县', '3', '1', '0', '24', 'P');
INSERT INTO `my_pcd` VALUES ('1542', '370125', '3701', '济阳县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('1543', '370126', '3701', '商河县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('1544', '370181', '3701', '章丘市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('1545', '3702', '37', '青岛市', '2', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('1546', '370201', '3702', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1547', '370202', '3702', '市南区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('1548', '370203', '3702', '市北区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1549', '370205', '3702', '四方区', '3', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('1550', '370211', '3702', '黄岛区', '3', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('1551', '370212', '3702', '崂山区', '3', '1', '0', '12', 'Z');
INSERT INTO `my_pcd` VALUES ('1552', '370213', '3702', '李沧区', '3', '1', '0', '13', 'L');
INSERT INTO `my_pcd` VALUES ('1553', '370214', '3702', '城阳区', '3', '1', '0', '14', 'C');
INSERT INTO `my_pcd` VALUES ('1554', '370281', '3702', '胶州市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('1555', '370282', '3702', '即墨市', '3', '1', '0', '82', 'J');
INSERT INTO `my_pcd` VALUES ('1556', '370283', '3702', '平度市', '3', '1', '0', '83', 'P');
INSERT INTO `my_pcd` VALUES ('1557', '370284', '3702', '胶南市', '3', '1', '0', '84', 'J');
INSERT INTO `my_pcd` VALUES ('1558', '370285', '3702', '莱西市', '3', '1', '0', '85', 'L');
INSERT INTO `my_pcd` VALUES ('1559', '3703', '37', '淄博市', '2', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1560', '370301', '3703', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1561', '370302', '3703', '淄川区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1562', '370303', '3703', '张店区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1563', '370304', '3703', '博山区', '3', '1', '0', '4', 'B');
INSERT INTO `my_pcd` VALUES ('1564', '370305', '3703', '临淄区', '3', '1', '0', '5', 'L');
INSERT INTO `my_pcd` VALUES ('1565', '370306', '3703', '周村区', '3', '1', '0', '6', 'Z');
INSERT INTO `my_pcd` VALUES ('1566', '370321', '3703', '桓台县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('1567', '370322', '3703', '高青县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('1568', '370323', '3703', '沂源县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('1569', '3704', '37', '枣庄市', '2', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('1570', '370401', '3704', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1571', '370402', '3704', '市中区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('1572', '370403', '3704', '薛城区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('1573', '370404', '3704', '峄城区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('1574', '370405', '3704', '台儿庄区', '3', '1', '0', '5', 'T');
INSERT INTO `my_pcd` VALUES ('1575', '370406', '3704', '山亭区', '3', '1', '0', '6', 'S');
INSERT INTO `my_pcd` VALUES ('1576', '370481', '3704', '滕州市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('1577', '3705', '37', '东营市', '2', '1', '0', '5', 'D');
INSERT INTO `my_pcd` VALUES ('1578', '370501', '3705', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1579', '370502', '3705', '东营区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1580', '370503', '3705', '河口区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1581', '370521', '3705', '垦利县', '3', '1', '0', '21', 'K');
INSERT INTO `my_pcd` VALUES ('1582', '370522', '3705', '利津县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('1583', '370523', '3705', '广饶县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('1584', '3706', '37', '烟台市', '2', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('1585', '370601', '3706', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1586', '370602', '3706', '芝罘区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1587', '370611', '3706', '福山区', '3', '1', '0', '11', 'F');
INSERT INTO `my_pcd` VALUES ('1588', '370612', '3706', '牟平区', '3', '1', '0', '12', 'M');
INSERT INTO `my_pcd` VALUES ('1589', '370613', '3706', '莱山区', '3', '1', '0', '13', 'L');
INSERT INTO `my_pcd` VALUES ('1590', '370634', '3706', '长岛县', '3', '1', '0', '34', 'C');
INSERT INTO `my_pcd` VALUES ('1591', '370681', '3706', '龙口市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1592', '370682', '3706', '莱阳市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('1593', '370683', '3706', '莱州市', '3', '1', '0', '83', 'L');
INSERT INTO `my_pcd` VALUES ('1594', '370684', '3706', '蓬莱市', '3', '1', '0', '84', 'P');
INSERT INTO `my_pcd` VALUES ('1595', '370685', '3706', '招远市', '3', '1', '0', '85', 'Z');
INSERT INTO `my_pcd` VALUES ('1596', '370686', '3706', '栖霞市', '3', '1', '0', '86', 'Q');
INSERT INTO `my_pcd` VALUES ('1597', '370687', '3706', '海阳市', '3', '1', '0', '87', 'H');
INSERT INTO `my_pcd` VALUES ('1598', '3707', '37', '潍坊市', '2', '1', '0', '7', 'W');
INSERT INTO `my_pcd` VALUES ('1599', '370701', '3707', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1600', '370702', '3707', '潍城区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('1601', '370703', '3707', '寒亭区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1602', '370704', '3707', '坊子区', '3', '1', '0', '4', 'F');
INSERT INTO `my_pcd` VALUES ('1603', '370705', '3707', '奎文区', '3', '1', '0', '5', 'K');
INSERT INTO `my_pcd` VALUES ('1604', '370724', '3707', '临朐县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('1605', '370725', '3707', '昌乐县', '3', '1', '0', '25', 'C');
INSERT INTO `my_pcd` VALUES ('1606', '370781', '3707', '青州市', '3', '1', '0', '81', 'Q');
INSERT INTO `my_pcd` VALUES ('1607', '370782', '3707', '诸城市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('1608', '370783', '3707', '寿光市', '3', '1', '0', '83', 'S');
INSERT INTO `my_pcd` VALUES ('1609', '370784', '3707', '安丘市', '3', '1', '0', '84', 'A');
INSERT INTO `my_pcd` VALUES ('1610', '370785', '3707', '高密市', '3', '1', '0', '85', 'G');
INSERT INTO `my_pcd` VALUES ('1611', '370786', '3707', '昌邑市', '3', '1', '0', '86', 'C');
INSERT INTO `my_pcd` VALUES ('1612', '3708', '37', '济宁市', '2', '1', '0', '8', 'J');
INSERT INTO `my_pcd` VALUES ('1613', '370801', '3708', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1614', '370802', '3708', '市中区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('1615', '370802006', '370802', '\"观音阁街道办事处', '0', '1', '0', '6', '');
INSERT INTO `my_pcd` VALUES ('1616', '370811', '3708', '任城区', '3', '1', '0', '11', 'R');
INSERT INTO `my_pcd` VALUES ('1617', '370826', '3708', '\"微山县', '0', '1', '0', '26', '');
INSERT INTO `my_pcd` VALUES ('1618', '370826101', '370826', '\"韩庄镇', '0', '1', '0', '1', '');
INSERT INTO `my_pcd` VALUES ('1619', '370826102', '370826', '\"欢城镇', '0', '1', '0', '2', '');
INSERT INTO `my_pcd` VALUES ('1620', '370826103', '370826', '\"南阳镇', '0', '1', '0', '3', '');
INSERT INTO `my_pcd` VALUES ('1621', '370826105', '370826', '\"傅村镇', '0', '1', '0', '5', '');
INSERT INTO `my_pcd` VALUES ('1622', '370826205', '370826', '\"马坡乡', '0', '1', '0', '5', '');
INSERT INTO `my_pcd` VALUES ('1623', '370826206', '370826', '\"高楼乡', '0', '1', '0', '6', '');
INSERT INTO `my_pcd` VALUES ('1624', '370826210', '370826', '\"西平乡', '0', '1', '0', '10', '');
INSERT INTO `my_pcd` VALUES ('1625', '370827', '3708', '鱼台县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('1626', '370828', '3708', '金乡县', '3', '1', '0', '28', 'J');
INSERT INTO `my_pcd` VALUES ('1627', '370829', '3708', '嘉祥县', '3', '1', '0', '29', 'J');
INSERT INTO `my_pcd` VALUES ('1628', '370830', '3708', '汶上县', '3', '1', '0', '30', 'Z');
INSERT INTO `my_pcd` VALUES ('1629', '370831', '3708', '泗水县', '3', '1', '0', '31', 'Z');
INSERT INTO `my_pcd` VALUES ('1630', '370832', '3708', '梁山县', '3', '1', '0', '32', 'L');
INSERT INTO `my_pcd` VALUES ('1631', '370881', '3708', '曲阜市', '3', '1', '0', '81', 'Q');
INSERT INTO `my_pcd` VALUES ('1632', '370882', '3708', '兖州市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('1633', '370883', '3708', '邹城市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('1634', '3709', '37', '泰安市', '2', '1', '0', '9', 'T');
INSERT INTO `my_pcd` VALUES ('1635', '370901', '3709', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1636', '370902', '3709', '泰山区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('1637', '370903', '3709', '岱岳区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1638', '370921', '3709', '宁阳县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('1639', '370923', '3709', '东平县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('1640', '370982', '3709', '新泰市', '3', '1', '0', '82', 'X');
INSERT INTO `my_pcd` VALUES ('1641', '370983', '3709', '肥城市', '3', '1', '0', '83', 'F');
INSERT INTO `my_pcd` VALUES ('1642', '3710', '37', '威海市', '2', '1', '0', '10', 'W');
INSERT INTO `my_pcd` VALUES ('1643', '371001', '3710', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1644', '371002', '3710', '环翠区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1645', '371081', '3710', '文登市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('1646', '371082', '3710', '荣成市', '3', '1', '0', '82', 'R');
INSERT INTO `my_pcd` VALUES ('1647', '371083', '3710', '乳山市', '3', '1', '0', '83', 'R');
INSERT INTO `my_pcd` VALUES ('1648', '3711', '37', '日照市', '2', '1', '0', '11', 'R');
INSERT INTO `my_pcd` VALUES ('1649', '371101', '3711', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1650', '371102', '3711', '东港区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1651', '371103', '3711', '岚山区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1652', '371121', '3711', '五莲县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('1653', '371122', '3711', '莒县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1654', '3712', '37', '莱芜市', '2', '1', '0', '12', 'L');
INSERT INTO `my_pcd` VALUES ('1655', '371201', '3712', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1656', '371202', '3712', '莱城区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1657', '371203', '3712', '钢城区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('1658', '3713', '37', '临沂市', '2', '1', '0', '13', 'L');
INSERT INTO `my_pcd` VALUES ('1659', '371301', '3713', '临沂市辖区', '3', '1', '0', '1', 'L');
INSERT INTO `my_pcd` VALUES ('1660', '371302', '3713', '兰山区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1661', '371311', '3713', '罗庄区', '3', '1', '0', '11', 'L');
INSERT INTO `my_pcd` VALUES ('1662', '371312', '3713', '河东区', '3', '1', '0', '12', 'H');
INSERT INTO `my_pcd` VALUES ('1663', '371321', '3713', '沂南县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('1664', '371322', '3713', '郯城县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1665', '371323', '3713', '沂水县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('1666', '371324', '3713', '苍山县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('1667', '371325', '3713', '费县', '3', '1', '0', '25', 'F');
INSERT INTO `my_pcd` VALUES ('1668', '371326', '3713', '平邑县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('1669', '371327', '3713', '莒南县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('1670', '371328', '3713', '蒙阴县', '3', '1', '0', '28', 'M');
INSERT INTO `my_pcd` VALUES ('1671', '371329', '3713', '临沭县', '3', '1', '0', '29', 'L');
INSERT INTO `my_pcd` VALUES ('1672', '3714', '37', '德州市', '2', '1', '0', '14', 'D');
INSERT INTO `my_pcd` VALUES ('1673', '371401', '3714', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1674', '371402', '3714', '德城区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1675', '371421', '3714', '陵县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('1676', '371422', '3714', '宁津县', '3', '1', '0', '22', 'N');
INSERT INTO `my_pcd` VALUES ('1677', '371423', '3714', '庆云县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('1678', '371424', '3714', '临邑县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('1679', '371425', '3714', '齐河县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('1680', '371426', '3714', '平原县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('1681', '371427', '3714', '夏津县', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('1682', '371428', '3714', '武城县', '3', '1', '0', '28', 'W');
INSERT INTO `my_pcd` VALUES ('1683', '371481', '3714', '乐陵市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1684', '371482', '3714', '禹城市', '3', '1', '0', '82', 'Y');
INSERT INTO `my_pcd` VALUES ('1685', '3715', '37', '聊城市', '2', '1', '0', '15', 'L');
INSERT INTO `my_pcd` VALUES ('1686', '371501', '3715', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1687', '371502', '3715', '东昌府区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1688', '371521', '3715', '阳谷县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('1689', '371522', '3715', '莘县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1690', '371523', '3715', '茌平县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1691', '371524', '3715', '东阿县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('1692', '371525', '3715', '冠县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('1693', '371526', '3715', '高唐县', '3', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('1694', '371581', '3715', '临清市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1695', '3716', '37', '滨州市', '2', '1', '0', '16', 'B');
INSERT INTO `my_pcd` VALUES ('1696', '371601', '3716', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1697', '371602', '3716', '滨城区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('1698', '371621', '3716', '惠民县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('1699', '371622', '3716', '阳信县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1700', '371623', '3716', '无棣县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('1701', '371624', '3716', '沾化县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1702', '371625', '3716', '博兴县', '3', '1', '0', '25', 'B');
INSERT INTO `my_pcd` VALUES ('1703', '371626', '3716', '邹平县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1704', '3717', '37', '菏泽市', '2', '1', '0', '17', 'H');
INSERT INTO `my_pcd` VALUES ('1705', '371701', '3717', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1706', '371702', '3717', '牡丹区', '3', '1', '0', '2', 'M');
INSERT INTO `my_pcd` VALUES ('1707', '371721', '3717', '曹县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('1708', '371722', '3717', '单县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('1709', '371723', '3717', '成武县', '3', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('1710', '371724', '3717', '巨野县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('1711', '371725', '3717', '郓城县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('1712', '371726', '3717', '鄄城县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1713', '371727', '3717', '定陶县', '3', '1', '0', '27', 'D');
INSERT INTO `my_pcd` VALUES ('1714', '371728', '3717', '东明县', '3', '1', '0', '28', 'D');
INSERT INTO `my_pcd` VALUES ('1715', '41', '0', '河南省', '1', '1', '0', '41', 'H');
INSERT INTO `my_pcd` VALUES ('1716', '4101', '41', '郑州市', '2', '1', '0', '1', 'Z');
INSERT INTO `my_pcd` VALUES ('1717', '410101', '4101', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1718', '410102', '4101', '中原区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1719', '410103', '4101', '二七区', '3', '1', '0', '3', 'E');
INSERT INTO `my_pcd` VALUES ('1720', '410104', '4101', '管城回族区', '3', '1', '0', '4', 'G');
INSERT INTO `my_pcd` VALUES ('1721', '410105', '4101', '金水区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('1722', '410106', '4101', '上街区', '3', '1', '0', '6', 'S');
INSERT INTO `my_pcd` VALUES ('1723', '410108', '4101', '惠济区', '3', '1', '0', '8', 'H');
INSERT INTO `my_pcd` VALUES ('1724', '410122', '4101', '中牟县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1725', '410181', '4101', '巩义市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('1726', '410182', '4101', '荥阳市', '3', '1', '0', '82', 'Z');
INSERT INTO `my_pcd` VALUES ('1727', '410183', '4101', '新密市', '3', '1', '0', '83', 'X');
INSERT INTO `my_pcd` VALUES ('1728', '410184', '4101', '新郑市', '3', '1', '0', '84', 'X');
INSERT INTO `my_pcd` VALUES ('1729', '410185', '4101', '登封市', '3', '1', '0', '85', 'D');
INSERT INTO `my_pcd` VALUES ('1730', '4102', '41', '开封市', '2', '1', '0', '2', 'K');
INSERT INTO `my_pcd` VALUES ('1731', '410201', '4102', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1732', '410202', '4102', '龙亭区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1733', '410203', '4102', '顺河区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1734', '410204', '4102', '鼓楼区', '3', '1', '0', '4', 'G');
INSERT INTO `my_pcd` VALUES ('1735', '410205', '4102', '禹王台区', '3', '1', '0', '5', 'Y');
INSERT INTO `my_pcd` VALUES ('1736', '410211', '4102', '金明区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('1737', '410221', '4102', '杞县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('1738', '410222', '4102', '通许县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('1739', '410223', '4102', '尉氏县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('1740', '410224', '4102', '开封县', '3', '1', '0', '24', 'K');
INSERT INTO `my_pcd` VALUES ('1741', '410225', '4102', '兰考县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('1742', '4103', '41', '洛阳市', '2', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('1743', '410301', '4103', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1744', '410302', '4103', '老城区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1745', '410303', '4103', '西工区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('1746', '410304', '4103', '廛河回族区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('1747', '410305', '4103', '涧西区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('1748', '410306', '4103', '吉利区', '3', '1', '0', '6', 'J');
INSERT INTO `my_pcd` VALUES ('1749', '410307', '4103', '洛龙区', '3', '1', '0', '7', 'L');
INSERT INTO `my_pcd` VALUES ('1750', '410322', '4103', '孟津县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('1751', '410323', '4103', '新安县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('1752', '410324', '4103', '栾川县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1753', '410325', '4103', '嵩县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('1754', '410326', '4103', '汝阳县', '3', '1', '0', '26', 'R');
INSERT INTO `my_pcd` VALUES ('1755', '410327', '4103', '宜阳县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('1756', '410328', '4103', '洛宁县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('1757', '410329', '4103', '伊川县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('1758', '410381', '4103', '偃师市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('1759', '4104', '41', '平顶山市', '2', '1', '0', '4', 'P');
INSERT INTO `my_pcd` VALUES ('1760', '410401', '4104', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1761', '410402', '4104', '新华区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1762', '410403', '4104', '卫东区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('1763', '410404', '4104', '石龙区', '3', '1', '0', '4', 'S');
INSERT INTO `my_pcd` VALUES ('1764', '410411', '4104', '湛河区', '3', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('1765', '410421', '4104', '宝丰县', '3', '1', '0', '21', 'B');
INSERT INTO `my_pcd` VALUES ('1766', '410422', '4104', '叶  县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1767', '410423', '4104', '鲁山县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('1768', '410425', '4104', '郏  县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('1769', '410481', '4104', '舞钢市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('1770', '410482', '4104', '汝州市', '3', '1', '0', '82', 'R');
INSERT INTO `my_pcd` VALUES ('1771', '4105', '41', '安阳市', '2', '1', '0', '5', 'A');
INSERT INTO `my_pcd` VALUES ('1772', '410501', '4105', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1773', '410502', '4105', '文峰区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('1774', '410503', '4105', '北关区', '3', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('1775', '410505', '4105', '殷都区', '3', '1', '0', '5', 'Y');
INSERT INTO `my_pcd` VALUES ('1776', '410506', '4105', '龙安区', '3', '1', '0', '6', 'L');
INSERT INTO `my_pcd` VALUES ('1777', '410522', '4105', '安阳县', '3', '1', '0', '22', 'A');
INSERT INTO `my_pcd` VALUES ('1778', '410523', '4105', '汤阴县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('1779', '410526', '4105', '滑县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('1780', '410527', '4105', '内黄县', '3', '1', '0', '27', 'N');
INSERT INTO `my_pcd` VALUES ('1781', '410581', '4105', '林州市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('1782', '4106', '41', '鹤壁市', '2', '1', '0', '6', 'H');
INSERT INTO `my_pcd` VALUES ('1783', '410601', '4106', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1784', '410602', '4106', '鹤山区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1785', '410603', '4106', '山城区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1786', '410611', '4106', '淇滨区', '3', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('1787', '410621', '4106', '浚县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('1788', '410622', '4106', '淇县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1789', '4107', '41', '新乡市', '2', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('1790', '410701', '4107', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1791', '410702', '4107', '红旗区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1792', '410703', '4107', '卫滨区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('1793', '410704', '4107', '凤泉区', '3', '1', '0', '4', 'F');
INSERT INTO `my_pcd` VALUES ('1794', '410711', '4107', '牧野区', '3', '1', '0', '11', 'M');
INSERT INTO `my_pcd` VALUES ('1795', '410721', '4107', '新乡县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('1796', '410724', '4107', '获嘉县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('1797', '410725', '4107', '原阳县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1798', '410726', '4107', '延津县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('1799', '410727', '4107', '封丘县', '3', '1', '0', '27', 'F');
INSERT INTO `my_pcd` VALUES ('1800', '410728', '4107', '长垣县', '3', '1', '0', '28', 'C');
INSERT INTO `my_pcd` VALUES ('1801', '410781', '4107', '卫辉市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('1802', '410782', '4107', '辉县市', '3', '1', '0', '82', 'H');
INSERT INTO `my_pcd` VALUES ('1803', '4108', '41', '焦作市', '2', '1', '0', '8', 'J');
INSERT INTO `my_pcd` VALUES ('1804', '410801', '4108', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1805', '410802', '4108', '解放区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1806', '410803', '4108', '中站区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1807', '410804', '4108', '马村区', '3', '1', '0', '4', 'M');
INSERT INTO `my_pcd` VALUES ('1808', '410811', '4108', '山阳区', '3', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('1809', '410821', '4108', '修武县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('1810', '410822', '4108', '博爱县', '3', '1', '0', '22', 'B');
INSERT INTO `my_pcd` VALUES ('1811', '410823', '4108', '武陟县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('1812', '410825', '4108', '温县', '3', '1', '0', '25', 'W');
INSERT INTO `my_pcd` VALUES ('1813', '410881', '4108', '济源市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('1814', '410882', '4108', '沁阳市', '3', '1', '0', '82', 'Q');
INSERT INTO `my_pcd` VALUES ('1815', '410883', '4108', '孟州市', '3', '1', '0', '83', 'M');
INSERT INTO `my_pcd` VALUES ('1816', '4109', '41', '濮阳市', '2', '1', '0', '9', 'Z');
INSERT INTO `my_pcd` VALUES ('1817', '410901', '4109', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1818', '410902', '4109', '华龙区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1819', '410922', '4109', '清丰县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('1820', '410923', '4109', '南乐县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('1821', '410926', '4109', '范县', '3', '1', '0', '26', 'F');
INSERT INTO `my_pcd` VALUES ('1822', '410927', '4109', '台前县', '3', '1', '0', '27', 'T');
INSERT INTO `my_pcd` VALUES ('1823', '410928', '4109', '濮阳县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('1824', '4110', '41', '许昌市', '2', '1', '0', '10', 'X');
INSERT INTO `my_pcd` VALUES ('1825', '411001', '4110', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1826', '411002', '4110', '魏都区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('1827', '411023', '4110', '许昌县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('1828', '411024', '4110', '鄢陵县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1829', '411025', '4110', '襄城县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('1830', '411081', '4110', '禹州市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1831', '411082', '4110', '长葛市', '3', '1', '0', '82', 'C');
INSERT INTO `my_pcd` VALUES ('1832', '4111', '41', '漯河市', '2', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('1833', '411101', '4111', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1834', '411102', '4111', '源汇区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('1835', '411103', '4111', '郾城区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1836', '411104', '4111', '召陵区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('1837', '411121', '4111', '舞阳县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('1838', '411122', '4111', '临颖县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('1839', '4112', '41', '三门峡市', '2', '1', '0', '12', 'S');
INSERT INTO `my_pcd` VALUES ('1840', '411201', '4112', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1841', '411202', '4112', '湖滨区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1842', '411221', '4112', '渑池县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('1843', '411222', '4112', '陕县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('1844', '411224', '4112', '卢氏县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('1845', '411281', '4112', '义马市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1846', '411282', '4112', '灵宝市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('1847', '4113', '41', '南阳市', '2', '1', '0', '13', 'N');
INSERT INTO `my_pcd` VALUES ('1848', '411301', '4113', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1849', '411302', '4113', '宛城区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('1850', '411303', '4113', '卧龙区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('1851', '411321', '4113', '南召县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('1852', '411322', '4113', '方城县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('1853', '411323', '4113', '西峡县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('1854', '411324', '4113', '镇平县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1855', '411325', '4113', '内乡县', '3', '1', '0', '25', 'N');
INSERT INTO `my_pcd` VALUES ('1856', '411326', '4113', '淅川县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1857', '411327', '4113', '社旗县', '3', '1', '0', '27', 'S');
INSERT INTO `my_pcd` VALUES ('1858', '411328', '4113', '唐河县', '3', '1', '0', '28', 'T');
INSERT INTO `my_pcd` VALUES ('1859', '411329', '4113', '新野县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('1860', '411330', '4113', '桐柏县', '3', '1', '0', '30', 'T');
INSERT INTO `my_pcd` VALUES ('1861', '411381', '4113', '邓州市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('1862', '4114', '41', '商丘市', '2', '1', '0', '14', 'S');
INSERT INTO `my_pcd` VALUES ('1863', '411401', '4114', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1864', '411402', '4114', '梁园区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1865', '411403', '4114', '睢阳区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1866', '411421', '4114', '民权县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('1867', '411422', '4114', '睢县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('1868', '411423', '4114', '宁陵县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('1869', '411424', '4114', '柘城县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1870', '411425', '4114', '虞城县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1871', '411426', '4114', '夏邑县', '3', '1', '0', '26', 'X');
INSERT INTO `my_pcd` VALUES ('1872', '411481', '4114', '永城市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1873', '4115', '41', '信阳市', '2', '1', '0', '15', 'X');
INSERT INTO `my_pcd` VALUES ('1874', '411501', '4115', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1875', '411502', '4115', '浉河区', '3', '1', '0', '2', '');
INSERT INTO `my_pcd` VALUES ('1876', '411503', '4115', '平桥区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('1877', '411521', '4115', '罗山县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('1878', '411522', '4115', '光山县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('1879', '411523', '4115', '新县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('1880', '411524', '4115', '商城县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1881', '411525', '4115', '固始县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('1882', '411526', '4115', '潢川县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('1883', '411527', '4115', '淮滨县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('1884', '411528', '4115', '息县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('1885', '4116', '41', '周口市', '2', '1', '0', '16', 'Z');
INSERT INTO `my_pcd` VALUES ('1886', '411601', '4116', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1887', '411602', '4116', '川汇区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('1888', '411621', '4116', '扶沟县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('1889', '411622', '4116', '西华县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('1890', '411623', '4116', '商水县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('1891', '411624', '4116', '沈丘县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('1892', '411625', '4116', '郸城县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('1893', '411626', '4116', '淮阳县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('1894', '411627', '4116', '太康县', '3', '1', '0', '27', 'T');
INSERT INTO `my_pcd` VALUES ('1895', '411628', '4116', '鹿邑县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('1896', '411681', '4116', '项城市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('1897', '4117', '41', '驻马店市', '2', '1', '0', '17', 'Z');
INSERT INTO `my_pcd` VALUES ('1898', '411701', '4117', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1899', '411702', '4117', '驿城区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('1900', '411721', '4117', '西平县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('1901', '411722', '4117', '上蔡县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('1902', '411723', '4117', '平舆县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('1903', '411724', '4117', '正阳县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1904', '411725', '4117', '确山县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('1905', '411726', '4117', '泌阳县', '3', '1', '0', '26', 'M');
INSERT INTO `my_pcd` VALUES ('1906', '411727', '4117', '汝南县', '3', '1', '0', '27', 'R');
INSERT INTO `my_pcd` VALUES ('1907', '411728', '4117', '遂平县', '3', '1', '0', '28', 'S');
INSERT INTO `my_pcd` VALUES ('1908', '411729', '4117', '新蔡县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('1909', '42', '0', '湖北省', '1', '1', '0', '42', 'H');
INSERT INTO `my_pcd` VALUES ('1910', '4201', '42', '武汉市', '2', '1', '0', '1', 'W');
INSERT INTO `my_pcd` VALUES ('1911', '420101', '4201', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1912', '420102', '4201', '江岸区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('1913', '420103', '4201', '江汉区', '3', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('1914', '420104', '4201', '硚口区', '3', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('1915', '420105', '4201', '汉阳区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('1916', '420106', '4201', '武昌区', '3', '1', '0', '6', 'W');
INSERT INTO `my_pcd` VALUES ('1917', '420107', '4201', '青山区', '3', '1', '0', '7', 'Q');
INSERT INTO `my_pcd` VALUES ('1918', '420111', '4201', '洪山区', '3', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('1919', '420112', '4201', '东西湖区', '3', '1', '0', '12', 'D');
INSERT INTO `my_pcd` VALUES ('1920', '420113', '4201', '汉南区', '3', '1', '0', '13', 'H');
INSERT INTO `my_pcd` VALUES ('1921', '420114', '4201', '蔡甸区', '3', '1', '0', '14', 'C');
INSERT INTO `my_pcd` VALUES ('1922', '420115', '4201', '江夏区', '3', '1', '0', '15', 'J');
INSERT INTO `my_pcd` VALUES ('1923', '420116', '4201', '黄陂区', '3', '1', '0', '16', 'H');
INSERT INTO `my_pcd` VALUES ('1924', '420117', '4201', '武汉市新洲区', '3', '1', '0', '17', 'W');
INSERT INTO `my_pcd` VALUES ('1925', '4202', '42', '黄石市', '2', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1926', '420201', '4202', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1927', '420202', '4202', '黄石港区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('1928', '420203', '4202', '西塞山区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('1929', '420204', '4202', '下陆区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('1930', '420205', '4202', '铁山区', '3', '1', '0', '5', 'T');
INSERT INTO `my_pcd` VALUES ('1931', '420222', '4202', '阳新县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1932', '420281', '4202', '大冶市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('1933', '4203', '42', '十堰市', '2', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('1934', '420301', '4203', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1935', '420302', '4203', '茅箭区', '3', '1', '0', '2', 'M');
INSERT INTO `my_pcd` VALUES ('1936', '420303', '4203', '张湾区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('1937', '420321', '4203', '郧县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('1938', '420322', '4203', '郧西县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('1939', '420323', '4203', '竹山县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('1940', '420324', '4203', '竹溪县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('1941', '420325', '4203', '房县', '3', '1', '0', '25', 'F');
INSERT INTO `my_pcd` VALUES ('1942', '420381', '4203', '丹江口市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('1943', '4205', '42', '宜昌市', '2', '1', '0', '5', 'Y');
INSERT INTO `my_pcd` VALUES ('1944', '420501', '4205', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1945', '420502', '4205', '西陵区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1946', '420503', '4205', '伍家岗区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('1947', '420504', '4205', '点军区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('1948', '420505', '4205', '猇亭区', '3', '1', '0', '5', '');
INSERT INTO `my_pcd` VALUES ('1949', '420506', '4205', '夷陵区', '3', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('1950', '420525', '4205', '远安县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('1951', '420526', '4205', '兴山县', '3', '1', '0', '26', 'X');
INSERT INTO `my_pcd` VALUES ('1952', '420527', '4205', '秭归县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('1953', '420528', '4205', '长阳土家族自治县', '3', '1', '0', '28', 'C');
INSERT INTO `my_pcd` VALUES ('1954', '420529', '4205', '五峰土家族自治县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('1955', '420581', '4205', '宜都市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1956', '420582', '4205', '当阳市', '3', '1', '0', '82', 'D');
INSERT INTO `my_pcd` VALUES ('1957', '420583', '4205', '枝江市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('1958', '4206', '42', '襄樊市', '2', '1', '0', '6', 'X');
INSERT INTO `my_pcd` VALUES ('1959', '420601', '4206', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1960', '420602', '4206', '襄城区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1961', '420606', '4206', '樊城区', '3', '1', '0', '6', 'F');
INSERT INTO `my_pcd` VALUES ('1962', '420607', '4206', '襄阳区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('1963', '420624', '4206', '南漳县', '3', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('1964', '420625', '4206', '谷城县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('1965', '420626', '4206', '保康县', '3', '1', '0', '26', 'B');
INSERT INTO `my_pcd` VALUES ('1966', '420682', '4206', '老河口市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('1967', '420683', '4206', '枣阳市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('1968', '420684', '4206', '宜城市', '3', '1', '0', '84', 'Y');
INSERT INTO `my_pcd` VALUES ('1969', '4207', '42', '鄂州市', '2', '1', '0', '7', 'E');
INSERT INTO `my_pcd` VALUES ('1970', '420701', '4207', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1971', '420702', '4207', '粱子湖区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('1972', '420703', '4207', '华容区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('1973', '420704', '4207', '鄂城区', '3', '1', '0', '4', 'E');
INSERT INTO `my_pcd` VALUES ('1974', '4208', '42', '荆门市', '2', '1', '0', '8', 'J');
INSERT INTO `my_pcd` VALUES ('1975', '420801', '4208', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1976', '420802', '4208', '东宝区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('1977', '420804', '4208', '掇刀区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('1978', '420821', '4208', '京山县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('1979', '420822', '4208', '沙洋县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('1980', '420881', '4208', '钟祥市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('1981', '4209', '42', '孝感市', '2', '1', '0', '9', 'X');
INSERT INTO `my_pcd` VALUES ('1982', '420901', '4209', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1983', '420902', '4209', '孝南区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('1984', '420921', '4209', '孝昌县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('1985', '420922', '4209', '大悟县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('1986', '420923', '4209', '云梦县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('1987', '420981', '4209', '应城市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('1988', '420982', '4209', '安陆市', '3', '1', '0', '82', 'A');
INSERT INTO `my_pcd` VALUES ('1989', '420984', '4209', '汉川市', '3', '1', '0', '84', 'H');
INSERT INTO `my_pcd` VALUES ('1990', '4210', '42', '荆州市', '2', '1', '0', '10', 'J');
INSERT INTO `my_pcd` VALUES ('1991', '421001', '4210', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('1992', '421002', '4210', '沙市区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('1993', '421003', '4210', '荆州区', '3', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('1994', '421022', '4210', '公安县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('1995', '421023', '4210', '监利县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('1996', '421024', '4210', '江陵县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('1997', '421081', '4210', '石首市', '3', '1', '0', '81', 'S');
INSERT INTO `my_pcd` VALUES ('1998', '421083', '4210', '洪湖市', '3', '1', '0', '83', 'H');
INSERT INTO `my_pcd` VALUES ('1999', '421087', '4210', '松滋市', '3', '1', '0', '87', 'S');
INSERT INTO `my_pcd` VALUES ('2000', '4211', '42', '黄冈市', '2', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('2001', '421101', '4211', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2002', '421102', '4211', '黄州区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2003', '421121', '4211', '团风县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('2004', '421122', '4211', '红安县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('2005', '421123', '4211', '罗田县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2006', '421124', '4211', '英山县', '3', '1', '0', '24', 'Y');
INSERT INTO `my_pcd` VALUES ('2007', '421125', '4211', '浠水县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2008', '421126', '4211', '蕲春县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('2009', '421127', '4211', '黄梅县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('2010', '421181', '4211', '麻城市', '3', '1', '0', '81', 'M');
INSERT INTO `my_pcd` VALUES ('2011', '421182', '4211', '武穴市', '3', '1', '0', '82', 'W');
INSERT INTO `my_pcd` VALUES ('2012', '4212', '42', '咸宁市', '2', '1', '0', '12', 'X');
INSERT INTO `my_pcd` VALUES ('2013', '421201', '4212', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2014', '421202', '4212', '咸安区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2015', '421221', '4212', '嘉鱼县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('2016', '421222', '4212', '通城县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2017', '421223', '4212', '崇阳县', '3', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('2018', '421224', '4212', '通山县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('2019', '421281', '4212', '赤壁市', '3', '1', '0', '81', 'C');
INSERT INTO `my_pcd` VALUES ('2020', '4213', '42', '随州市', '2', '1', '0', '13', 'S');
INSERT INTO `my_pcd` VALUES ('2021', '421301', '4213', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2022', '421302', '4213', '曾都区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2023', '421381', '4213', '广水市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('2024', '4228', '42', '恩施州', '2', '1', '0', '28', 'E');
INSERT INTO `my_pcd` VALUES ('2025', '422801', '4228', '恩施市', '3', '1', '0', '1', 'E');
INSERT INTO `my_pcd` VALUES ('2026', '422802', '4228', '利川市', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2027', '422822', '4228', '建始县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('2028', '422823', '4228', '巴东县', '3', '1', '0', '23', 'B');
INSERT INTO `my_pcd` VALUES ('2029', '422825', '4228', '宣恩县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('2030', '422826', '4228', '咸丰县', '3', '1', '0', '26', 'X');
INSERT INTO `my_pcd` VALUES ('2031', '422827', '4228', '来凤县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('2032', '422828', '4228', '鹤峰县', '3', '1', '0', '28', 'H');
INSERT INTO `my_pcd` VALUES ('2033', '4290', '42', '省直辖行政单位', '2', '1', '0', '90', 'S');
INSERT INTO `my_pcd` VALUES ('2034', '429004', '4290', '仙桃市', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('2035', '429005', '4290', '潜江市', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('2036', '429006', '4290', '天门市', '3', '1', '0', '6', 'T');
INSERT INTO `my_pcd` VALUES ('2037', '429021', '4290', '神农架林区', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('2038', '43', '0', '湖南省', '1', '1', '0', '43', 'H');
INSERT INTO `my_pcd` VALUES ('2039', '4301', '43', '长沙市', '2', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('2040', '430101', '4301', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2041', '430102', '4301', '芙蓉区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2042', '430103', '4301', '天心区', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('2043', '430104', '4301', '岳麓区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('2044', '430105', '4301', '开福区', '3', '1', '0', '5', 'K');
INSERT INTO `my_pcd` VALUES ('2045', '430111', '4301', '雨花区', '3', '1', '0', '11', 'Y');
INSERT INTO `my_pcd` VALUES ('2046', '430121', '4301', '长沙县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('2047', '430122', '4301', '望城县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('2048', '430124', '4301', '宁乡县', '3', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('2049', '430181', '4301', '浏阳市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2050', '4302', '43', '株洲市', '2', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2051', '430201', '4302', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2052', '430202', '4302', '荷塘区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2053', '430203', '4302', '芦淞区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('2054', '430204', '4302', '石峰区', '3', '1', '0', '4', 'S');
INSERT INTO `my_pcd` VALUES ('2055', '430211', '4302', '天元区', '3', '1', '0', '11', 'T');
INSERT INTO `my_pcd` VALUES ('2056', '430221', '4302', '株洲县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2057', '430223', '4302', '攸县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('2058', '430224', '4302', '茶陵县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('2059', '430225', '4302', '炎陵县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('2060', '430281', '4302', '醴陵市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2061', '4303', '43', '湘潭市', '2', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('2062', '430301', '4303', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2063', '430302', '4303', '雨湖区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2064', '430304', '4303', '岳塘区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('2065', '430321', '4303', '湘潭县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('2066', '430381', '4303', '湘乡市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('2067', '430382', '4303', '韶山市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('2068', '4304', '43', '衡阳市', '2', '1', '0', '4', 'H');
INSERT INTO `my_pcd` VALUES ('2069', '430401', '4304', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2070', '430405', '4304', '珠晖区', '3', '1', '0', '5', 'Z');
INSERT INTO `my_pcd` VALUES ('2071', '430406', '4304', '雁峰区', '3', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('2072', '430407', '4304', '石鼓区', '3', '1', '0', '7', 'S');
INSERT INTO `my_pcd` VALUES ('2073', '430408', '4304', '蒸湘区', '3', '1', '0', '8', 'Z');
INSERT INTO `my_pcd` VALUES ('2074', '430412', '4304', '南岳区', '3', '1', '0', '12', 'N');
INSERT INTO `my_pcd` VALUES ('2075', '430421', '4304', '衡阳县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('2076', '430422', '4304', '衡南县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('2077', '430423', '4304', '衡山县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('2078', '430424', '4304', '衡东县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('2079', '430426', '4304', '祁东县', '3', '1', '0', '26', 'Q');
INSERT INTO `my_pcd` VALUES ('2080', '430481', '4304', '耒阳市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2081', '430482', '4304', '常宁市', '3', '1', '0', '82', 'C');
INSERT INTO `my_pcd` VALUES ('2082', '4305', '43', '邵阳市', '2', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('2083', '430501', '4305', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2084', '430502', '4305', '双清区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2085', '430503', '4305', '大祥区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('2086', '430511', '4305', '北塔区', '3', '1', '0', '11', 'B');
INSERT INTO `my_pcd` VALUES ('2087', '430521', '4305', '邵东县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('2088', '430522', '4305', '新邵县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('2089', '430523', '4305', '邵阳县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('2090', '430524', '4305', '隆回县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('2091', '430525', '4305', '洞口县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('2092', '430527', '4305', '绥宁县', '3', '1', '0', '27', 'S');
INSERT INTO `my_pcd` VALUES ('2093', '430528', '4305', '新宁县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('2094', '430529', '4305', '城步苗族自治县', '3', '1', '0', '29', 'C');
INSERT INTO `my_pcd` VALUES ('2095', '430581', '4305', '武冈市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('2096', '4306', '43', '岳阳市', '2', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('2097', '430601', '4306', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2098', '430602', '4306', '岳阳楼区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2099', '430603', '4306', '云溪区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('2100', '430611', '4306', '君山区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('2101', '430621', '4306', '岳阳县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('2102', '430623', '4306', '华容县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('2103', '430624', '4306', '湘阴县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('2104', '430626', '4306', '平江县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('2105', '430681', '4306', '汩罗市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2106', '430682', '4306', '临湘市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('2107', '4307', '43', '常德市', '2', '1', '0', '7', 'C');
INSERT INTO `my_pcd` VALUES ('2108', '430701', '4307', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2109', '430702', '4307', '武陵区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('2110', '430703', '4307', '鼎城区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('2111', '430721', '4307', '安乡县', '3', '1', '0', '21', 'A');
INSERT INTO `my_pcd` VALUES ('2112', '430722', '4307', '汉寿县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('2113', '430723', '4307', '澧县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('2114', '430724', '4307', '临澧县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('2115', '430725', '4307', '桃源县', '3', '1', '0', '25', 'T');
INSERT INTO `my_pcd` VALUES ('2116', '430726', '4307', '石门县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('2117', '430781', '4307', '津市市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('2118', '4308', '43', '张家界市', '2', '1', '0', '8', 'Z');
INSERT INTO `my_pcd` VALUES ('2119', '430801', '4308', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2120', '430802', '4308', '永定区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2121', '430811', '4308', '武陵源区', '3', '1', '0', '11', 'W');
INSERT INTO `my_pcd` VALUES ('2122', '430821', '4308', '慈利县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('2123', '430822', '4308', '桑植县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('2124', '4309', '43', '益阳市', '2', '1', '0', '9', 'Y');
INSERT INTO `my_pcd` VALUES ('2125', '430901', '4309', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2126', '430902', '4309', '资阳区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2127', '430903', '4309', '赫山区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('2128', '430921', '4309', '南县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('2129', '430922', '4309', '桃江县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2130', '430923', '4309', '安化县', '3', '1', '0', '23', 'A');
INSERT INTO `my_pcd` VALUES ('2131', '430981', '4309', '沅江市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2132', '4310', '43', '郴州市', '2', '1', '0', '10', 'C');
INSERT INTO `my_pcd` VALUES ('2133', '431001', '4310', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2134', '431002', '4310', '北湖区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('2135', '431003', '4310', '苏仙区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('2136', '431021', '4310', '桂阳县', '3', '1', '0', '21', 'G');
INSERT INTO `my_pcd` VALUES ('2137', '431022', '4310', '宜章县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2138', '431023', '4310', '永兴县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2139', '431024', '4310', '嘉禾县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2140', '431025', '4310', '临武县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('2141', '431026', '4310', '汝城县', '3', '1', '0', '26', 'R');
INSERT INTO `my_pcd` VALUES ('2142', '431027', '4310', '桂东县', '3', '1', '0', '27', 'G');
INSERT INTO `my_pcd` VALUES ('2143', '431028', '4310', '安仁县', '3', '1', '0', '28', 'A');
INSERT INTO `my_pcd` VALUES ('2144', '431081', '4310', '资兴市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2145', '4311', '43', '永州市', '2', '1', '0', '11', 'Y');
INSERT INTO `my_pcd` VALUES ('2146', '431101', '4311', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2147', '431102', '4311', '零陵区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2148', '431103', '4311', '冷水滩区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('2149', '431121', '4311', '祁阳县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('2150', '431122', '4311', '东安县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('2151', '431123', '4311', '双牌县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('2152', '431124', '4311', '道县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2153', '431125', '4311', '江永县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('2154', '431126', '4311', '宁远县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('2155', '431127', '4311', '蓝山县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('2156', '431128', '4311', '新田县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('2157', '431129', '4311', '江华县', '3', '1', '0', '29', 'J');
INSERT INTO `my_pcd` VALUES ('2158', '4312', '43', '怀化市', '2', '1', '0', '12', 'H');
INSERT INTO `my_pcd` VALUES ('2159', '431201', '4312', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2160', '431202', '4312', '鹤城区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2161', '431221', '4312', '中方县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2162', '431222', '4312', '沅陵县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('2163', '431223', '4312', '辰溪县', '3', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('2164', '431224', '4312', '溆浦县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('2165', '431225', '4312', '会同县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('2166', '431226', '4312', '麻阳苗族自治县', '3', '1', '0', '26', 'M');
INSERT INTO `my_pcd` VALUES ('2167', '431227', '4312', '新晃侗族自治县', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('2168', '431228', '4312', '芷江侗族自治县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('2169', '431229', '4312', '靖州苗族侗族县', '3', '1', '0', '29', 'J');
INSERT INTO `my_pcd` VALUES ('2170', '431230', '4312', '通道侗族自治县', '3', '1', '0', '30', 'T');
INSERT INTO `my_pcd` VALUES ('2171', '431281', '4312', '洪江市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('2172', '4313', '43', '娄底市', '2', '1', '0', '13', 'L');
INSERT INTO `my_pcd` VALUES ('2173', '431301', '4313', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2174', '431302', '4313', '娄星区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2175', '431321', '4313', '双峰县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('2176', '431322', '4313', '新化县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('2177', '431381', '4313', '冷水江市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('2178', '431382', '4313', '涟源市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('2179', '4331', '43', '湘西土家族苗族自治州', '2', '1', '0', '31', 'X');
INSERT INTO `my_pcd` VALUES ('2180', '433101', '4331', '吉首市', '3', '1', '0', '1', 'J');
INSERT INTO `my_pcd` VALUES ('2181', '433122', '4331', '泸溪县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('2182', '433123', '4331', '凤凰县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('2183', '433124', '4331', '花垣县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('2184', '433125', '4331', '保靖县', '3', '1', '0', '25', 'B');
INSERT INTO `my_pcd` VALUES ('2185', '433126', '4331', '古丈县', '3', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('2186', '433127', '4331', '永顺县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('2187', '433130', '4331', '龙山县', '3', '1', '0', '30', 'L');
INSERT INTO `my_pcd` VALUES ('2188', '44', '0', '广东省', '1', '1', '0', '44', 'G');
INSERT INTO `my_pcd` VALUES ('2189', '4401', '44', '广州市', '2', '1', '0', '1', 'G');
INSERT INTO `my_pcd` VALUES ('2190', '440101', '4401', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2191', '440103', '4401', '荔湾区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('2192', '440104', '4401', '越秀区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('2193', '440105', '4401', '海珠区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('2194', '440106', '4401', '天河区', '3', '1', '0', '6', 'T');
INSERT INTO `my_pcd` VALUES ('2195', '440111', '4401', '白云区', '3', '1', '0', '11', 'B');
INSERT INTO `my_pcd` VALUES ('2196', '440112', '4401', '黄埔区', '3', '1', '0', '12', 'H');
INSERT INTO `my_pcd` VALUES ('2197', '440113', '4401', '番禺区', '3', '1', '0', '13', 'F');
INSERT INTO `my_pcd` VALUES ('2198', '440114', '4401', '花都区', '3', '1', '0', '14', 'H');
INSERT INTO `my_pcd` VALUES ('2199', '440115', '4401', '南沙区', '3', '1', '0', '15', 'N');
INSERT INTO `my_pcd` VALUES ('2200', '440116', '4401', '萝岗区', '3', '1', '0', '16', 'L');
INSERT INTO `my_pcd` VALUES ('2201', '440183', '4401', '增城市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('2202', '440184', '4401', '从化市', '3', '1', '0', '84', 'C');
INSERT INTO `my_pcd` VALUES ('2203', '4402', '44', '韶关市', '2', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2204', '440201', '4402', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2205', '440203', '4402', '武江区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('2206', '440204', '4402', '浈江区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('2207', '440205', '4402', '曲江区', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('2208', '440222', '4402', '始兴县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('2209', '440224', '4402', '仁化县', '3', '1', '0', '24', 'R');
INSERT INTO `my_pcd` VALUES ('2210', '440229', '4402', '翁源县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('2211', '440232', '4402', '乳源瑶族自治县', '3', '1', '0', '32', 'R');
INSERT INTO `my_pcd` VALUES ('2212', '440233', '4402', '新丰县', '3', '1', '0', '33', 'X');
INSERT INTO `my_pcd` VALUES ('2213', '440281', '4402', '乐昌市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('2214', '440282', '4402', '南雄市', '3', '1', '0', '82', 'N');
INSERT INTO `my_pcd` VALUES ('2215', '4403', '44', '深圳市', '2', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('2216', '440301', '4403', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2217', '440303', '4403', '罗湖区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('2218', '440304', '4403', '福田区', '3', '1', '0', '4', 'F');
INSERT INTO `my_pcd` VALUES ('2219', '440305', '4403', '南山区', '3', '1', '0', '5', 'N');
INSERT INTO `my_pcd` VALUES ('2220', '440306', '4403', '宝安区', '3', '1', '0', '6', 'B');
INSERT INTO `my_pcd` VALUES ('2221', '440307', '4403', '龙岗区', '3', '1', '0', '7', 'L');
INSERT INTO `my_pcd` VALUES ('2222', '440308', '4403', '盐田区', '3', '1', '0', '8', 'Y');
INSERT INTO `my_pcd` VALUES ('2223', '4404', '44', '珠海市', '2', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('2224', '440401', '4404', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2225', '440402', '4404', '香洲区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2226', '440403', '4404', '斗门区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('2227', '440404', '4404', '金湾区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('2228', '4405', '44', '汕头市', '2', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('2229', '440501', '4405', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2230', '440507', '4405', '龙湖区', '3', '1', '0', '7', 'L');
INSERT INTO `my_pcd` VALUES ('2231', '440511', '4405', '金平区', '3', '1', '0', '11', 'J');
INSERT INTO `my_pcd` VALUES ('2232', '440512', '4405', '濠江区', '3', '1', '0', '12', 'Z');
INSERT INTO `my_pcd` VALUES ('2233', '440513', '4405', '潮阳区', '3', '1', '0', '13', 'C');
INSERT INTO `my_pcd` VALUES ('2234', '440514', '4405', '潮南区', '3', '1', '0', '14', 'C');
INSERT INTO `my_pcd` VALUES ('2235', '440515', '4405', '澄海区', '3', '1', '0', '15', 'C');
INSERT INTO `my_pcd` VALUES ('2236', '440523', '4405', '南澳县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('2237', '4406', '44', '佛山市', '2', '1', '0', '6', 'F');
INSERT INTO `my_pcd` VALUES ('2238', '440601', '4406', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2239', '440604', '4406', '禅城区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('2240', '440605', '4406', '南海区', '3', '1', '0', '5', 'N');
INSERT INTO `my_pcd` VALUES ('2241', '440606', '4406', '顺德区', '3', '1', '0', '6', 'S');
INSERT INTO `my_pcd` VALUES ('2242', '440607', '4406', '三水区', '3', '1', '0', '7', 'S');
INSERT INTO `my_pcd` VALUES ('2243', '440608', '4406', '高明区', '3', '1', '0', '8', 'G');
INSERT INTO `my_pcd` VALUES ('2244', '4407', '44', '江门市', '2', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('2245', '440701', '4407', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2246', '440703', '4407', '蓬江区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('2247', '440704', '4407', '江海区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('2248', '440705', '4407', '新会区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('2249', '440781', '4407', '台山市', '3', '1', '0', '81', 'T');
INSERT INTO `my_pcd` VALUES ('2250', '440783', '4407', '开平市', '3', '1', '0', '83', 'K');
INSERT INTO `my_pcd` VALUES ('2251', '440784', '4407', '鹤山市', '3', '1', '0', '84', 'H');
INSERT INTO `my_pcd` VALUES ('2252', '440785', '4407', '恩平市', '3', '1', '0', '85', 'E');
INSERT INTO `my_pcd` VALUES ('2253', '4408', '44', '湛江市', '2', '1', '0', '8', 'Z');
INSERT INTO `my_pcd` VALUES ('2254', '440801', '4408', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2255', '440802', '4408', '湛江市赤坎区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2256', '440803', '4408', '湛江市霞山区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('2257', '440804', '4408', '湛江市坡头区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('2258', '440811', '4408', '湛江市麻章区', '3', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('2259', '440823', '4408', '遂溪县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('2260', '440825', '4408', '徐闻县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('2261', '440881', '4408', '廉江市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('2262', '440882', '4408', '雷州市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('2263', '440883', '4408', '吴川市', '3', '1', '0', '83', 'W');
INSERT INTO `my_pcd` VALUES ('2264', '4409', '44', '茂名市', '2', '1', '0', '9', 'M');
INSERT INTO `my_pcd` VALUES ('2265', '440901', '4409', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2266', '440902', '4409', '茂南区', '3', '1', '0', '2', 'M');
INSERT INTO `my_pcd` VALUES ('2267', '440903', '4409', '茂港区', '3', '1', '0', '3', 'M');
INSERT INTO `my_pcd` VALUES ('2268', '440923', '4409', '电白县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('2269', '440981', '4409', '高州市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('2270', '440982', '4409', '化州市', '3', '1', '0', '82', 'H');
INSERT INTO `my_pcd` VALUES ('2271', '440983', '4409', '信宜市', '3', '1', '0', '83', 'X');
INSERT INTO `my_pcd` VALUES ('2272', '4412', '44', '肇庆市', '2', '1', '0', '12', 'Z');
INSERT INTO `my_pcd` VALUES ('2273', '441201', '4412', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2274', '441202', '4412', '端州区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('2275', '441203', '4412', '鼎湖区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('2276', '441223', '4412', '广宁县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('2277', '441224', '4412', '怀集县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('2278', '441225', '4412', '封开县', '3', '1', '0', '25', 'F');
INSERT INTO `my_pcd` VALUES ('2279', '441226', '4412', '德庆县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('2280', '441283', '4412', '高要市', '3', '1', '0', '83', 'G');
INSERT INTO `my_pcd` VALUES ('2281', '441284', '4412', '四会市', '3', '1', '0', '84', 'S');
INSERT INTO `my_pcd` VALUES ('2282', '4413', '44', '惠州市', '2', '1', '0', '13', 'H');
INSERT INTO `my_pcd` VALUES ('2283', '441301', '4413', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2284', '441302', '4413', '惠城区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2285', '441303', '4413', '惠阳区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('2286', '441322', '4413', '博罗县', '3', '1', '0', '22', 'B');
INSERT INTO `my_pcd` VALUES ('2287', '441323', '4413', '惠东县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('2288', '441324', '4413', '龙门县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('2289', '4414', '44', '梅州市', '2', '1', '0', '14', 'M');
INSERT INTO `my_pcd` VALUES ('2290', '441401', '4414', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2291', '441402', '4414', '梅江区', '3', '1', '0', '2', 'M');
INSERT INTO `my_pcd` VALUES ('2292', '441421', '4414', '梅县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('2293', '441422', '4414', '大埔县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('2294', '441423', '4414', '丰顺县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('2295', '441424', '4414', '五华县', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('2296', '441426', '4414', '平远县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('2297', '441427', '4414', '蕉岭县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('2298', '441481', '4414', '兴宁市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('2299', '4415', '44', '汕尾市', '2', '1', '0', '15', 'S');
INSERT INTO `my_pcd` VALUES ('2300', '441501', '4415', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2301', '441502', '4415', '城区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('2302', '441521', '4415', '海丰县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('2303', '441523', '4415', '陆河县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2304', '441581', '4415', '陆丰市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('2305', '4416', '44', '河源市', '2', '1', '0', '16', 'H');
INSERT INTO `my_pcd` VALUES ('2306', '441601', '4416', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2307', '441602', '4416', '源城区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2308', '441621', '4416', '紫金县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2309', '441622', '4416', '龙川县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2310', '441623', '4416', '连平县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2311', '441624', '4416', '和平县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('2312', '441625', '4416', '东源县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('2313', '4417', '44', '阳江市', '2', '1', '0', '17', 'Y');
INSERT INTO `my_pcd` VALUES ('2314', '441701', '4417', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2315', '441702', '4417', '江城区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('2316', '441721', '4417', '阳西县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('2317', '441723', '4417', '阳东县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2318', '441781', '4417', '阳春市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('2319', '4418', '44', '清远市', '2', '1', '0', '18', 'Q');
INSERT INTO `my_pcd` VALUES ('2320', '441801', '4418', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2321', '441802', '4418', '清城区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('2322', '441821', '4418', '佛冈县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('2323', '441823', '4418', '阳山县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2324', '441825', '4418', '连山县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('2325', '441826', '4418', '连南瑶族自治县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('2326', '441827', '4418', '清新县', '3', '1', '0', '27', 'Q');
INSERT INTO `my_pcd` VALUES ('2327', '441881', '4418', '英德市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('2328', '441882', '4418', '连州市', '3', '1', '0', '82', 'L');
INSERT INTO `my_pcd` VALUES ('2329', '4419', '44', '东莞市', '2', '1', '0', '19', 'D');
INSERT INTO `my_pcd` VALUES ('2330', '4420', '44', '中山市', '2', '1', '0', '20', 'Z');
INSERT INTO `my_pcd` VALUES ('2331', '4451', '44', '潮州市', '2', '1', '0', '51', 'C');
INSERT INTO `my_pcd` VALUES ('2332', '445101', '4451', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2333', '445102', '4451', '潮州市湘桥区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('2334', '445121', '4451', '潮州市潮安县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('2335', '445122', '4451', '潮州市饶平县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('2336', '4452', '44', '揭阳市', '2', '1', '0', '52', 'J');
INSERT INTO `my_pcd` VALUES ('2337', '445201', '4452', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2338', '445202', '4452', '榕城区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2339', '445221', '4452', '揭东县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('2340', '445222', '4452', '揭西县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('2341', '445224', '4452', '惠来县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('2342', '445281', '4452', '普宁市', '3', '1', '0', '81', 'P');
INSERT INTO `my_pcd` VALUES ('2343', '4453', '44', '云浮市', '2', '1', '0', '53', 'Y');
INSERT INTO `my_pcd` VALUES ('2344', '445301', '4453', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2345', '445302', '4453', '云城区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2346', '445321', '4453', '新兴县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('2347', '445322', '4453', '郁南县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2348', '445323', '4453', '云安县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2349', '445381', '4453', '罗定市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('2350', '45', '0', '广西壮族自治区', '1', '1', '0', '45', 'G');
INSERT INTO `my_pcd` VALUES ('2351', '4501', '45', '南宁市', '2', '1', '0', '1', 'N');
INSERT INTO `my_pcd` VALUES ('2352', '450101', '4501', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2353', '450102', '4501', '兴宁区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2354', '450103', '4501', '青秀区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('2355', '450105', '4501', '江南区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('2356', '450107', '4501', '西乡塘区', '3', '1', '0', '7', 'X');
INSERT INTO `my_pcd` VALUES ('2357', '450108', '4501', '良庆区', '3', '1', '0', '8', 'L');
INSERT INTO `my_pcd` VALUES ('2358', '450109', '4501', '邕宁区', '3', '1', '0', '9', 'Z');
INSERT INTO `my_pcd` VALUES ('2359', '450122', '4501', '武鸣县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('2360', '450123', '4501', '隆安县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2361', '450124', '4501', '马山县', '3', '1', '0', '24', 'M');
INSERT INTO `my_pcd` VALUES ('2362', '450125', '4501', '上林县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('2363', '450126', '4501', '宾阳县', '3', '1', '0', '26', 'B');
INSERT INTO `my_pcd` VALUES ('2364', '450127', '4501', '横县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('2365', '4502', '45', '柳州市', '2', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2366', '450201', '4502', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2367', '450202', '4502', '城中区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('2368', '450203', '4502', '鱼峰区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('2369', '450204', '4502', '柳南区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('2370', '450205', '4502', '柳北区', '3', '1', '0', '5', 'L');
INSERT INTO `my_pcd` VALUES ('2371', '450221', '4502', '柳江县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('2372', '450222', '4502', '柳城县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2373', '450223', '4502', '鹿寨县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2374', '450224', '4502', '融安县', '3', '1', '0', '24', 'R');
INSERT INTO `my_pcd` VALUES ('2375', '450225', '4502', '融水苗族自治县', '3', '1', '0', '25', 'R');
INSERT INTO `my_pcd` VALUES ('2376', '450226', '4502', '三江侗族自治县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('2377', '4503', '45', '桂林市', '2', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('2378', '450301', '4503', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2379', '450302', '4503', '秀峰区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2380', '450303', '4503', '叠彩区', '3', '1', '0', '3', 'D');
INSERT INTO `my_pcd` VALUES ('2381', '450304', '4503', '象山区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('2382', '450305', '4503', '七星区', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('2383', '450311', '4503', '雁山区', '3', '1', '0', '11', 'Y');
INSERT INTO `my_pcd` VALUES ('2384', '450321', '4503', '阳朔县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('2385', '450322', '4503', '临桂县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2386', '450323', '4503', '灵川县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2387', '450324', '4503', '全州县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('2388', '450325', '4503', '兴安县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('2389', '450326', '4503', '永福县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('2390', '450327', '4503', '灌阳县', '3', '1', '0', '27', 'G');
INSERT INTO `my_pcd` VALUES ('2391', '450328', '4503', '龙胜各族自治县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2392', '450329', '4503', '资源县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('2393', '450330', '4503', '平乐县', '3', '1', '0', '30', 'P');
INSERT INTO `my_pcd` VALUES ('2394', '450331', '4503', '荔浦县', '3', '1', '0', '31', 'L');
INSERT INTO `my_pcd` VALUES ('2395', '450332', '4503', '恭城县', '3', '1', '0', '32', 'G');
INSERT INTO `my_pcd` VALUES ('2396', '4504', '45', '梧州市', '2', '1', '0', '4', 'W');
INSERT INTO `my_pcd` VALUES ('2397', '450401', '4504', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2398', '450403', '4504', '万秀区', '3', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('2399', '450404', '4504', '蝶山区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('2400', '450405', '4504', '长洲区', '3', '1', '0', '5', 'C');
INSERT INTO `my_pcd` VALUES ('2401', '450421', '4504', '苍梧县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('2402', '450422', '4504', '藤县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2403', '450423', '4504', '蒙山县', '3', '1', '0', '23', 'M');
INSERT INTO `my_pcd` VALUES ('2404', '450481', '4504', '岑溪市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2405', '4505', '45', '北海市', '2', '1', '0', '5', 'B');
INSERT INTO `my_pcd` VALUES ('2406', '450501', '4505', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2407', '450502', '4505', '海城区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2408', '450503', '4505', '银海区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('2409', '450512', '4505', '铁山港区', '3', '1', '0', '12', 'T');
INSERT INTO `my_pcd` VALUES ('2410', '450521', '4505', '合浦县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('2411', '4506', '45', '防城港市', '2', '1', '0', '6', 'F');
INSERT INTO `my_pcd` VALUES ('2412', '450601', '4506', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2413', '450602', '4506', '港口区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('2414', '450603', '4506', '防城区', '3', '1', '0', '3', 'F');
INSERT INTO `my_pcd` VALUES ('2415', '450621', '4506', '上思县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('2416', '450681', '4506', '东兴市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('2417', '4507', '45', '钦州市', '2', '1', '0', '7', 'Q');
INSERT INTO `my_pcd` VALUES ('2418', '450701', '4507', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2419', '450702', '4507', '钦南区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('2420', '450703', '4507', '钦北区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('2421', '450721', '4507', '灵山县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('2422', '450722', '4507', '浦北县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('2423', '4508', '45', '贵港市', '2', '1', '0', '8', 'G');
INSERT INTO `my_pcd` VALUES ('2424', '450801', '4508', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2425', '450802', '4508', '港北区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('2426', '450803', '4508', '港南区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('2427', '450804', '4508', '覃塘区', '3', '1', '0', '4', 'Z');
INSERT INTO `my_pcd` VALUES ('2428', '450821', '4508', '平南县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('2429', '450881', '4508', '桂平市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('2430', '4509', '45', '玉林市', '2', '1', '0', '9', 'Y');
INSERT INTO `my_pcd` VALUES ('2431', '450901', '4509', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2432', '450902', '4509', '玉州区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2433', '450921', '4509', '容县', '3', '1', '0', '21', 'R');
INSERT INTO `my_pcd` VALUES ('2434', '450922', '4509', '陆川县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2435', '450923', '4509', '博白县', '3', '1', '0', '23', 'B');
INSERT INTO `my_pcd` VALUES ('2436', '450924', '4509', '兴业县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('2437', '450981', '4509', '北流市', '3', '1', '0', '81', 'B');
INSERT INTO `my_pcd` VALUES ('2438', '4510', '45', '百色市', '2', '1', '0', '10', 'B');
INSERT INTO `my_pcd` VALUES ('2439', '451001', '4510', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2440', '451002', '4510', '右江区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2441', '451021', '4510', '田阳县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('2442', '451022', '4510', '田东县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2443', '451023', '4510', '平果县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('2444', '451024', '4510', '德保县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2445', '451025', '4510', '靖西县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('2446', '451026', '4510', '那坡县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('2447', '451027', '4510', '凌云县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('2448', '451028', '4510', '乐业县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2449', '451029', '4510', '田林县', '3', '1', '0', '29', 'T');
INSERT INTO `my_pcd` VALUES ('2450', '451030', '4510', '西林县', '3', '1', '0', '30', 'X');
INSERT INTO `my_pcd` VALUES ('2451', '451031', '4510', '隆林各族自治县', '3', '1', '0', '31', 'L');
INSERT INTO `my_pcd` VALUES ('2452', '4511', '45', '贺州市', '2', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('2453', '451101', '4511', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2454', '451102', '4511', '八步区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('2455', '451121', '4511', '昭平县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2456', '451122', '4511', '钟山县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('2457', '451123', '4511', '富川瑶族自治县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('2458', '4512', '45', '河池市', '2', '1', '0', '12', 'H');
INSERT INTO `my_pcd` VALUES ('2459', '451201', '4512', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2460', '451202', '4512', '金城江区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('2461', '451221', '4512', '南丹县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('2462', '451222', '4512', '天峨县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2463', '451223', '4512', '凤山县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('2464', '451224', '4512', '东兰县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2465', '451225', '4512', '罗城仫佬族自治县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('2466', '451226', '4512', '环江毛南族自治县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('2467', '451227', '4512', '巴马瑶族自治县', '3', '1', '0', '27', 'B');
INSERT INTO `my_pcd` VALUES ('2468', '451228', '4512', '都安瑶族自治县', '3', '1', '0', '28', 'D');
INSERT INTO `my_pcd` VALUES ('2469', '451229', '4512', '大化瑶族自治县', '3', '1', '0', '29', 'D');
INSERT INTO `my_pcd` VALUES ('2470', '451281', '4512', '宜州市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('2471', '4513', '45', '来宾市', '2', '1', '0', '13', 'L');
INSERT INTO `my_pcd` VALUES ('2472', '451301', '4513', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2473', '451302', '4513', '兴宾区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2474', '451321', '4513', '忻城县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('2475', '451322', '4513', '象州县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('2476', '451323', '4513', '武宣县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('2477', '451324', '4513', '金秀瑶族自治县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2478', '451381', '4513', '合山市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('2479', '4514', '45', '崇左市', '2', '1', '0', '14', 'C');
INSERT INTO `my_pcd` VALUES ('2480', '451401', '4514', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2481', '451402', '4514', '江州区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('2482', '451421', '4514', '扶绥县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('2483', '451422', '4514', '宁明县', '3', '1', '0', '22', 'N');
INSERT INTO `my_pcd` VALUES ('2484', '451423', '4514', '龙州县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2485', '451424', '4514', '大新县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2486', '451425', '4514', '天等县', '3', '1', '0', '25', 'T');
INSERT INTO `my_pcd` VALUES ('2487', '451481', '4514', '凭祥市', '3', '1', '0', '81', 'P');
INSERT INTO `my_pcd` VALUES ('2488', '46', '0', '海南省', '1', '1', '0', '46', 'H');
INSERT INTO `my_pcd` VALUES ('2489', '4601', '46', '海口市', '2', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('2490', '460101', '4601', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2491', '460105', '4601', '秀英区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('2492', '460106', '4601', '龙华区', '3', '1', '0', '6', 'L');
INSERT INTO `my_pcd` VALUES ('2493', '460107', '4601', '琼山区', '3', '1', '0', '7', 'Q');
INSERT INTO `my_pcd` VALUES ('2494', '460108', '4601', '美兰区', '3', '1', '0', '8', 'M');
INSERT INTO `my_pcd` VALUES ('2495', '4602', '46', '三亚市', '2', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2496', '460201', '4602', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2497', '4690', '46', '省属虚拟市', '2', '1', '0', '90', 'S');
INSERT INTO `my_pcd` VALUES ('2498', '469001', '4690', '五指山市', '3', '1', '0', '1', 'W');
INSERT INTO `my_pcd` VALUES ('2499', '469002', '4690', '琼海市', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('2500', '469003', '4690', '儋州市', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('2501', '469005', '4690', '文昌市', '3', '1', '0', '5', 'W');
INSERT INTO `my_pcd` VALUES ('2502', '469006', '4690', '万宁市', '3', '1', '0', '6', 'W');
INSERT INTO `my_pcd` VALUES ('2503', '469007', '4690', '东方市', '3', '1', '0', '7', 'D');
INSERT INTO `my_pcd` VALUES ('2504', '469025', '4690', '定安县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('2505', '469026', '4690', '屯昌县', '3', '1', '0', '26', 'T');
INSERT INTO `my_pcd` VALUES ('2506', '469027', '4690', '澄迈县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('2507', '469028', '4690', '临高县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2508', '469030', '4690', '白沙黎族自治县', '3', '1', '0', '30', 'B');
INSERT INTO `my_pcd` VALUES ('2509', '469031', '4690', '昌江黎族自治县', '3', '1', '0', '31', 'C');
INSERT INTO `my_pcd` VALUES ('2510', '469033', '4690', '乐东黎族自治县', '3', '1', '0', '33', 'L');
INSERT INTO `my_pcd` VALUES ('2511', '469034', '4690', '陵水黎族自治县', '3', '1', '0', '34', 'L');
INSERT INTO `my_pcd` VALUES ('2512', '469035', '4690', '保亭黎族苗族自治县', '3', '1', '0', '35', 'B');
INSERT INTO `my_pcd` VALUES ('2513', '469036', '4690', '琼中黎族苗族自治县', '3', '1', '0', '36', 'Q');
INSERT INTO `my_pcd` VALUES ('2514', '469037', '4690', '西沙群岛', '3', '1', '0', '37', 'X');
INSERT INTO `my_pcd` VALUES ('2515', '469038', '4690', '南沙群岛', '3', '1', '0', '38', 'N');
INSERT INTO `my_pcd` VALUES ('2516', '469039', '4690', '中沙群岛的岛礁及其海域', '3', '1', '0', '39', 'Z');
INSERT INTO `my_pcd` VALUES ('2517', '50', '0', '重庆市', '1', '1', '0', '50', 'C');
INSERT INTO `my_pcd` VALUES ('2518', '5001', '50', '市辖区', '2', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2519', '500101', '5001', '万州区', '3', '1', '0', '1', 'W');
INSERT INTO `my_pcd` VALUES ('2520', '500102', '5001', '涪陵区', '3', '1', '0', '2', 'F');
INSERT INTO `my_pcd` VALUES ('2521', '500103', '5001', '渝中区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('2522', '500104', '5001', '大渡口区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('2523', '500105', '5001', '江北区', '3', '1', '0', '5', 'J');
INSERT INTO `my_pcd` VALUES ('2524', '500106', '5001', '沙坪坝区', '3', '1', '0', '6', 'S');
INSERT INTO `my_pcd` VALUES ('2525', '500107', '5001', '九龙坡区', '3', '1', '0', '7', 'J');
INSERT INTO `my_pcd` VALUES ('2526', '500108', '5001', '南岸区', '3', '1', '0', '8', 'N');
INSERT INTO `my_pcd` VALUES ('2527', '500109', '5001', '北碚区', '3', '1', '0', '9', 'B');
INSERT INTO `my_pcd` VALUES ('2528', '500110', '5001', '万盛区', '3', '1', '0', '10', 'W');
INSERT INTO `my_pcd` VALUES ('2529', '500111', '5001', '双桥区', '3', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('2530', '500112', '5001', '渝北区', '3', '1', '0', '12', 'Y');
INSERT INTO `my_pcd` VALUES ('2531', '500113', '5001', '巴南区', '3', '1', '0', '13', 'B');
INSERT INTO `my_pcd` VALUES ('2532', '500114', '5001', '黔江区', '3', '1', '0', '14', 'Q');
INSERT INTO `my_pcd` VALUES ('2533', '500115', '5001', '长寿区', '3', '1', '0', '15', 'C');
INSERT INTO `my_pcd` VALUES ('2534', '500116', '5001', '江津区', '3', '1', '0', '16', 'J');
INSERT INTO `my_pcd` VALUES ('2535', '500117', '5001', '合川区', '3', '1', '0', '17', 'H');
INSERT INTO `my_pcd` VALUES ('2536', '500118', '5001', '永川区', '3', '1', '0', '18', 'Y');
INSERT INTO `my_pcd` VALUES ('2537', '500119', '5001', '南川区', '3', '1', '0', '19', 'N');
INSERT INTO `my_pcd` VALUES ('2538', '5002', '50', '县', '2', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2539', '500222', '5002', '綦江县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('2540', '500223', '5002', '潼南县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('2541', '500224', '5002', '铜梁县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('2542', '500225', '5002', '大足县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('2543', '500226', '5002', '荣昌县', '3', '1', '0', '26', 'R');
INSERT INTO `my_pcd` VALUES ('2544', '500227', '5002', '璧山县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('2545', '500228', '5002', '梁平县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2546', '500229', '5002', '城口县', '3', '1', '0', '29', 'C');
INSERT INTO `my_pcd` VALUES ('2547', '500230', '5002', '丰都县', '3', '1', '0', '30', 'F');
INSERT INTO `my_pcd` VALUES ('2548', '500231', '5002', '垫江县', '3', '1', '0', '31', 'D');
INSERT INTO `my_pcd` VALUES ('2549', '500232', '5002', '武隆县', '3', '1', '0', '32', 'W');
INSERT INTO `my_pcd` VALUES ('2550', '500233', '5002', '忠县', '3', '1', '0', '33', 'Z');
INSERT INTO `my_pcd` VALUES ('2551', '500234', '5002', '开县', '3', '1', '0', '34', 'K');
INSERT INTO `my_pcd` VALUES ('2552', '500235', '5002', '云阳县', '3', '1', '0', '35', 'Y');
INSERT INTO `my_pcd` VALUES ('2553', '500236', '5002', '奉节县', '3', '1', '0', '36', 'F');
INSERT INTO `my_pcd` VALUES ('2554', '500237', '5002', '巫山县', '3', '1', '0', '37', 'W');
INSERT INTO `my_pcd` VALUES ('2555', '500238', '5002', '巫溪县', '3', '1', '0', '38', 'W');
INSERT INTO `my_pcd` VALUES ('2556', '500240', '5002', '石柱县', '3', '1', '0', '40', 'S');
INSERT INTO `my_pcd` VALUES ('2557', '500241', '5002', '秀山土家族苗族自治县', '3', '1', '0', '41', 'X');
INSERT INTO `my_pcd` VALUES ('2558', '500242', '5002', '酉阳土家族苗族自治县', '3', '1', '0', '42', 'Y');
INSERT INTO `my_pcd` VALUES ('2559', '500243', '5002', '彭水苗族土家族自治县', '3', '1', '0', '43', 'P');
INSERT INTO `my_pcd` VALUES ('2560', '51', '0', '四川省', '1', '1', '0', '51', 'S');
INSERT INTO `my_pcd` VALUES ('2561', '5101', '51', '成都市', '2', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('2562', '510101', '5101', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2563', '510104', '5101', '锦江区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('2564', '510105', '5101', '青羊区', '3', '1', '0', '5', 'Q');
INSERT INTO `my_pcd` VALUES ('2565', '510106', '5101', '金牛区', '3', '1', '0', '6', 'J');
INSERT INTO `my_pcd` VALUES ('2566', '510107', '5101', '武侯区', '3', '1', '0', '7', 'W');
INSERT INTO `my_pcd` VALUES ('2567', '510108', '5101', '成华区', '3', '1', '0', '8', 'C');
INSERT INTO `my_pcd` VALUES ('2568', '510112', '5101', '龙泉驿区', '3', '1', '0', '12', 'L');
INSERT INTO `my_pcd` VALUES ('2569', '510113', '5101', '青白江区', '3', '1', '0', '13', 'Q');
INSERT INTO `my_pcd` VALUES ('2570', '510114', '5101', '新都区', '3', '1', '0', '14', 'X');
INSERT INTO `my_pcd` VALUES ('2571', '510115', '5101', '温江区', '3', '1', '0', '15', 'W');
INSERT INTO `my_pcd` VALUES ('2572', '510121', '5101', '金堂县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('2573', '510122', '5101', '双流县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('2574', '510124', '5101', '郫县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('2575', '510129', '5101', '大邑县', '3', '1', '0', '29', 'D');
INSERT INTO `my_pcd` VALUES ('2576', '510131', '5101', '蒲江县', '3', '1', '0', '31', 'P');
INSERT INTO `my_pcd` VALUES ('2577', '510132', '5101', '新津县', '3', '1', '0', '32', 'X');
INSERT INTO `my_pcd` VALUES ('2578', '510181', '5101', '都江堰市', '3', '1', '0', '81', 'D');
INSERT INTO `my_pcd` VALUES ('2579', '510182', '5101', '彭州市', '3', '1', '0', '82', 'P');
INSERT INTO `my_pcd` VALUES ('2580', '510183', '5101', '邛崃市', '3', '1', '0', '83', 'Z');
INSERT INTO `my_pcd` VALUES ('2581', '510184', '5101', '崇州市', '3', '1', '0', '84', 'C');
INSERT INTO `my_pcd` VALUES ('2582', '5103', '51', '自贡市', '2', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('2583', '510301', '5103', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2584', '510302', '5103', '自流井区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2585', '510303', '5103', '贡井区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('2586', '510304', '5103', '大安区', '3', '1', '0', '4', 'D');
INSERT INTO `my_pcd` VALUES ('2587', '510311', '5103', '沿滩区', '3', '1', '0', '11', 'Y');
INSERT INTO `my_pcd` VALUES ('2588', '510321', '5103', '荣县', '3', '1', '0', '21', 'R');
INSERT INTO `my_pcd` VALUES ('2589', '510322', '5103', '富顺县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('2590', '5104', '51', '攀枝花市', '2', '1', '0', '4', 'P');
INSERT INTO `my_pcd` VALUES ('2591', '510401', '5104', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2592', '510402', '5104', '攀枝花东区', '3', '1', '0', '2', 'P');
INSERT INTO `my_pcd` VALUES ('2593', '510403', '5104', '西区', '3', '1', '0', '3', 'X');
INSERT INTO `my_pcd` VALUES ('2594', '510411', '5104', '仁和区', '3', '1', '0', '11', 'R');
INSERT INTO `my_pcd` VALUES ('2595', '510421', '5104', '米易县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('2596', '510422', '5104', '盐边县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2597', '5105', '51', '泸州市', '2', '1', '0', '5', 'Z');
INSERT INTO `my_pcd` VALUES ('2598', '510501', '5105', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2599', '510502', '5105', '江阳区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('2600', '510503', '5105', '纳溪区', '3', '1', '0', '3', 'N');
INSERT INTO `my_pcd` VALUES ('2601', '510504', '5105', '龙马潭区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('2602', '510521', '5105', '泸县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2603', '510522', '5105', '合江县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('2604', '510524', '5105', '叙永县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('2605', '510525', '5105', '古蔺县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('2606', '5106', '51', '德阳市', '2', '1', '0', '6', 'D');
INSERT INTO `my_pcd` VALUES ('2607', '510601', '5106', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2608', '510603', '5106', '旌阳区', '3', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('2609', '510623', '5106', '中江县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('2610', '510626', '5106', '罗江县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('2611', '510681', '5106', '广汉市', '3', '1', '0', '81', 'G');
INSERT INTO `my_pcd` VALUES ('2612', '510682', '5106', '什邡市', '3', '1', '0', '82', 'S');
INSERT INTO `my_pcd` VALUES ('2613', '510683', '5106', '绵竹市', '3', '1', '0', '83', 'M');
INSERT INTO `my_pcd` VALUES ('2614', '5107', '51', '绵阳市', '2', '1', '0', '7', 'M');
INSERT INTO `my_pcd` VALUES ('2615', '510701', '5107', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2616', '510703', '5107', '涪城区', '3', '1', '0', '3', 'F');
INSERT INTO `my_pcd` VALUES ('2617', '510704', '5107', '游仙区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('2618', '510722', '5107', '三台县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('2619', '510723', '5107', '盐亭县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2620', '510724', '5107', '安县', '3', '1', '0', '24', 'A');
INSERT INTO `my_pcd` VALUES ('2621', '510725', '5107', '梓潼县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2622', '510726', '5107', '北川羌族自治县', '3', '1', '0', '26', 'B');
INSERT INTO `my_pcd` VALUES ('2623', '510727', '5107', '平武县', '3', '1', '0', '27', 'P');
INSERT INTO `my_pcd` VALUES ('2624', '510781', '5107', '江油市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('2625', '5108', '51', '广元市', '2', '1', '0', '8', 'G');
INSERT INTO `my_pcd` VALUES ('2626', '510801', '5108', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2627', '510802', '5108', '市中区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2628', '510811', '5108', '元坝区', '3', '1', '0', '11', 'Y');
INSERT INTO `my_pcd` VALUES ('2629', '510812', '5108', '朝天区', '3', '1', '0', '12', 'C');
INSERT INTO `my_pcd` VALUES ('2630', '510821', '5108', '旺苍县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('2631', '510822', '5108', '青川县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('2632', '510823', '5108', '剑阁县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('2633', '510824', '5108', '苍溪县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('2634', '5109', '51', '遂宁市', '2', '1', '0', '9', 'S');
INSERT INTO `my_pcd` VALUES ('2635', '510901', '5109', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2636', '510903', '5109', '船山区', '3', '1', '0', '3', 'C');
INSERT INTO `my_pcd` VALUES ('2637', '510904', '5109', '安居区', '3', '1', '0', '4', 'A');
INSERT INTO `my_pcd` VALUES ('2638', '510921', '5109', '蓬溪县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('2639', '510922', '5109', '射洪县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('2640', '510923', '5109', '大英县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('2641', '5110', '51', '内江市', '2', '1', '0', '10', 'N');
INSERT INTO `my_pcd` VALUES ('2642', '511001', '5110', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2643', '511002', '5110', '市中区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2644', '511011', '5110', '东兴区', '3', '1', '0', '11', 'D');
INSERT INTO `my_pcd` VALUES ('2645', '511024', '5110', '威远县', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('2646', '511025', '5110', '资中县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2647', '511028', '5110', '隆昌县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2648', '5111', '51', '乐山市', '2', '1', '0', '11', 'L');
INSERT INTO `my_pcd` VALUES ('2649', '511101', '5111', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2650', '511102', '5111', '市中区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2651', '511111', '5111', '沙湾区', '3', '1', '0', '11', 'S');
INSERT INTO `my_pcd` VALUES ('2652', '511112', '5111', '五通桥区', '3', '1', '0', '12', 'W');
INSERT INTO `my_pcd` VALUES ('2653', '511113', '5111', '金口河区', '3', '1', '0', '13', 'J');
INSERT INTO `my_pcd` VALUES ('2654', '511123', '5111', '犍为县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('2655', '511124', '5111', '井研县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2656', '511126', '5111', '夹江县', '3', '1', '0', '26', 'J');
INSERT INTO `my_pcd` VALUES ('2657', '511129', '5111', '沐川县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('2658', '511132', '5111', '峨边彝族自治县', '3', '1', '0', '32', 'E');
INSERT INTO `my_pcd` VALUES ('2659', '511133', '5111', '马边彝族自治县', '3', '1', '0', '33', 'M');
INSERT INTO `my_pcd` VALUES ('2660', '511181', '5111', '峨眉山市', '3', '1', '0', '81', 'E');
INSERT INTO `my_pcd` VALUES ('2661', '5113', '51', '南充市', '2', '1', '0', '13', 'N');
INSERT INTO `my_pcd` VALUES ('2662', '511301', '5113', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2663', '511302', '5113', '顺庆区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('2664', '511303', '5113', '高坪区', '3', '1', '0', '3', 'G');
INSERT INTO `my_pcd` VALUES ('2665', '511304', '5113', '嘉陵区', '3', '1', '0', '4', 'J');
INSERT INTO `my_pcd` VALUES ('2666', '511321', '5113', '南部县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('2667', '511322', '5113', '营山县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2668', '511323', '5113', '蓬安县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('2669', '511324', '5113', '仪陇县', '3', '1', '0', '24', 'Y');
INSERT INTO `my_pcd` VALUES ('2670', '511325', '5113', '西充县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('2671', '511381', '5113', '阆中市', '3', '1', '0', '81', 'Z');
INSERT INTO `my_pcd` VALUES ('2672', '5114', '51', '眉山市', '2', '1', '0', '14', 'M');
INSERT INTO `my_pcd` VALUES ('2673', '511401', '5114', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2674', '511402', '5114', '东坡区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('2675', '511421', '5114', '仁寿县', '3', '1', '0', '21', 'R');
INSERT INTO `my_pcd` VALUES ('2676', '511422', '5114', '彭山县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('2677', '511423', '5114', '洪雅县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('2678', '511424', '5114', '丹棱县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2679', '511425', '5114', '青神县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('2680', '5115', '51', '宜宾市', '2', '1', '0', '15', 'Y');
INSERT INTO `my_pcd` VALUES ('2681', '511501', '5115', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2682', '511502', '5115', '翠屏区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('2683', '511521', '5115', '宜宾县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('2684', '511522', '5115', '南溪县', '3', '1', '0', '22', 'N');
INSERT INTO `my_pcd` VALUES ('2685', '511523', '5115', '江安县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('2686', '511524', '5115', '长宁县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('2687', '511525', '5115', '高县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('2688', '511526', '5115', '珙县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('2689', '511527', '5115', '筠连县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('2690', '511528', '5115', '兴文县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('2691', '511529', '5115', '屏山县', '3', '1', '0', '29', 'P');
INSERT INTO `my_pcd` VALUES ('2692', '5116', '51', '广安市', '2', '1', '0', '16', 'G');
INSERT INTO `my_pcd` VALUES ('2693', '511601', '5116', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2694', '511602', '5116', '广安区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('2695', '511621', '5116', '岳池县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('2696', '511622', '5116', '武胜县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('2697', '511623', '5116', '邻水县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2698', '511681', '5116', '华蓥市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('2699', '5117', '51', '达州市', '2', '1', '0', '17', 'D');
INSERT INTO `my_pcd` VALUES ('2700', '511701', '5117', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2701', '511702', '5117', '通川区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('2702', '511721', '5117', '达县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('2703', '511722', '5117', '宣汉县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('2704', '511723', '5117', '开江县', '3', '1', '0', '23', 'K');
INSERT INTO `my_pcd` VALUES ('2705', '511724', '5117', '大竹县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2706', '511725', '5117', '渠县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('2707', '511781', '5117', '万源市', '3', '1', '0', '81', 'W');
INSERT INTO `my_pcd` VALUES ('2708', '5118', '51', '雅安市', '2', '1', '0', '18', 'Y');
INSERT INTO `my_pcd` VALUES ('2709', '511801', '5118', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2710', '511802', '5118', '雨城区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2711', '511821', '5118', '名山县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('2712', '511822', '5118', '荥经县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('2713', '511823', '5118', '汉源县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('2714', '511824', '5118', '石棉县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('2715', '511825', '5118', '天全县', '3', '1', '0', '25', 'T');
INSERT INTO `my_pcd` VALUES ('2716', '511826', '5118', '芦山县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('2717', '511827', '5118', '宝兴县', '3', '1', '0', '27', 'B');
INSERT INTO `my_pcd` VALUES ('2718', '5119', '51', '巴中市', '2', '1', '0', '19', 'B');
INSERT INTO `my_pcd` VALUES ('2719', '511901', '5119', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2720', '511902', '5119', '巴州区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('2721', '511921', '5119', '通江县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('2722', '511922', '5119', '南江县', '3', '1', '0', '22', 'N');
INSERT INTO `my_pcd` VALUES ('2723', '511923', '5119', '平昌县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('2724', '5120', '51', '资阳市', '2', '1', '0', '20', 'Z');
INSERT INTO `my_pcd` VALUES ('2725', '512001', '5120', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2726', '512002', '5120', '雁江区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('2727', '512021', '5120', '安岳县', '3', '1', '0', '21', 'A');
INSERT INTO `my_pcd` VALUES ('2728', '512022', '5120', '乐至县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2729', '512081', '5120', '简阳市', '3', '1', '0', '81', 'J');
INSERT INTO `my_pcd` VALUES ('2730', '5132', '51', '阿坝州', '2', '1', '0', '32', 'A');
INSERT INTO `my_pcd` VALUES ('2731', '513221', '5132', '汶川县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2732', '513222', '5132', '理县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2733', '513223', '5132', '茂县', '3', '1', '0', '23', 'M');
INSERT INTO `my_pcd` VALUES ('2734', '513224', '5132', '松潘县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('2735', '513225', '5132', '九寨沟县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('2736', '513226', '5132', '金川县', '3', '1', '0', '26', 'J');
INSERT INTO `my_pcd` VALUES ('2737', '513227', '5132', '小金县', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('2738', '513228', '5132', '黑水县', '3', '1', '0', '28', 'H');
INSERT INTO `my_pcd` VALUES ('2739', '513229', '5132', '马尔康县', '3', '1', '0', '29', 'M');
INSERT INTO `my_pcd` VALUES ('2740', '513230', '5132', '壤塘县', '3', '1', '0', '30', 'R');
INSERT INTO `my_pcd` VALUES ('2741', '513231', '5132', '阿坝县', '3', '1', '0', '31', 'A');
INSERT INTO `my_pcd` VALUES ('2742', '513232', '5132', '若尔盖县', '3', '1', '0', '32', 'R');
INSERT INTO `my_pcd` VALUES ('2743', '513233', '5132', '红原县', '3', '1', '0', '33', 'H');
INSERT INTO `my_pcd` VALUES ('2744', '5133', '51', '甘孜藏族自治州', '2', '1', '0', '33', 'G');
INSERT INTO `my_pcd` VALUES ('2745', '513321', '5133', '康定县', '3', '1', '0', '21', 'K');
INSERT INTO `my_pcd` VALUES ('2746', '513322', '5133', '泸定县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('2747', '513323', '5133', '丹巴县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('2748', '513324', '5133', '九龙县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2749', '513325', '5133', '雅江县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('2750', '513326', '5133', '道孚县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('2751', '513327', '5133', '炉霍县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('2752', '513328', '5133', '甘孜县', '3', '1', '0', '28', 'G');
INSERT INTO `my_pcd` VALUES ('2753', '513329', '5133', '新龙县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('2754', '513330', '5133', '德格县', '3', '1', '0', '30', 'D');
INSERT INTO `my_pcd` VALUES ('2755', '513331', '5133', '白玉县', '3', '1', '0', '31', 'B');
INSERT INTO `my_pcd` VALUES ('2756', '513332', '5133', '石渠县', '3', '1', '0', '32', 'S');
INSERT INTO `my_pcd` VALUES ('2757', '513333', '5133', '色达县', '3', '1', '0', '33', 'S');
INSERT INTO `my_pcd` VALUES ('2758', '513334', '5133', '理塘县', '3', '1', '0', '34', 'L');
INSERT INTO `my_pcd` VALUES ('2759', '513335', '5133', '巴塘县', '3', '1', '0', '35', 'B');
INSERT INTO `my_pcd` VALUES ('2760', '513336', '5133', '乡城县', '3', '1', '0', '36', 'X');
INSERT INTO `my_pcd` VALUES ('2761', '513337', '5133', '稻城县', '3', '1', '0', '37', 'D');
INSERT INTO `my_pcd` VALUES ('2762', '513338', '5133', '得荣县', '3', '1', '0', '38', 'D');
INSERT INTO `my_pcd` VALUES ('2763', '5134', '51', '凉山州', '2', '1', '0', '34', 'L');
INSERT INTO `my_pcd` VALUES ('2764', '513401', '5134', '西昌市', '3', '1', '0', '1', 'X');
INSERT INTO `my_pcd` VALUES ('2765', '513422', '5134', '木里藏族自治县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('2766', '513423', '5134', '盐源县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2767', '513424', '5134', '德昌', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2768', '513425', '5134', '会理县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('2769', '513426', '5134', '会东县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('2770', '513427', '5134', '宁南县', '3', '1', '0', '27', 'N');
INSERT INTO `my_pcd` VALUES ('2771', '513428', '5134', '普格县', '3', '1', '0', '28', 'P');
INSERT INTO `my_pcd` VALUES ('2772', '513429', '5134', '布拖县', '3', '1', '0', '29', 'B');
INSERT INTO `my_pcd` VALUES ('2773', '513430', '5134', '金阳县', '3', '1', '0', '30', 'J');
INSERT INTO `my_pcd` VALUES ('2774', '513431', '5134', '昭觉县', '3', '1', '0', '31', 'Z');
INSERT INTO `my_pcd` VALUES ('2775', '513432', '5134', '喜德县', '3', '1', '0', '32', 'X');
INSERT INTO `my_pcd` VALUES ('2776', '513433', '5134', '冕宁县', '3', '1', '0', '33', 'M');
INSERT INTO `my_pcd` VALUES ('2777', '513434', '5134', '越西县', '3', '1', '0', '34', 'Y');
INSERT INTO `my_pcd` VALUES ('2778', '513435', '5134', '甘洛县', '3', '1', '0', '35', 'G');
INSERT INTO `my_pcd` VALUES ('2779', '513436', '5134', '美姑县', '3', '1', '0', '36', 'M');
INSERT INTO `my_pcd` VALUES ('2780', '513437', '5134', '雷波县', '3', '1', '0', '37', 'L');
INSERT INTO `my_pcd` VALUES ('2781', '52', '0', '贵州省', '1', '1', '0', '52', 'G');
INSERT INTO `my_pcd` VALUES ('2782', '5201', '52', '贵阳市', '2', '1', '0', '1', 'G');
INSERT INTO `my_pcd` VALUES ('2783', '520101', '5201', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2784', '520102', '5201', '南明区', '3', '1', '0', '2', 'N');
INSERT INTO `my_pcd` VALUES ('2785', '520103', '5201', '云岩区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('2786', '520111', '5201', '花溪区', '3', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('2787', '520112', '5201', '乌当区', '3', '1', '0', '12', 'W');
INSERT INTO `my_pcd` VALUES ('2788', '520113', '5201', '白云区', '3', '1', '0', '13', 'B');
INSERT INTO `my_pcd` VALUES ('2789', '520114', '5201', '小河区', '3', '1', '0', '14', 'X');
INSERT INTO `my_pcd` VALUES ('2790', '520121', '5201', '开阳县', '3', '1', '0', '21', 'K');
INSERT INTO `my_pcd` VALUES ('2791', '520122', '5201', '息烽县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('2792', '520123', '5201', '修文县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('2793', '520181', '5201', '清镇市', '3', '1', '0', '81', 'Q');
INSERT INTO `my_pcd` VALUES ('2794', '5202', '52', '六盘水市', '2', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2795', '520201', '5202', '钟山区', '3', '1', '0', '1', 'Z');
INSERT INTO `my_pcd` VALUES ('2796', '520203', '5202', '六枝特区', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('2797', '520221', '5202', '水城县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('2798', '520222', '5202', '盘县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('2799', '5203', '52', '遵义市', '2', '1', '0', '3', 'Z');
INSERT INTO `my_pcd` VALUES ('2800', '520301', '5203', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2801', '520302', '5203', '红花岗区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2802', '520303', '5203', '汇川区', '3', '1', '0', '3', 'H');
INSERT INTO `my_pcd` VALUES ('2803', '520321', '5203', '遵义县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('2804', '520322', '5203', '桐梓县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2805', '520323', '5203', '绥阳县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('2806', '520324', '5203', '正安县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('2807', '520325', '5203', '道真仡佬族苗族自治县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('2808', '520326', '5203', '务川仡佬族苗族自治县', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('2809', '520327', '5203', '凤冈县', '3', '1', '0', '27', 'F');
INSERT INTO `my_pcd` VALUES ('2810', '520328', '5203', '湄潭县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('2811', '520329', '5203', '余庆县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('2812', '520330', '5203', '习水县', '3', '1', '0', '30', 'X');
INSERT INTO `my_pcd` VALUES ('2813', '520381', '5203', '赤水市', '3', '1', '0', '81', 'C');
INSERT INTO `my_pcd` VALUES ('2814', '520382', '5203', '仁怀市', '3', '1', '0', '82', 'R');
INSERT INTO `my_pcd` VALUES ('2815', '5204', '52', '安顺市', '2', '1', '0', '4', 'A');
INSERT INTO `my_pcd` VALUES ('2816', '520401', '5204', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2817', '520402', '5204', '西秀区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('2818', '520421', '5204', '平坝县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('2819', '520422', '5204', '普定县', '3', '1', '0', '22', 'P');
INSERT INTO `my_pcd` VALUES ('2820', '520423', '5204', '镇宁布依族苗族自治县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('2821', '520424', '5204', '关岭自治县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('2822', '520425', '5204', '紫云苗族布依族自治县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2823', '5222', '52', '铜仁地区', '2', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2824', '522201', '5222', '铜仁市', '3', '1', '0', '1', 'T');
INSERT INTO `my_pcd` VALUES ('2825', '522222', '5222', '江口县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('2826', '522223', '5222', '玉屏侗族自治县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2827', '522224', '5222', '石阡县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('2828', '522225', '5222', '思南县　', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('2829', '522226', '5222', '印江土家族苗族自治县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('2830', '522227', '5222', '德江县', '3', '1', '0', '27', 'D');
INSERT INTO `my_pcd` VALUES ('2831', '522228', '5222', '沿河土家族自治县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('2832', '522229', '5222', '松桃苗族自治县', '3', '1', '0', '29', 'S');
INSERT INTO `my_pcd` VALUES ('2833', '522230', '5222', '万山特区', '3', '1', '0', '30', 'W');
INSERT INTO `my_pcd` VALUES ('2834', '5223', '52', '黔西南州', '2', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('2835', '522301', '5223', '兴义市', '3', '1', '0', '1', 'X');
INSERT INTO `my_pcd` VALUES ('2836', '522322', '5223', '兴仁县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('2837', '522323', '5223', '普安县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('2838', '522324', '5223', '晴隆县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('2839', '522325', '5223', '贞丰县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2840', '522326', '5223', '望谟县', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('2841', '522327', '5223', '册亨县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('2842', '522328', '5223', '安龙县', '3', '1', '0', '28', 'A');
INSERT INTO `my_pcd` VALUES ('2843', '5224', '52', '毕节地区', '2', '1', '0', '24', 'B');
INSERT INTO `my_pcd` VALUES ('2844', '522401', '5224', '毕节市', '3', '1', '0', '1', 'B');
INSERT INTO `my_pcd` VALUES ('2845', '522422', '5224', '大方县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('2846', '522423', '5224', '黔西县', '3', '1', '0', '23', 'Q');
INSERT INTO `my_pcd` VALUES ('2847', '522424', '5224', '金沙县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2848', '522425', '5224', '织金县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2849', '522426', '5224', '纳雍县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('2850', '522427', '5224', '威宁彝族回族苗族自治县', '3', '1', '0', '27', 'W');
INSERT INTO `my_pcd` VALUES ('2851', '522428', '5224', '赫章县', '3', '1', '0', '28', 'H');
INSERT INTO `my_pcd` VALUES ('2852', '5226', '52', '黔东南苗族侗族自治州', '2', '1', '0', '26', 'Q');
INSERT INTO `my_pcd` VALUES ('2853', '522601', '5226', '凯里市', '3', '1', '0', '1', 'K');
INSERT INTO `my_pcd` VALUES ('2854', '522622', '5226', '黄平县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('2855', '522623', '5226', '施秉县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('2856', '522624', '5226', '三穗县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('2857', '522625', '5226', '镇远县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2858', '522626', '5226', '岑巩县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('2859', '522627', '5226', '天柱县', '3', '1', '0', '27', 'T');
INSERT INTO `my_pcd` VALUES ('2860', '522628', '5226', '锦屏县', '3', '1', '0', '28', 'J');
INSERT INTO `my_pcd` VALUES ('2861', '522629', '5226', '剑河县', '3', '1', '0', '29', 'J');
INSERT INTO `my_pcd` VALUES ('2862', '522630', '5226', '台江县', '3', '1', '0', '30', 'T');
INSERT INTO `my_pcd` VALUES ('2863', '522631', '5226', '黎平县', '3', '1', '0', '31', 'L');
INSERT INTO `my_pcd` VALUES ('2864', '522632', '5226', '榕江县', '3', '1', '0', '32', 'Z');
INSERT INTO `my_pcd` VALUES ('2865', '522633', '5226', '从江县', '3', '1', '0', '33', 'C');
INSERT INTO `my_pcd` VALUES ('2866', '522634', '5226', '雷山县', '3', '1', '0', '34', 'L');
INSERT INTO `my_pcd` VALUES ('2867', '522635', '5226', '麻江县', '3', '1', '0', '35', 'M');
INSERT INTO `my_pcd` VALUES ('2868', '522636', '5226', '丹寨县', '3', '1', '0', '36', 'D');
INSERT INTO `my_pcd` VALUES ('2869', '5227', '52', '黔南布依族苗族自治州', '2', '1', '0', '27', 'Q');
INSERT INTO `my_pcd` VALUES ('2870', '522701', '5227', '都匀市', '3', '1', '0', '1', 'D');
INSERT INTO `my_pcd` VALUES ('2871', '522702', '5227', '福泉市', '3', '1', '0', '2', 'F');
INSERT INTO `my_pcd` VALUES ('2872', '522722', '5227', '荔波县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2873', '522723', '5227', '贵定县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('2874', '522725', '5227', '瓮安县', '3', '1', '0', '25', 'W');
INSERT INTO `my_pcd` VALUES ('2875', '522726', '5227', '独山县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('2876', '522727', '5227', '平塘县', '3', '1', '0', '27', 'P');
INSERT INTO `my_pcd` VALUES ('2877', '522728', '5227', '罗甸县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2878', '522729', '5227', '长顺县', '3', '1', '0', '29', 'C');
INSERT INTO `my_pcd` VALUES ('2879', '522730', '5227', '龙里县', '3', '1', '0', '30', 'L');
INSERT INTO `my_pcd` VALUES ('2880', '522731', '5227', '惠水县', '3', '1', '0', '31', 'H');
INSERT INTO `my_pcd` VALUES ('2881', '522732', '5227', '三都水族自治县', '3', '1', '0', '32', 'S');
INSERT INTO `my_pcd` VALUES ('2882', '53', '0', '云南省', '1', '1', '0', '53', 'Y');
INSERT INTO `my_pcd` VALUES ('2883', '5301', '53', '昆明市', '2', '1', '0', '1', 'K');
INSERT INTO `my_pcd` VALUES ('2884', '530101', '5301', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2885', '530102', '5301', '五华区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('2886', '530103', '5301', '盘龙区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('2887', '530111', '5301', '官渡区', '3', '1', '0', '11', 'G');
INSERT INTO `my_pcd` VALUES ('2888', '530112', '5301', '西山区', '3', '1', '0', '12', 'X');
INSERT INTO `my_pcd` VALUES ('2889', '530113', '5301', '东川区', '3', '1', '0', '13', 'D');
INSERT INTO `my_pcd` VALUES ('2890', '530121', '5301', '呈贡县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('2891', '530122', '5301', '晋宁县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('2892', '530124', '5301', '富民县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('2893', '530125', '5301', '宜良县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('2894', '530126', '5301', '石林县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('2895', '530127', '5301', '嵩明县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('2896', '530128', '5301', '禄劝县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2897', '530129', '5301', '寻甸县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('2898', '530181', '5301', '安宁市', '3', '1', '0', '81', 'A');
INSERT INTO `my_pcd` VALUES ('2899', '5303', '53', '曲靖市', '2', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('2900', '530301', '5303', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2901', '530302', '5303', '麒麟区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2902', '530321', '5303', '马龙县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('2903', '530322', '5303', '陆良县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('2904', '530323', '5303', '师宗县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('2905', '530324', '5303', '罗平县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('2906', '530325', '5303', '富源县', '3', '1', '0', '25', 'F');
INSERT INTO `my_pcd` VALUES ('2907', '530326', '5303', '会泽县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('2908', '530328', '5303', '沾益县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('2909', '530381', '5303', '宣威市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('2910', '5304', '53', '玉溪市', '2', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('2911', '530401', '5304', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2912', '530402', '5304', '红塔区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('2913', '530421', '5304', '江川县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('2914', '530422', '5304', '澄江县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('2915', '530423', '5304', '通海县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('2916', '530424', '5304', '华宁县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('2917', '530425', '5304', '易门县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('2918', '530426', '5304', '峨山县', '3', '1', '0', '26', 'E');
INSERT INTO `my_pcd` VALUES ('2919', '530427', '5304', '新平县', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('2920', '530428', '5304', '元江县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('2921', '5305', '53', '保山市', '2', '1', '0', '5', 'B');
INSERT INTO `my_pcd` VALUES ('2922', '530501', '5305', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2923', '530502', '5305', '隆阳区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2924', '530521', '5305', '施甸县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('2925', '530522', '5305', '腾冲县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('2926', '530523', '5305', '龙陵县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('2927', '530524', '5305', '昌宁县', '3', '1', '0', '24', 'C');
INSERT INTO `my_pcd` VALUES ('2928', '5306', '53', '昭通市', '2', '1', '0', '6', 'Z');
INSERT INTO `my_pcd` VALUES ('2929', '530601', '5306', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2930', '530602', '5306', '昭阳区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('2931', '530621', '5306', '鲁甸县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('2932', '530622', '5306', '巧家县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('2933', '530623', '5306', '盐津县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2934', '530624', '5306', '大关县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('2935', '530625', '5306', '永善县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('2936', '530626', '5306', '绥江县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('2937', '530627', '5306', '镇雄县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('2938', '530628', '5306', '彝良县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('2939', '530629', '5306', '威信县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('2940', '530630', '5306', '水富县', '3', '1', '0', '30', 'S');
INSERT INTO `my_pcd` VALUES ('2941', '5307', '53', '丽江市', '2', '1', '0', '7', 'L');
INSERT INTO `my_pcd` VALUES ('2942', '530701', '5307', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2943', '530702', '5307', '古城区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('2944', '530721', '5307', '玉龙县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('2945', '530722', '5307', '永胜县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2946', '530723', '5307', '华坪县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('2947', '530724', '5307', '宁蒗县', '3', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('2948', '5308', '53', '思茅市', '2', '1', '0', '8', 'S');
INSERT INTO `my_pcd` VALUES ('2949', '530801', '5308', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2950', '530802', '5308', '翠云区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('2951', '530821', '5308', '普洱县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('2952', '530822', '5308', '墨江县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('2953', '530823', '5308', '景东县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('2954', '530824', '5308', '景谷县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2955', '530825', '5308', '镇沅县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('2956', '530826', '5308', '江城县', '3', '1', '0', '26', 'J');
INSERT INTO `my_pcd` VALUES ('2957', '530827', '5308', '孟连县', '3', '1', '0', '27', 'M');
INSERT INTO `my_pcd` VALUES ('2958', '530828', '5308', '澜沧县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('2959', '530829', '5308', '西盟县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('2960', '5309', '53', '临沧市', '2', '1', '0', '9', 'L');
INSERT INTO `my_pcd` VALUES ('2961', '530901', '5309', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('2962', '530902', '5309', '临翔区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('2963', '530921', '5309', '凤庆县', '3', '1', '0', '21', 'F');
INSERT INTO `my_pcd` VALUES ('2964', '530922', '5309', '云县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2965', '530923', '5309', '永德县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('2966', '530924', '5309', '镇康县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('2967', '530925', '5309', '双江县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('2968', '530926', '5309', '耿马县', '3', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('2969', '530927', '5309', '沧源县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('2970', '5323', '53', '楚雄州', '2', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('2971', '532301', '5323', '楚雄市', '3', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('2972', '532322', '5323', '双柏县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('2973', '532323', '5323', '牟定县', '3', '1', '0', '23', 'M');
INSERT INTO `my_pcd` VALUES ('2974', '532324', '5323', '南华县', '3', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('2975', '532325', '5323', '姚安县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('2976', '532326', '5323', '大姚县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('2977', '532327', '5323', '永仁县', '3', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('2978', '532328', '5323', '元谋县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('2979', '532329', '5323', '武定县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('2980', '532331', '5323', '禄丰县', '3', '1', '0', '31', 'L');
INSERT INTO `my_pcd` VALUES ('2981', '5325', '53', '红河州', '2', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('2982', '532501', '5325', '个旧市', '3', '1', '0', '1', 'G');
INSERT INTO `my_pcd` VALUES ('2983', '532502', '5325', '开远市', '3', '1', '0', '2', 'K');
INSERT INTO `my_pcd` VALUES ('2984', '532522', '5325', '蒙自县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('2985', '532523', '5325', '屏边县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('2986', '532524', '5325', '建水县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('2987', '532525', '5325', '石屏县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('2988', '532526', '5325', '弥勒县', '3', '1', '0', '26', 'M');
INSERT INTO `my_pcd` VALUES ('2989', '532527', '5325', '泸西县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('2990', '532528', '5325', '元阳县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('2991', '532529', '5325', '红河县', '3', '1', '0', '29', 'H');
INSERT INTO `my_pcd` VALUES ('2992', '532530', '5325', '金平县', '3', '1', '0', '30', 'J');
INSERT INTO `my_pcd` VALUES ('2993', '532531', '5325', '绿春县', '3', '1', '0', '31', 'L');
INSERT INTO `my_pcd` VALUES ('2994', '532532', '5325', '河口县', '3', '1', '0', '32', 'H');
INSERT INTO `my_pcd` VALUES ('2995', '5326', '53', '文山州', '2', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('2996', '532621', '5326', '文山县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('2997', '532622', '5326', '砚山县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('2998', '532623', '5326', '西畴县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('2999', '532624', '5326', '麻栗坡县', '3', '1', '0', '24', 'M');
INSERT INTO `my_pcd` VALUES ('3000', '532625', '5326', '马关县', '3', '1', '0', '25', 'M');
INSERT INTO `my_pcd` VALUES ('3001', '532626', '5326', '丘北县', '3', '1', '0', '26', 'Q');
INSERT INTO `my_pcd` VALUES ('3002', '532627', '5326', '广南县', '3', '1', '0', '27', 'G');
INSERT INTO `my_pcd` VALUES ('3003', '532628', '5326', '富宁县', '3', '1', '0', '28', 'F');
INSERT INTO `my_pcd` VALUES ('3004', '5328', '53', '西双版纳州', '2', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('3005', '532801', '5328', '景洪市', '3', '1', '0', '1', 'J');
INSERT INTO `my_pcd` VALUES ('3006', '532822', '5328', '勐海县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3007', '532823', '5328', '勐腊县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3008', '5329', '53', '大理州', '2', '1', '0', '29', 'D');
INSERT INTO `my_pcd` VALUES ('3009', '532901', '5329', '大理市', '3', '1', '0', '1', 'D');
INSERT INTO `my_pcd` VALUES ('3010', '532922', '5329', '漾濞县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('3011', '532923', '5329', '祥云县', '3', '1', '0', '23', 'X');
INSERT INTO `my_pcd` VALUES ('3012', '532924', '5329', '宾川县', '3', '1', '0', '24', 'B');
INSERT INTO `my_pcd` VALUES ('3013', '532925', '5329', '弥渡县', '3', '1', '0', '25', 'M');
INSERT INTO `my_pcd` VALUES ('3014', '532926', '5329', '南涧县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('3015', '532927', '5329', '巍山县', '3', '1', '0', '27', 'W');
INSERT INTO `my_pcd` VALUES ('3016', '532928', '5329', '永平县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('3017', '532929', '5329', '云龙县', '3', '1', '0', '29', 'Y');
INSERT INTO `my_pcd` VALUES ('3018', '532930', '5329', '洱源县', '3', '1', '0', '30', 'E');
INSERT INTO `my_pcd` VALUES ('3019', '532931', '5329', '剑川县', '3', '1', '0', '31', 'J');
INSERT INTO `my_pcd` VALUES ('3020', '532932', '5329', '鹤庆县', '3', '1', '0', '32', 'H');
INSERT INTO `my_pcd` VALUES ('3021', '5331', '53', '德宏州', '2', '1', '0', '31', 'D');
INSERT INTO `my_pcd` VALUES ('3022', '533102', '5331', '瑞丽市', '3', '1', '0', '2', 'R');
INSERT INTO `my_pcd` VALUES ('3023', '533103', '5331', '潞西市', '3', '1', '0', '3', 'L');
INSERT INTO `my_pcd` VALUES ('3024', '533122', '5331', '梁河县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('3025', '533123', '5331', '盈江县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3026', '533124', '5331', '陇川县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('3027', '5333', '53', '怒江州', '2', '1', '0', '33', 'N');
INSERT INTO `my_pcd` VALUES ('3028', '533321', '5333', '泸水县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('3029', '533323', '5333', '福贡县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('3030', '533324', '5333', '贡山县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('3031', '533325', '5333', '兰坪县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('3032', '5334', '53', '迪庆州', '2', '1', '0', '34', 'D');
INSERT INTO `my_pcd` VALUES ('3033', '533421', '5334', '香格里拉县', '3', '1', '0', '21', 'X');
INSERT INTO `my_pcd` VALUES ('3034', '533422', '5334', '德钦县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('3035', '533423', '5334', '维西县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('3036', '54', '0', '西藏自治区', '1', '1', '0', '54', 'X');
INSERT INTO `my_pcd` VALUES ('3037', '5401', '54', '拉萨市', '2', '1', '0', '1', 'L');
INSERT INTO `my_pcd` VALUES ('3038', '540101', '5401', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3039', '540102', '5401', '城关区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('3040', '540121', '5401', '林周县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('3041', '540122', '5401', '当雄县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('3042', '540123', '5401', '尼木县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('3043', '540124', '5401', '曲水县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('3044', '540125', '5401', '堆龙德庆', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('3045', '540126', '5401', '达孜县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('3046', '540127', '5401', '墨竹工卡县', '3', '1', '0', '27', 'M');
INSERT INTO `my_pcd` VALUES ('3047', '5421', '54', '昌都地区', '2', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('3048', '542121', '5421', '昌都县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('3049', '542122', '5421', '江达县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('3050', '542123', '5421', '贡觉县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('3051', '542124', '5421', '类乌齐县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('3052', '542125', '5421', '丁青县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('3053', '542126', '5421', '察亚县', '3', '1', '0', '26', 'C');
INSERT INTO `my_pcd` VALUES ('3054', '542127', '5421', '八宿县', '3', '1', '0', '27', 'B');
INSERT INTO `my_pcd` VALUES ('3055', '542128', '5421', '左贡县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('3056', '542129', '5421', '芒康县', '3', '1', '0', '29', 'M');
INSERT INTO `my_pcd` VALUES ('3057', '542132', '5421', '洛隆县', '3', '1', '0', '32', 'L');
INSERT INTO `my_pcd` VALUES ('3058', '542133', '5421', '边坝县', '3', '1', '0', '33', 'B');
INSERT INTO `my_pcd` VALUES ('3059', '5422', '54', '山南地区', '2', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('3060', '542221', '5422', '乃东县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('3061', '542222', '5422', '扎囊县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3062', '542223', '5422', '贡嘎县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('3063', '542224', '5422', '桑日县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('3064', '542225', '5422', '琼结县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('3065', '542226', '5422', '曲松县', '3', '1', '0', '26', 'Q');
INSERT INTO `my_pcd` VALUES ('3066', '542227', '5422', '措美县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('3067', '542228', '5422', '洛扎县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('3068', '542229', '5422', '加查县', '3', '1', '0', '29', 'J');
INSERT INTO `my_pcd` VALUES ('3069', '542231', '5422', '隆子县', '3', '1', '0', '31', 'L');
INSERT INTO `my_pcd` VALUES ('3070', '542232', '5422', '错那县', '3', '1', '0', '32', 'C');
INSERT INTO `my_pcd` VALUES ('3071', '542233', '5422', '浪卡子县', '3', '1', '0', '33', 'L');
INSERT INTO `my_pcd` VALUES ('3072', '5423', '54', '日喀则地区', '2', '1', '0', '23', 'R');
INSERT INTO `my_pcd` VALUES ('3073', '542301', '5423', '日喀则市', '3', '1', '0', '1', 'R');
INSERT INTO `my_pcd` VALUES ('3074', '542322', '5423', '南木林县', '3', '1', '0', '22', 'N');
INSERT INTO `my_pcd` VALUES ('3075', '542323', '5423', '江孜县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('3076', '542324', '5423', '定日县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('3077', '542325', '5423', '萨迦县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('3078', '542326', '5423', '拉孜县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('3079', '542327', '5423', '昂仁县', '3', '1', '0', '27', 'A');
INSERT INTO `my_pcd` VALUES ('3080', '542328', '5423', '谢通门县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('3081', '542329', '5423', '白朗县', '3', '1', '0', '29', 'B');
INSERT INTO `my_pcd` VALUES ('3082', '542330', '5423', '仁布县', '3', '1', '0', '30', 'R');
INSERT INTO `my_pcd` VALUES ('3083', '542331', '5423', '康马县', '3', '1', '0', '31', 'K');
INSERT INTO `my_pcd` VALUES ('3084', '542332', '5423', '定结县', '3', '1', '0', '32', 'D');
INSERT INTO `my_pcd` VALUES ('3085', '542333', '5423', '仲巴县', '3', '1', '0', '33', 'Z');
INSERT INTO `my_pcd` VALUES ('3086', '542334', '5423', '亚东县', '3', '1', '0', '34', 'Y');
INSERT INTO `my_pcd` VALUES ('3087', '542335', '5423', '吉隆县', '3', '1', '0', '35', 'J');
INSERT INTO `my_pcd` VALUES ('3088', '542336', '5423', '聂拉木县', '3', '1', '0', '36', 'N');
INSERT INTO `my_pcd` VALUES ('3089', '542337', '5423', '萨嘎县', '3', '1', '0', '37', 'S');
INSERT INTO `my_pcd` VALUES ('3090', '542338', '5423', '岗巴县', '3', '1', '0', '38', 'G');
INSERT INTO `my_pcd` VALUES ('3091', '5424', '54', '那曲地区', '2', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('3092', '542421', '5424', '那曲县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('3093', '542422', '5424', '嘉黎县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('3094', '542423', '5424', '比如县', '3', '1', '0', '23', 'B');
INSERT INTO `my_pcd` VALUES ('3095', '542424', '5424', '聂荣县', '3', '1', '0', '24', 'N');
INSERT INTO `my_pcd` VALUES ('3096', '542425', '5424', '安多县', '3', '1', '0', '25', 'A');
INSERT INTO `my_pcd` VALUES ('3097', '542426', '5424', '申扎县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('3098', '542427', '5424', '索县', '3', '1', '0', '27', 'S');
INSERT INTO `my_pcd` VALUES ('3099', '542428', '5424', '班戈县', '3', '1', '0', '28', 'B');
INSERT INTO `my_pcd` VALUES ('3100', '542429', '5424', '巴青县', '3', '1', '0', '29', 'B');
INSERT INTO `my_pcd` VALUES ('3101', '542430', '5424', '尼玛县', '3', '1', '0', '30', 'N');
INSERT INTO `my_pcd` VALUES ('3102', '5425', '54', '阿里地区', '2', '1', '0', '25', 'A');
INSERT INTO `my_pcd` VALUES ('3103', '542521', '5425', '普兰县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('3104', '542522', '5425', '札达县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3105', '542523', '5425', '噶尔县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('3106', '542524', '5425', '日土县', '3', '1', '0', '24', 'R');
INSERT INTO `my_pcd` VALUES ('3107', '542525', '5425', '革吉县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('3108', '542526', '5425', '改则县', '3', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('3109', '542527', '5425', '措勤县', '3', '1', '0', '27', 'C');
INSERT INTO `my_pcd` VALUES ('3110', '5426', '54', '林芝地区', '2', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('3111', '542621', '5426', '林芝县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('3112', '542622', '5426', '工布江达县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('3113', '542623', '5426', '米林县', '3', '1', '0', '23', 'M');
INSERT INTO `my_pcd` VALUES ('3114', '542624', '5426', '墨脱县', '3', '1', '0', '24', 'M');
INSERT INTO `my_pcd` VALUES ('3115', '542625', '5426', '波密县', '3', '1', '0', '25', 'B');
INSERT INTO `my_pcd` VALUES ('3116', '542626', '5426', '察隅县', '3', '1', '0', '26', 'C');
INSERT INTO `my_pcd` VALUES ('3117', '542627', '5426', '朗县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('3118', '61', '0', '陕西省', '1', '1', '0', '61', 'S');
INSERT INTO `my_pcd` VALUES ('3119', '6101', '61', '西安市', '2', '1', '0', '1', 'X');
INSERT INTO `my_pcd` VALUES ('3120', '610101', '6101', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3121', '610102', '6101', '新城区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('3122', '610103', '6101', '碑林区', '3', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('3123', '610104', '6101', '莲湖区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('3124', '610111', '6101', '灞桥区', '3', '1', '0', '11', 'Z');
INSERT INTO `my_pcd` VALUES ('3125', '610112', '6101', '未央区', '3', '1', '0', '12', 'W');
INSERT INTO `my_pcd` VALUES ('3126', '610113', '6101', '雁塔区', '3', '1', '0', '13', 'Y');
INSERT INTO `my_pcd` VALUES ('3127', '610114', '6101', '阎良区', '3', '1', '0', '14', 'Y');
INSERT INTO `my_pcd` VALUES ('3128', '610115', '6101', '临潼区', '3', '1', '0', '15', 'L');
INSERT INTO `my_pcd` VALUES ('3129', '610116', '6101', '长安区', '3', '1', '0', '16', 'C');
INSERT INTO `my_pcd` VALUES ('3130', '610122', '6101', '蓝田县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('3131', '610124', '6101', '周至县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('3132', '610125', '6101', '户县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('3133', '610126', '6101', '高陵县', '3', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('3134', '6102', '61', '铜川市', '2', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('3135', '610201', '6102', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3136', '610202', '6102', '王益区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('3137', '610202100', '610202', '\"黄堡镇', '0', '1', '0', '0', '');
INSERT INTO `my_pcd` VALUES ('3138', '610202201', '610202', '\"王益乡', '0', '1', '0', '1', '');
INSERT INTO `my_pcd` VALUES ('3139', '610203', '6102', '印台区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('3140', '610204', '6102', '耀州区', '3', '1', '0', '4', 'Y');
INSERT INTO `my_pcd` VALUES ('3141', '610222', '6102', '宜君县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('3142', '6103', '61', '宝鸡市', '2', '1', '0', '3', 'B');
INSERT INTO `my_pcd` VALUES ('3143', '610301', '6103', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3144', '610302', '6103', '渭滨区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('3145', '610303', '6103', '金台区', '3', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('3146', '610304', '6103', '陈仓区', '3', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('3147', '610322', '6103', '凤翔县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('3148', '610323', '6103', '岐山县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3149', '610324', '6103', '扶风县', '3', '1', '0', '24', 'F');
INSERT INTO `my_pcd` VALUES ('3150', '610326', '6103', '眉县', '3', '1', '0', '26', 'M');
INSERT INTO `my_pcd` VALUES ('3151', '610327', '6103', '陇县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('3152', '610328', '6103', '千阳县', '3', '1', '0', '28', 'Q');
INSERT INTO `my_pcd` VALUES ('3153', '610329', '6103', '麟游县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('3154', '610330', '6103', '凤县', '3', '1', '0', '30', 'F');
INSERT INTO `my_pcd` VALUES ('3155', '610331', '6103', '太白县', '3', '1', '0', '31', 'T');
INSERT INTO `my_pcd` VALUES ('3156', '6104', '61', '咸阳市', '2', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('3157', '610401', '6104', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3158', '610402', '6104', '秦都区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('3159', '610403', '6104', '杨凌区', '3', '1', '0', '3', 'Y');
INSERT INTO `my_pcd` VALUES ('3160', '610404', '6104', '渭城区', '3', '1', '0', '4', 'W');
INSERT INTO `my_pcd` VALUES ('3161', '610422', '6104', '三原县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('3162', '610423', '6104', '泾阳县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3163', '610424', '6104', '乾县', '3', '1', '0', '24', 'Q');
INSERT INTO `my_pcd` VALUES ('3164', '610425', '6104', '礼泉县', '3', '1', '0', '25', 'L');
INSERT INTO `my_pcd` VALUES ('3165', '610426', '6104', '永寿县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('3166', '610427', '6104', '彬县', '3', '1', '0', '27', 'B');
INSERT INTO `my_pcd` VALUES ('3167', '610428', '6104', '长武县', '3', '1', '0', '28', 'C');
INSERT INTO `my_pcd` VALUES ('3168', '610429', '6104', '旬邑县', '3', '1', '0', '29', 'X');
INSERT INTO `my_pcd` VALUES ('3169', '610430', '6104', '淳化县', '3', '1', '0', '30', 'C');
INSERT INTO `my_pcd` VALUES ('3170', '610431', '6104', '武功县', '3', '1', '0', '31', 'W');
INSERT INTO `my_pcd` VALUES ('3171', '610481', '6104', '兴平市', '3', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('3172', '6105', '61', '渭南市', '2', '1', '0', '5', 'W');
INSERT INTO `my_pcd` VALUES ('3173', '610501', '6105', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3174', '610502', '6105', '临渭区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('3175', '610521', '6105', '华县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('3176', '610522', '6105', '潼关县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3177', '610523', '6105', '大荔县', '3', '1', '0', '23', 'D');
INSERT INTO `my_pcd` VALUES ('3178', '610524', '6105', '合阳县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('3179', '610525', '6105', '澄城县', '3', '1', '0', '25', 'C');
INSERT INTO `my_pcd` VALUES ('3180', '610526', '6105', '蒲城县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('3181', '610527', '6105', '白水县', '3', '1', '0', '27', 'B');
INSERT INTO `my_pcd` VALUES ('3182', '610528', '6105', '富平县', '3', '1', '0', '28', 'F');
INSERT INTO `my_pcd` VALUES ('3183', '610581', '6105', '韩城市', '3', '1', '0', '81', 'H');
INSERT INTO `my_pcd` VALUES ('3184', '610582', '6105', '华阴市', '3', '1', '0', '82', 'H');
INSERT INTO `my_pcd` VALUES ('3185', '6106', '61', '延安市', '2', '1', '0', '6', 'Y');
INSERT INTO `my_pcd` VALUES ('3186', '610601', '6106', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3187', '610602', '6106', '宝塔区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('3188', '610621', '6106', '延长县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('3189', '610622', '6106', '延川县', '3', '1', '0', '22', 'Y');
INSERT INTO `my_pcd` VALUES ('3190', '610623', '6106', '子长县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3191', '610624', '6106', '安塞县', '3', '1', '0', '24', 'A');
INSERT INTO `my_pcd` VALUES ('3192', '610625', '6106', '志丹县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3193', '610626', '6106', '吴起县', '3', '1', '0', '26', 'W');
INSERT INTO `my_pcd` VALUES ('3194', '610627', '6106', '甘泉县', '3', '1', '0', '27', 'G');
INSERT INTO `my_pcd` VALUES ('3195', '610628', '6106', '富县', '3', '1', '0', '28', 'F');
INSERT INTO `my_pcd` VALUES ('3196', '610629', '6106', '洛川县', '3', '1', '0', '29', 'L');
INSERT INTO `my_pcd` VALUES ('3197', '610630', '6106', '宜川县', '3', '1', '0', '30', 'Y');
INSERT INTO `my_pcd` VALUES ('3198', '610631', '6106', '黄龙县', '3', '1', '0', '31', 'H');
INSERT INTO `my_pcd` VALUES ('3199', '610632', '6106', '黄陵县', '3', '1', '0', '32', 'H');
INSERT INTO `my_pcd` VALUES ('3200', '6107', '61', '汉中市', '2', '1', '0', '7', 'H');
INSERT INTO `my_pcd` VALUES ('3201', '610701', '6107', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3202', '610702', '6107', '汉台区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('3203', '610721', '6107', '南郑县', '3', '1', '0', '21', 'N');
INSERT INTO `my_pcd` VALUES ('3204', '610722', '6107', '城固县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('3205', '610723', '6107', '洋县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3206', '610724', '6107', '西乡县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('3207', '610725', '6107', '勉县', '3', '1', '0', '25', 'M');
INSERT INTO `my_pcd` VALUES ('3208', '610726', '6107', '宁强县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('3209', '610727', '6107', '略阳县', '3', '1', '0', '27', 'L');
INSERT INTO `my_pcd` VALUES ('3210', '610728', '6107', '镇巴县', '3', '1', '0', '28', 'Z');
INSERT INTO `my_pcd` VALUES ('3211', '610729', '6107', '留坝县', '3', '1', '0', '29', 'L');
INSERT INTO `my_pcd` VALUES ('3212', '610730', '6107', '佛坪县', '3', '1', '0', '30', 'F');
INSERT INTO `my_pcd` VALUES ('3213', '6108', '61', '榆林市', '2', '1', '0', '8', 'Y');
INSERT INTO `my_pcd` VALUES ('3214', '610801', '6108', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3215', '610802', '6108', '榆阳区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('3216', '610821', '6108', '神木县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('3217', '610822', '6108', '府谷县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('3218', '610823', '6108', '横山县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('3219', '610824', '6108', '靖边县', '3', '1', '0', '24', 'J');
INSERT INTO `my_pcd` VALUES ('3220', '610825', '6108', '定边县', '3', '1', '0', '25', 'D');
INSERT INTO `my_pcd` VALUES ('3221', '610826', '6108', '绥德县', '3', '1', '0', '26', 'S');
INSERT INTO `my_pcd` VALUES ('3222', '610827', '6108', '米脂县', '3', '1', '0', '27', 'M');
INSERT INTO `my_pcd` VALUES ('3223', '610828', '6108', '佳县', '3', '1', '0', '28', 'J');
INSERT INTO `my_pcd` VALUES ('3224', '610829', '6108', '吴堡县', '3', '1', '0', '29', 'W');
INSERT INTO `my_pcd` VALUES ('3225', '610830', '6108', '清涧县', '3', '1', '0', '30', 'Q');
INSERT INTO `my_pcd` VALUES ('3226', '610831', '6108', '子洲县', '3', '1', '0', '31', 'Z');
INSERT INTO `my_pcd` VALUES ('3227', '6109', '61', '安康市', '2', '1', '0', '9', 'A');
INSERT INTO `my_pcd` VALUES ('3228', '610901', '6109', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3229', '610902', '6109', '汉滨区', '3', '1', '0', '2', 'H');
INSERT INTO `my_pcd` VALUES ('3230', '610921', '6109', '汉阴县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('3231', '610922', '6109', '石泉县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('3232', '610923', '6109', '宁陕县', '3', '1', '0', '23', 'N');
INSERT INTO `my_pcd` VALUES ('3233', '610924', '6109', '紫阳县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('3234', '610925', '6109', '岚皋县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3235', '610926', '6109', '平利县', '3', '1', '0', '26', 'P');
INSERT INTO `my_pcd` VALUES ('3236', '610926100', '610926', '\"城关镇', '0', '1', '0', '0', '');
INSERT INTO `my_pcd` VALUES ('3237', '610927', '6109', '镇坪县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('3238', '610928', '6109', '旬阳县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('3239', '610929', '6109', '白河县', '3', '1', '0', '29', 'B');
INSERT INTO `my_pcd` VALUES ('3240', '6110', '61', '商洛市', '2', '1', '0', '10', 'S');
INSERT INTO `my_pcd` VALUES ('3241', '611001', '6110', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3242', '611002', '6110', '商州区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('3243', '611021', '6110', '洛南县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('3244', '611022', '6110', '丹凤县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('3245', '611023', '6110', '商南县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('3246', '611024', '6110', '山阳县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('3247', '611025', '6110', '镇安县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3248', '611026', '6110', '柞水县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('3249', '62', '0', '甘肃省', '1', '1', '0', '62', 'G');
INSERT INTO `my_pcd` VALUES ('3250', '6201', '62', '兰州市', '2', '1', '0', '1', 'L');
INSERT INTO `my_pcd` VALUES ('3251', '620101', '6201', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3252', '620102', '6201', '城关区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('3253', '620103', '6201', '七里河区', '3', '1', '0', '3', 'Q');
INSERT INTO `my_pcd` VALUES ('3254', '620104', '6201', '兰州市西固区', '3', '1', '0', '4', 'L');
INSERT INTO `my_pcd` VALUES ('3255', '620105', '6201', '安宁区', '3', '1', '0', '5', 'A');
INSERT INTO `my_pcd` VALUES ('3256', '620111', '6201', '红古区', '3', '1', '0', '11', 'H');
INSERT INTO `my_pcd` VALUES ('3257', '620121', '6201', '永登县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('3258', '620122', '6201', '皋兰县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('3259', '620123', '6201', '榆中县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3260', '6202', '62', '嘉峪关市', '2', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('3261', '620201', '6202', '市辖', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3262', '6203', '62', '金昌市', '2', '1', '0', '3', 'J');
INSERT INTO `my_pcd` VALUES ('3263', '620301', '6203', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3264', '620302', '6203', '金川区', '3', '1', '0', '2', 'J');
INSERT INTO `my_pcd` VALUES ('3265', '620321', '6203', '永昌县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('3266', '6204', '62', '白银市', '2', '1', '0', '4', 'B');
INSERT INTO `my_pcd` VALUES ('3267', '620401', '6204', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3268', '620402', '6204', '白银区', '3', '1', '0', '2', 'B');
INSERT INTO `my_pcd` VALUES ('3269', '620403', '6204', '平川区', '3', '1', '0', '3', 'P');
INSERT INTO `my_pcd` VALUES ('3270', '620421', '6204', '靖远县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('3271', '620422', '6204', '会宁县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('3272', '620423', '6204', '景泰县', '3', '1', '0', '23', 'J');
INSERT INTO `my_pcd` VALUES ('3273', '6205', '62', '天水市', '2', '1', '0', '5', 'T');
INSERT INTO `my_pcd` VALUES ('3274', '620501', '6205', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3275', '620502', '6205', '秦州区', '3', '1', '0', '2', 'Q');
INSERT INTO `my_pcd` VALUES ('3276', '620503', '6205', '麦积区', '3', '1', '0', '3', 'M');
INSERT INTO `my_pcd` VALUES ('3277', '620521', '6205', '清水县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('3278', '620522', '6205', '秦安县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('3279', '620523', '6205', '甘谷县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('3280', '620524', '6205', '武山县', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('3281', '620525', '6205', '张家川县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3282', '6206', '62', '武威市', '2', '1', '0', '6', 'W');
INSERT INTO `my_pcd` VALUES ('3283', '620601', '6206', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3284', '620602', '6206', '凉州区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('3285', '620621', '6206', '民勤县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('3286', '620622', '6206', '古浪县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('3287', '620623', '6206', '天祝县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('3288', '6207', '62', '张掖市', '2', '1', '0', '7', 'Z');
INSERT INTO `my_pcd` VALUES ('3289', '620701', '6207', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3290', '620702', '6207', '甘州区', '3', '1', '0', '2', 'G');
INSERT INTO `my_pcd` VALUES ('3291', '620721', '6207', '肃南裕固族自治县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('3292', '620722', '6207', '民乐县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('3293', '620723', '6207', '临泽县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('3294', '620724', '6207', '高台县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('3295', '620725', '6207', '山丹县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('3296', '6208', '62', '平凉市', '2', '1', '0', '8', 'P');
INSERT INTO `my_pcd` VALUES ('3297', '620801', '6208', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3298', '620802', '6208', '崆峒区', '3', '1', '0', '2', 'Z');
INSERT INTO `my_pcd` VALUES ('3299', '620821', '6208', '泾川县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('3300', '620822', '6208', '灵台县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('3301', '620823', '6208', '崇信县', '3', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('3302', '620824', '6208', '华亭县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('3303', '620825', '6208', '庄浪县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3304', '620826', '6208', '静宁县', '3', '1', '0', '26', 'J');
INSERT INTO `my_pcd` VALUES ('3305', '6209', '62', '酒泉市', '2', '1', '0', '9', 'J');
INSERT INTO `my_pcd` VALUES ('3306', '620901', '6209', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3307', '620902', '6209', '肃州区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('3308', '620921', '6209', '金塔县', '3', '1', '0', '21', 'J');
INSERT INTO `my_pcd` VALUES ('3309', '620922', '6209', '瓜州县', '3', '1', '0', '22', 'G');
INSERT INTO `my_pcd` VALUES ('3310', '620923', '6209', '肃北蒙古族自治县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('3311', '620924', '6209', '阿克塞县', '3', '1', '0', '24', 'A');
INSERT INTO `my_pcd` VALUES ('3312', '620981', '6209', '玉门市', '3', '1', '0', '81', 'Y');
INSERT INTO `my_pcd` VALUES ('3313', '620982', '6209', '敦煌市', '3', '1', '0', '82', 'D');
INSERT INTO `my_pcd` VALUES ('3314', '6210', '62', '庆阳市', '2', '1', '0', '10', 'Q');
INSERT INTO `my_pcd` VALUES ('3315', '621001', '6210', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3316', '621002', '6210', '西峰区', '3', '1', '0', '2', 'X');
INSERT INTO `my_pcd` VALUES ('3317', '621021', '6210', '庆城县', '3', '1', '0', '21', 'Q');
INSERT INTO `my_pcd` VALUES ('3318', '621022', '6210', '环县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('3319', '621023', '6210', '华池县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('3320', '621024', '6210', '合水县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('3321', '621025', '6210', '正宁县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3322', '621026', '6210', '宁县', '3', '1', '0', '26', 'N');
INSERT INTO `my_pcd` VALUES ('3323', '621027', '6210', '镇原县', '3', '1', '0', '27', 'Z');
INSERT INTO `my_pcd` VALUES ('3324', '6211', '62', '定西市', '2', '1', '0', '11', 'D');
INSERT INTO `my_pcd` VALUES ('3325', '621101', '6211', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3326', '621102', '6211', '安定区', '3', '1', '0', '2', 'A');
INSERT INTO `my_pcd` VALUES ('3327', '621121', '6211', '通渭县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('3328', '621122', '6211', '陇西县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('3329', '621123', '6211', '渭源县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('3330', '621124', '6211', '临洮县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('3331', '621125', '6211', '漳县', '3', '1', '0', '25', 'Z');
INSERT INTO `my_pcd` VALUES ('3332', '621126', '6211', '岷县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('3333', '6212', '62', '陇南市', '2', '1', '0', '12', 'L');
INSERT INTO `my_pcd` VALUES ('3334', '621201', '6212', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3335', '621202', '6212', '武都区', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('3336', '621221', '6212', '成县', '3', '1', '0', '21', 'C');
INSERT INTO `my_pcd` VALUES ('3337', '621222', '6212', '文县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('3338', '621223', '6212', '宕昌县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3339', '621224', '6212', '康县', '3', '1', '0', '24', 'K');
INSERT INTO `my_pcd` VALUES ('3340', '621225', '6212', '西和县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('3341', '621226', '6212', '礼县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('3342', '621227', '6212', '徽县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('3343', '621228', '6212', '两当县', '3', '1', '0', '28', 'L');
INSERT INTO `my_pcd` VALUES ('3344', '6229', '62', '临夏州', '2', '1', '0', '29', 'L');
INSERT INTO `my_pcd` VALUES ('3345', '622901', '6229', '临夏市', '3', '1', '0', '1', 'L');
INSERT INTO `my_pcd` VALUES ('3346', '622921', '6229', '临夏县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('3347', '622922', '6229', '康乐县', '3', '1', '0', '22', 'K');
INSERT INTO `my_pcd` VALUES ('3348', '622923', '6229', '永靖县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3349', '622924', '6229', '广河县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('3350', '622925', '6229', '和政县', '3', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('3351', '622926', '6229', '东乡族自治县', '3', '1', '0', '26', 'D');
INSERT INTO `my_pcd` VALUES ('3352', '622927', '6229', '积石山县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('3353', '6230', '62', '甘南州', '2', '1', '0', '30', 'G');
INSERT INTO `my_pcd` VALUES ('3354', '623001', '6230', '合作市', '3', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('3355', '623021', '6230', '临潭县', '3', '1', '0', '21', 'L');
INSERT INTO `my_pcd` VALUES ('3356', '623022', '6230', '卓尼县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3357', '623023', '6230', '舟曲县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3358', '623024', '6230', '迭部县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('3359', '623025', '6230', '玛曲县', '3', '1', '0', '25', 'M');
INSERT INTO `my_pcd` VALUES ('3360', '623026', '6230', '碌曲县', '3', '1', '0', '26', 'L');
INSERT INTO `my_pcd` VALUES ('3361', '623027', '6230', '夏河县', '3', '1', '0', '27', 'X');
INSERT INTO `my_pcd` VALUES ('3362', '63', '0', '青海省', '1', '1', '0', '63', 'Q');
INSERT INTO `my_pcd` VALUES ('3363', '6301', '63', '西宁市', '2', '1', '0', '1', 'X');
INSERT INTO `my_pcd` VALUES ('3364', '630101', '6301', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3365', '630102', '6301', '城东区', '3', '1', '0', '2', 'C');
INSERT INTO `my_pcd` VALUES ('3366', '630103', '6301', '城中区', '3', '1', '0', '3', 'C');
INSERT INTO `my_pcd` VALUES ('3367', '630104', '6301', '城西区', '3', '1', '0', '4', 'C');
INSERT INTO `my_pcd` VALUES ('3368', '630105', '6301', '城北区', '3', '1', '0', '5', 'C');
INSERT INTO `my_pcd` VALUES ('3369', '630121', '6301', '大通回族土族自治县', '3', '1', '0', '21', 'D');
INSERT INTO `my_pcd` VALUES ('3370', '630122', '6301', '湟中县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3371', '630123', '6301', '湟源县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3372', '6321', '63', '海东地区', '2', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('3373', '632121', '6321', '平安县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('3374', '632122', '6321', '民和县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('3375', '632123', '6321', '乐都县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('3376', '632126', '6321', '互助县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('3377', '632127', '6321', '化隆回族自治县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('3378', '632128', '6321', '循化县', '3', '1', '0', '28', 'X');
INSERT INTO `my_pcd` VALUES ('3379', '6322', '63', '海北州', '2', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('3380', '632221', '6322', '门源县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('3381', '632222', '6322', '祁连县', '3', '1', '0', '22', 'Q');
INSERT INTO `my_pcd` VALUES ('3382', '632223', '6322', '海晏县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('3383', '632224', '6322', '刚察县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('3384', '6323', '63', '黄南州', '2', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('3385', '632321', '6323', '同仁县', '3', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('3386', '632322', '6323', '尖扎县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('3387', '632323', '6323', '泽库县', '3', '1', '0', '23', 'Z');
INSERT INTO `my_pcd` VALUES ('3388', '632324', '6323', '河南县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('3389', '6325', '63', '海南州', '2', '1', '0', '25', 'H');
INSERT INTO `my_pcd` VALUES ('3390', '632521', '6325', '共和县', '3', '1', '0', '21', 'G');
INSERT INTO `my_pcd` VALUES ('3391', '632522', '6325', '同德县', '3', '1', '0', '22', 'T');
INSERT INTO `my_pcd` VALUES ('3392', '632523', '6325', '贵德县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('3393', '632524', '6325', '兴海县', '3', '1', '0', '24', 'X');
INSERT INTO `my_pcd` VALUES ('3394', '632525', '6325', '贵南县', '3', '1', '0', '25', 'G');
INSERT INTO `my_pcd` VALUES ('3395', '6326', '63', '果洛州', '2', '1', '0', '26', 'G');
INSERT INTO `my_pcd` VALUES ('3396', '632621', '6326', '玛沁县', '3', '1', '0', '21', 'M');
INSERT INTO `my_pcd` VALUES ('3397', '632622', '6326', '班玛县', '3', '1', '0', '22', 'B');
INSERT INTO `my_pcd` VALUES ('3398', '632623', '6326', '甘德县', '3', '1', '0', '23', 'G');
INSERT INTO `my_pcd` VALUES ('3399', '632624', '6326', '达日县', '3', '1', '0', '24', 'D');
INSERT INTO `my_pcd` VALUES ('3400', '632625', '6326', '久治县', '3', '1', '0', '25', 'J');
INSERT INTO `my_pcd` VALUES ('3401', '632626', '6326', '玛多县', '3', '1', '0', '26', 'M');
INSERT INTO `my_pcd` VALUES ('3402', '6327', '63', '玉树州', '2', '1', '0', '27', 'Y');
INSERT INTO `my_pcd` VALUES ('3403', '632721', '6327', '玉树县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('3404', '632722', '6327', '杂多县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3405', '632723', '6327', '称多县', '3', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('3406', '632724', '6327', '治多县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('3407', '632725', '6327', '囊谦县', '3', '1', '0', '25', 'N');
INSERT INTO `my_pcd` VALUES ('3408', '632726', '6327', '曲麻莱县', '3', '1', '0', '26', 'Q');
INSERT INTO `my_pcd` VALUES ('3409', '6328', '63', '海西州', '2', '1', '0', '28', 'H');
INSERT INTO `my_pcd` VALUES ('3410', '632801', '6328', '格尔木市', '3', '1', '0', '1', 'G');
INSERT INTO `my_pcd` VALUES ('3411', '632802', '6328', '德令哈市', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('3412', '632821', '6328', '乌兰县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('3413', '632822', '6328', '都兰县', '3', '1', '0', '22', 'D');
INSERT INTO `my_pcd` VALUES ('3414', '632823', '6328', '天峻县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('3415', '64', '0', '宁夏回族自治区', '1', '1', '0', '64', 'N');
INSERT INTO `my_pcd` VALUES ('3416', '6401', '64', '银川市', '2', '1', '0', '1', 'Y');
INSERT INTO `my_pcd` VALUES ('3417', '640101', '6401', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3418', '640104', '6401', '兴庆区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('3419', '640105', '6401', '西夏区', '3', '1', '0', '5', 'X');
INSERT INTO `my_pcd` VALUES ('3420', '640106', '6401', '金凤区', '3', '1', '0', '6', 'J');
INSERT INTO `my_pcd` VALUES ('3421', '640121', '6401', '永宁县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('3422', '640122', '6401', '贺兰县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('3423', '640181', '6401', '灵武市', '3', '1', '0', '81', 'L');
INSERT INTO `my_pcd` VALUES ('3424', '6402', '64', '石嘴山市', '2', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('3425', '640201', '6402', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3426', '640202', '6402', '大武口区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('3427', '640205', '6402', '惠农区', '3', '1', '0', '5', 'H');
INSERT INTO `my_pcd` VALUES ('3428', '640221', '6402', '平罗县', '3', '1', '0', '21', 'P');
INSERT INTO `my_pcd` VALUES ('3429', '6403', '64', '吴忠市', '2', '1', '0', '3', 'W');
INSERT INTO `my_pcd` VALUES ('3430', '640301', '6403', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3431', '640302', '6403', '利通区', '3', '1', '0', '2', 'L');
INSERT INTO `my_pcd` VALUES ('3432', '640323', '6403', '盐池县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3433', '640324', '6403', '同心县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('3434', '640381', '6403', '青铜峡市', '3', '1', '0', '81', 'Q');
INSERT INTO `my_pcd` VALUES ('3435', '6404', '64', '固原市', '2', '1', '0', '4', 'G');
INSERT INTO `my_pcd` VALUES ('3436', '640401', '6404', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3437', '640402', '6404', '原州区', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('3438', '640422', '6404', '西吉县', '3', '1', '0', '22', 'X');
INSERT INTO `my_pcd` VALUES ('3439', '640423', '6404', '隆德县', '3', '1', '0', '23', 'L');
INSERT INTO `my_pcd` VALUES ('3440', '640424', '6404', '泾源县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('3441', '640425', '6404', '彭阳县', '3', '1', '0', '25', 'P');
INSERT INTO `my_pcd` VALUES ('3442', '6405', '64', '中卫市', '2', '1', '0', '5', 'Z');
INSERT INTO `my_pcd` VALUES ('3443', '640501', '6405', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3444', '640502', '6405', '沙坡头区', '3', '1', '0', '2', 'S');
INSERT INTO `my_pcd` VALUES ('3445', '640521', '6405', '中宁县', '3', '1', '0', '21', 'Z');
INSERT INTO `my_pcd` VALUES ('3446', '640522', '6405', '海原县', '3', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('3447', '65', '0', '新疆维吾尔自治区', '1', '1', '0', '65', 'X');
INSERT INTO `my_pcd` VALUES ('3448', '6501', '65', '乌鲁木齐市', '2', '1', '0', '1', 'W');
INSERT INTO `my_pcd` VALUES ('3449', '650101', '6501', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3450', '650102', '6501', '天山区', '3', '1', '0', '2', 'T');
INSERT INTO `my_pcd` VALUES ('3451', '650103', '6501', '沙依巴克区', '3', '1', '0', '3', 'S');
INSERT INTO `my_pcd` VALUES ('3452', '650104', '6501', '新市区', '3', '1', '0', '4', 'X');
INSERT INTO `my_pcd` VALUES ('3453', '650105', '6501', '水磨沟区', '3', '1', '0', '5', 'S');
INSERT INTO `my_pcd` VALUES ('3454', '650106', '6501', '头屯河区', '3', '1', '0', '6', 'T');
INSERT INTO `my_pcd` VALUES ('3455', '650107', '6501', '达坂城区', '3', '1', '0', '7', 'D');
INSERT INTO `my_pcd` VALUES ('3456', '650108', '6501', '东山区', '3', '1', '0', '8', 'D');
INSERT INTO `my_pcd` VALUES ('3457', '650121', '6501', '乌鲁木齐县', '3', '1', '0', '21', 'W');
INSERT INTO `my_pcd` VALUES ('3458', '6502', '65', '克拉玛依市', '2', '1', '0', '2', 'K');
INSERT INTO `my_pcd` VALUES ('3459', '650201', '6502', '市辖区', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3460', '650202', '6502', '独山子区', '3', '1', '0', '2', 'D');
INSERT INTO `my_pcd` VALUES ('3461', '650203', '6502', '克拉玛依区', '3', '1', '0', '3', 'K');
INSERT INTO `my_pcd` VALUES ('3462', '650204', '6502', '白碱滩区', '3', '1', '0', '4', 'B');
INSERT INTO `my_pcd` VALUES ('3463', '650205', '6502', '乌尔禾区', '3', '1', '0', '5', 'W');
INSERT INTO `my_pcd` VALUES ('3464', '6521', '65', '吐鲁番地区', '2', '1', '0', '21', 'T');
INSERT INTO `my_pcd` VALUES ('3465', '652101', '6521', '吐鲁番市', '3', '1', '0', '1', 'T');
INSERT INTO `my_pcd` VALUES ('3466', '652122', '6521', '鄯善县', '3', '1', '0', '22', 'Z');
INSERT INTO `my_pcd` VALUES ('3467', '652123', '6521', '托克逊县', '3', '1', '0', '23', 'T');
INSERT INTO `my_pcd` VALUES ('3468', '6522', '65', '哈密地区', '2', '1', '0', '22', 'H');
INSERT INTO `my_pcd` VALUES ('3469', '652201', '6522', '哈密市', '3', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('3470', '652222', '6522', '巴里坤县', '3', '1', '0', '22', 'B');
INSERT INTO `my_pcd` VALUES ('3471', '652223', '6522', '伊吾县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3472', '6523', '65', '昌吉州', '2', '1', '0', '23', 'C');
INSERT INTO `my_pcd` VALUES ('3473', '652301', '6523', '昌吉市', '3', '1', '0', '1', 'C');
INSERT INTO `my_pcd` VALUES ('3474', '652302', '6523', '阜康市', '3', '1', '0', '2', 'F');
INSERT INTO `my_pcd` VALUES ('3475', '652303', '6523', '米泉市', '3', '1', '0', '3', 'M');
INSERT INTO `my_pcd` VALUES ('3476', '652323', '6523', '呼图壁县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('3477', '652324', '6523', '玛纳斯', '3', '1', '0', '24', 'M');
INSERT INTO `my_pcd` VALUES ('3478', '652325', '6523', '奇台县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('3479', '652327', '6523', '吉木萨尔县', '3', '1', '0', '27', 'J');
INSERT INTO `my_pcd` VALUES ('3480', '652328', '6523', '木垒县', '3', '1', '0', '28', 'M');
INSERT INTO `my_pcd` VALUES ('3481', '6527', '65', '博尔塔拉蒙古自治州', '2', '1', '0', '27', 'B');
INSERT INTO `my_pcd` VALUES ('3482', '652701', '6527', '博乐市', '3', '1', '0', '1', 'B');
INSERT INTO `my_pcd` VALUES ('3483', '652722', '6527', '精河县', '3', '1', '0', '22', 'J');
INSERT INTO `my_pcd` VALUES ('3484', '652723', '6527', '温泉县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('3485', '6528', '65', '巴音郭楞蒙古自治州', '2', '1', '0', '28', 'B');
INSERT INTO `my_pcd` VALUES ('3486', '652801', '6528', '库尔勒市', '3', '1', '0', '1', 'K');
INSERT INTO `my_pcd` VALUES ('3487', '652822', '6528', '轮台县', '3', '1', '0', '22', 'L');
INSERT INTO `my_pcd` VALUES ('3488', '652823', '6528', '尉犁县', '3', '1', '0', '23', 'W');
INSERT INTO `my_pcd` VALUES ('3489', '652824', '6528', '若羌县', '3', '1', '0', '24', 'R');
INSERT INTO `my_pcd` VALUES ('3490', '652825', '6528', '且末县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('3491', '652826', '6528', '焉耆县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('3492', '652827', '6528', '和静县', '3', '1', '0', '27', 'H');
INSERT INTO `my_pcd` VALUES ('3493', '652828', '6528', '和硕县', '3', '1', '0', '28', 'H');
INSERT INTO `my_pcd` VALUES ('3494', '652829', '6528', '博湖县', '3', '1', '0', '29', 'B');
INSERT INTO `my_pcd` VALUES ('3495', '6529', '65', '阿克苏地区', '2', '1', '0', '29', 'A');
INSERT INTO `my_pcd` VALUES ('3496', '652901', '6529', '阿克苏市', '3', '1', '0', '1', 'A');
INSERT INTO `my_pcd` VALUES ('3497', '652922', '6529', '温宿县', '3', '1', '0', '22', 'W');
INSERT INTO `my_pcd` VALUES ('3498', '652923', '6529', '库车县', '3', '1', '0', '23', 'K');
INSERT INTO `my_pcd` VALUES ('3499', '652924', '6529', '沙雅县', '3', '1', '0', '24', 'S');
INSERT INTO `my_pcd` VALUES ('3500', '652925', '6529', '新和县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('3501', '652926', '6529', '拜城县', '3', '1', '0', '26', 'B');
INSERT INTO `my_pcd` VALUES ('3502', '652927', '6529', '乌什县', '3', '1', '0', '27', 'W');
INSERT INTO `my_pcd` VALUES ('3503', '652928', '6529', '阿瓦提县', '3', '1', '0', '28', 'A');
INSERT INTO `my_pcd` VALUES ('3504', '652929', '6529', '柯坪县', '3', '1', '0', '29', 'K');
INSERT INTO `my_pcd` VALUES ('3505', '6530', '65', '克州', '2', '1', '0', '30', 'K');
INSERT INTO `my_pcd` VALUES ('3506', '653001', '6530', '阿图什市', '3', '1', '0', '1', 'A');
INSERT INTO `my_pcd` VALUES ('3507', '653022', '6530', '阿克陶县', '3', '1', '0', '22', 'A');
INSERT INTO `my_pcd` VALUES ('3508', '653023', '6530', '阿合奇县', '3', '1', '0', '23', 'A');
INSERT INTO `my_pcd` VALUES ('3509', '653024', '6530', '乌恰县', '3', '1', '0', '24', 'W');
INSERT INTO `my_pcd` VALUES ('3510', '6531', '65', '喀什地区', '2', '1', '0', '31', 'K');
INSERT INTO `my_pcd` VALUES ('3511', '653101', '6531', '喀什市', '3', '1', '0', '1', 'K');
INSERT INTO `my_pcd` VALUES ('3512', '653121', '6531', '疏附县', '3', '1', '0', '21', 'S');
INSERT INTO `my_pcd` VALUES ('3513', '653122', '6531', '疏勒县', '3', '1', '0', '22', 'S');
INSERT INTO `my_pcd` VALUES ('3514', '653123', '6531', '英吉沙县', '3', '1', '0', '23', 'Y');
INSERT INTO `my_pcd` VALUES ('3515', '653124', '6531', '泽普县', '3', '1', '0', '24', 'Z');
INSERT INTO `my_pcd` VALUES ('3516', '653125', '6531', '莎车县', '3', '1', '0', '25', 'S');
INSERT INTO `my_pcd` VALUES ('3517', '653126', '6531', '叶城县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('3518', '653127', '6531', '麦盖提县', '3', '1', '0', '27', 'M');
INSERT INTO `my_pcd` VALUES ('3519', '653128', '6531', '岳普湖县', '3', '1', '0', '28', 'Y');
INSERT INTO `my_pcd` VALUES ('3520', '653129', '6531', '伽师县', '3', '1', '0', '29', 'Z');
INSERT INTO `my_pcd` VALUES ('3521', '653130', '6531', '巴楚县', '3', '1', '0', '30', 'B');
INSERT INTO `my_pcd` VALUES ('3522', '653131', '6531', '塔什库尔干县', '3', '1', '0', '31', 'T');
INSERT INTO `my_pcd` VALUES ('3523', '6532', '65', '和田地区', '2', '1', '0', '32', 'H');
INSERT INTO `my_pcd` VALUES ('3524', '653201', '6532', '和田市', '3', '1', '0', '1', 'H');
INSERT INTO `my_pcd` VALUES ('3525', '653221', '6532', '和田县', '3', '1', '0', '21', 'H');
INSERT INTO `my_pcd` VALUES ('3526', '653222', '6532', '墨玉县', '3', '1', '0', '22', 'M');
INSERT INTO `my_pcd` VALUES ('3527', '653223', '6532', '皮山县', '3', '1', '0', '23', 'P');
INSERT INTO `my_pcd` VALUES ('3528', '653224', '6532', '洛浦县', '3', '1', '0', '24', 'L');
INSERT INTO `my_pcd` VALUES ('3529', '653225', '6532', '策勒县', '3', '1', '0', '25', 'C');
INSERT INTO `my_pcd` VALUES ('3530', '653226', '6532', '于田县', '3', '1', '0', '26', 'Y');
INSERT INTO `my_pcd` VALUES ('3531', '653227', '6532', '民丰县', '3', '1', '0', '27', 'M');
INSERT INTO `my_pcd` VALUES ('3532', '6540', '65', '伊犁州', '2', '1', '0', '40', 'Y');
INSERT INTO `my_pcd` VALUES ('3533', '654002', '6540', '伊宁市', '3', '1', '0', '2', 'Y');
INSERT INTO `my_pcd` VALUES ('3534', '654003', '6540', '奎屯市', '3', '1', '0', '3', 'K');
INSERT INTO `my_pcd` VALUES ('3535', '654021', '6540', '伊宁县', '3', '1', '0', '21', 'Y');
INSERT INTO `my_pcd` VALUES ('3536', '654022', '6540', '察布查尔县', '3', '1', '0', '22', 'C');
INSERT INTO `my_pcd` VALUES ('3537', '654023', '6540', '霍城县', '3', '1', '0', '23', 'H');
INSERT INTO `my_pcd` VALUES ('3538', '654024', '6540', '巩留县', '3', '1', '0', '24', 'G');
INSERT INTO `my_pcd` VALUES ('3539', '654025', '6540', '新源县', '3', '1', '0', '25', 'X');
INSERT INTO `my_pcd` VALUES ('3540', '654026', '6540', '昭苏县', '3', '1', '0', '26', 'Z');
INSERT INTO `my_pcd` VALUES ('3541', '654027', '6540', '特克斯县', '3', '1', '0', '27', 'T');
INSERT INTO `my_pcd` VALUES ('3542', '654028', '6540', '尼勒克县', '3', '1', '0', '28', 'N');
INSERT INTO `my_pcd` VALUES ('3543', '6542', '65', '塔城地区', '2', '1', '0', '42', 'T');
INSERT INTO `my_pcd` VALUES ('3544', '654201', '6542', '塔城市', '3', '1', '0', '1', 'T');
INSERT INTO `my_pcd` VALUES ('3545', '654202', '6542', '乌苏市', '3', '1', '0', '2', 'W');
INSERT INTO `my_pcd` VALUES ('3546', '654221', '6542', '额敏县', '3', '1', '0', '21', 'E');
INSERT INTO `my_pcd` VALUES ('3547', '654223', '6542', '沙湾县', '3', '1', '0', '23', 'S');
INSERT INTO `my_pcd` VALUES ('3548', '654224', '6542', '托里县', '3', '1', '0', '24', 'T');
INSERT INTO `my_pcd` VALUES ('3549', '654225', '6542', '裕民县', '3', '1', '0', '25', 'Y');
INSERT INTO `my_pcd` VALUES ('3550', '654226', '6542', '和布克赛尔蒙古自治县', '3', '1', '0', '26', 'H');
INSERT INTO `my_pcd` VALUES ('3551', '6543', '65', '阿勒泰地区', '2', '1', '0', '43', 'A');
INSERT INTO `my_pcd` VALUES ('3552', '654301', '6543', '阿勒泰市', '3', '1', '0', '1', 'A');
INSERT INTO `my_pcd` VALUES ('3553', '654321', '6543', '布尔津县', '3', '1', '0', '21', 'B');
INSERT INTO `my_pcd` VALUES ('3554', '654322', '6543', '富蕴县', '3', '1', '0', '22', 'F');
INSERT INTO `my_pcd` VALUES ('3555', '654323', '6543', '福海县', '3', '1', '0', '23', 'F');
INSERT INTO `my_pcd` VALUES ('3556', '654324', '6543', '哈巴河县', '3', '1', '0', '24', 'H');
INSERT INTO `my_pcd` VALUES ('3557', '654325', '6543', '青河县', '3', '1', '0', '25', 'Q');
INSERT INTO `my_pcd` VALUES ('3558', '654326', '6543', '吉木乃县', '3', '1', '0', '26', 'J');
INSERT INTO `my_pcd` VALUES ('3559', '6590', '65', '省直辖行政单位', '2', '1', '0', '90', 'S');
INSERT INTO `my_pcd` VALUES ('3560', '659001', '6590', '石河子市', '3', '1', '0', '1', 'S');
INSERT INTO `my_pcd` VALUES ('3561', '659002', '6590', '阿拉尔市', '3', '1', '0', '2', 'A');
INSERT INTO `my_pcd` VALUES ('3562', '659003', '6590', '图木舒克市', '3', '1', '0', '3', 'T');
INSERT INTO `my_pcd` VALUES ('3563', '659004', '6590', '五家渠市', '3', '1', '0', '4', 'W');
INSERT INTO `my_pcd` VALUES ('3564', '71', '0', '台湾省', '1', '1', '0', '71', 'T');
INSERT INTO `my_pcd` VALUES ('3565', '81', '0', '香港特别行政区', '1', '1', '0', '81', 'X');
INSERT INTO `my_pcd` VALUES ('3566', '82', '0', '澳门特别行政区', '1', '1', '0', '82', 'A');
INSERT INTO `my_pcd` VALUES ('3567', '820054', '82', '澳门特别行政区', '1', '1', '0', '0', 'A');

-- -----------------------------
-- Table structure for `my_point_log`
-- -----------------------------
DROP TABLE IF EXISTS `my_point_log`;
CREATE TABLE `my_point_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memberid` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  `act` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8 COMMENT='积分记录表';

-- -----------------------------
-- Records of `my_point_log`
-- -----------------------------
INSERT INTO `my_point_log` VALUES ('111', '137', '10', '购买商品返积分', '2016-10-25 10:55:10');
INSERT INTO `my_point_log` VALUES ('112', '146', '10', '购买商品返积分', '2016-10-27 14:48:27');
INSERT INTO `my_point_log` VALUES ('113', '198', '10', '购买商品返积分', '2016-11-03 10:03:14');
INSERT INTO `my_point_log` VALUES ('114', '196', '30', '购买商品返积分', '2016-11-03 10:03:51');
INSERT INTO `my_point_log` VALUES ('115', '196', '200', '购买商品返积分', '2016-11-03 10:07:44');
INSERT INTO `my_point_log` VALUES ('116', '198', '200', '购买商品返积分', '2016-11-03 10:14:58');
INSERT INTO `my_point_log` VALUES ('117', '198', '200', '购买商品返积分', '2016-11-03 10:20:23');
INSERT INTO `my_point_log` VALUES ('118', '198', '100', '购买商品返积分', '2016-11-03 10:24:32');
INSERT INTO `my_point_log` VALUES ('119', '196', '100', '购买商品返积分', '2016-11-03 10:27:00');
INSERT INTO `my_point_log` VALUES ('120', '196', '430', '购买商品返积分', '2016-11-03 10:30:59');
INSERT INTO `my_point_log` VALUES ('121', '195', '1900', '购买商品返积分', '2016-11-04 08:27:19');
INSERT INTO `my_point_log` VALUES ('122', '195', '10', '消费使用积分', '2016-11-04 08:28:08');
INSERT INTO `my_point_log` VALUES ('123', '203', '2000', '购买商品返积分', '2016-11-04 10:44:34');
INSERT INTO `my_point_log` VALUES ('124', '203', '1000', '购买商品返积分', '2016-11-04 10:46:33');
INSERT INTO `my_point_log` VALUES ('125', '198', '10', '消费使用积分', '2016-11-04 14:43:09');
INSERT INTO `my_point_log` VALUES ('126', '225', '498', '消费使用积分', '2016-11-09 09:24:29');
INSERT INTO `my_point_log` VALUES ('127', '225', '498', '消费使用积分', '2016-11-09 09:27:25');
INSERT INTO `my_point_log` VALUES ('128', '202', '1', '购买商品返积分', '2016-11-11 09:49:58');
INSERT INTO `my_point_log` VALUES ('129', '1', '1', '购买商品返积分', '2016-12-08 14:07:00');

-- -----------------------------
-- Table structure for `my_role`
-- -----------------------------
DROP TABLE IF EXISTS `my_role`;
CREATE TABLE `my_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `sort` tinyint(3) DEFAULT NULL,
  `channel` varchar(255) DEFAULT NULL,
  `shop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `my_role`
-- -----------------------------
INSERT INTO `my_role` VALUES ('1', 'admin', '0', '1', '管理员', '1', '', '');
INSERT INTO `my_role` VALUES ('2', 'tester', '0', '1', '测试员', '2', '', '');

-- -----------------------------
-- Table structure for `my_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `my_role_user`;
CREATE TABLE `my_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- -----------------------------
-- Records of `my_role_user`
-- -----------------------------
INSERT INTO `my_role_user` VALUES ('1', '2');

-- -----------------------------
-- Table structure for `my_user`
-- -----------------------------
DROP TABLE IF EXISTS `my_user`;
CREATE TABLE `my_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT '',
  `userpwd` varchar(50) DEFAULT '',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `remark` varchar(255) DEFAULT NULL,
  `status` tinyint(3) DEFAULT NULL,
  `sort` tinyint(3) DEFAULT NULL,
  `logtimes` int(11) DEFAULT '0',
  `lastlogtime` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `lastlogip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `my_user`
-- -----------------------------
INSERT INTO `my_user` VALUES ('1', 'administrator', '21232f297a57a5a743894a0e4a801fc3', '2016-12-08 13:42:25', '超级管理员', '1', '1', '147', '2016-12-08 13:42:25', '127.0.0.1');
INSERT INTO `my_user` VALUES ('2', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2016-11-29 16:47:59', '系统管理员', '1', '1', '149', '2016-11-29 16:47:59', '110.184.8.183');

-- -----------------------------
-- Table structure for `my_wechat_keyword`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_keyword`;
CREATE TABLE `my_wechat_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '关键词',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `isfull` tinyint(3) DEFAULT '0' COMMENT '0-模糊查询，1-全字匹配',
  `isall` tinyint(3) DEFAULT '0' COMMENT '0-随机回复，1-全部回复',
  `ismenu` tinyint(3) DEFAULT '0' COMMENT '0-否，1-是',
  `keyword_rule_id` int(11) DEFAULT '0' COMMENT '规则ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='微信-关键词回复';

-- -----------------------------
-- Records of `my_wechat_keyword`
-- -----------------------------
INSERT INTO `my_wechat_keyword` VALUES ('41', 'subscribe', '2016-12-08 11:33:31', '1', '', '0', '2');
INSERT INTO `my_wechat_keyword` VALUES ('39', '您好', '2016-12-08 11:31:23', '1', '', '0', '3');

-- -----------------------------
-- Table structure for `my_wechat_keyword_reply`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_keyword_reply`;
CREATE TABLE `my_wechat_keyword_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword_id` int(11) DEFAULT '0' COMMENT '关键词ID',
  `type` tinyint(3) DEFAULT '1' COMMENT '0-文字，1-图片，2-图文，3-语音，4-视频，5-app',
  `info` varchar(2048) DEFAULT NULL COMMENT '回复内容',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort` int(11) DEFAULT NULL COMMENT '0',
  `status` tinyint(3) DEFAULT '1' COMMENT '可否购买',
  `keyword_ids` varchar(255) DEFAULT ',' COMMENT '关键词ID列表，允许多个关键词回复同一内容',
  `keyword_rule_id` int(11) DEFAULT '0' COMMENT '规则ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='微信-关键词回复';

-- -----------------------------
-- Records of `my_wechat_keyword_reply`
-- -----------------------------
INSERT INTO `my_wechat_keyword_reply` VALUES ('51', '39', '0', '您好，感谢关注！', '2016-12-08 11:31:23', '', '1', ',39,', '3');
INSERT INTO `my_wechat_keyword_reply` VALUES ('53', '41', '0', '欢迎关注！！', '2016-12-08 11:33:31', '', '1', ',41,', '2');

-- -----------------------------
-- Table structure for `my_wechat_keyword_rule`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_keyword_rule`;
CREATE TABLE `my_wechat_keyword_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '规则名称',
  `title` varchar(1024) DEFAULT NULL COMMENT '关键词列表',
  `num` varchar(255) DEFAULT NULL COMMENT '统计数',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='微信-关键词回复';

-- -----------------------------
-- Records of `my_wechat_keyword_rule`
-- -----------------------------
INSERT INTO `my_wechat_keyword_rule` VALUES ('2', '关注回复', 'a:1:{i:0;s:9:\"subscribe\";}', 'a:6:{i:0;i:1;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;}', '2016-12-08 11:28:16');
INSERT INTO `my_wechat_keyword_rule` VALUES ('3', '您好', 'a:1:{i:0;s:6:\"您好\";}', 'a:6:{i:0;i:1;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;}', '2016-11-08 17:17:00');

-- -----------------------------
-- Table structure for `my_wechat_material`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_material`;
CREATE TABLE `my_wechat_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) DEFAULT '1' COMMENT '1-图片，2-图文，3-语音，4-视频，5-app',
  `remark` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL COMMENT '图片地址，语音地址，视频地址',
  `size` varchar(255) DEFAULT NULL COMMENT '素材尺寸',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(3) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='微信-素材表：1-图片，2-图文，3-语音，4-视频';

-- -----------------------------
-- Records of `my_wechat_material`
-- -----------------------------
INSERT INTO `my_wechat_material` VALUES ('10', '2', '', '', '', '2016-11-07 11:21:19', '1');
INSERT INTO `my_wechat_material` VALUES ('13', '2', '', '', '', '2016-11-07 16:52:47', '1');
INSERT INTO `my_wechat_material` VALUES ('14', '2', '', '', '', '2016-11-07 17:01:37', '1');
INSERT INTO `my_wechat_material` VALUES ('15', '2', '', '', '', '2016-11-07 17:02:58', '1');
INSERT INTO `my_wechat_material` VALUES ('16', '2', '', '', '', '2016-11-08 10:49:05', '1');
INSERT INTO `my_wechat_material` VALUES ('17', '2', '', '', '', '2016-11-08 11:07:59', '1');
INSERT INTO `my_wechat_material` VALUES ('18', '2', '', '', '', '2016-11-09 15:40:01', '1');

-- -----------------------------
-- Table structure for `my_wechat_material_comment`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_material_comment`;
CREATE TABLE `my_wechat_material_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_detail_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `indexpic` varchar(255) DEFAULT NULL,
  `info` varchar(1000) DEFAULT NULL,
  `pid` int(11) DEFAULT '0',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `up` int(11) NOT NULL DEFAULT '0' COMMENT '顶',
  `down` int(11) NOT NULL DEFAULT '0' COMMENT '踩',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='微信-素材评论';


-- -----------------------------
-- Table structure for `my_wechat_material_detail`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_material_detail`;
CREATE TABLE `my_wechat_material_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) DEFAULT '0' COMMENT '素材ID',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `remark` varchar(255) DEFAULT NULL COMMENT '标题',
  `info` text COMMENT '描述',
  `indexpic` varchar(255) DEFAULT NULL COMMENT '形象图',
  `panel_name` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `isshowpic` tinyint(3) DEFAULT '0' COMMENT '0-封面不显示在正文，1-显示',
  `iscomment` tinyint(3) DEFAULT '0' COMMENT '评论：0-不允许，1-允许',
  `islink` tinyint(3) DEFAULT '0' COMMENT '0-内容，1-外链',
  `url` varchar(1000) DEFAULT NULL COMMENT '外部链接',
  `ourl` varchar(1000) DEFAULT NULL COMMENT '原文链接',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sort` int(11) DEFAULT '0' COMMENT '排序',
  `hits` int(11) DEFAULT '0' COMMENT '点击量',
  `praise` int(11) NOT NULL DEFAULT '0' COMMENT '赞',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='微信-素材-详细表';

-- -----------------------------
-- Records of `my_wechat_material_detail`
-- -----------------------------
INSERT INTO `my_wechat_material_detail` VALUES ('13', '10', '藍琪國際', '蓝琪国际集团有限公司简介', '<p style=\"white-space: normal; text-align: center;\"><span style=\"font-size: 20px;\"><strong><span style=\"font-family: 宋体;\">藍琪國際集團有限公司</span></strong></span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体;\">&nbsp; &nbsp; 蓝琪国际集团有限公司成立于</span>2016<span style=\"font-family: 宋体;\">年</span>1<span style=\"font-family: 宋体;\">月</span>6<span style=\"font-family: 宋体;\">日，注册地为中国香港，注册资</span><span style=\"font-family: 宋体;\">本</span>1000<span style=\"font-family: 宋体;\">万元</span>RMB<span style=\"font-family: 宋体;\">，全部以货币出资。公司主营业务超氧化物歧化酶（</span>SOD<span style=\"font-family: 宋体;\">）系列产</span><span style=\"font-family: 宋体;\">品、生态农庄、</span><span style=\"font-family: 宋体;\">养老养生、婚庆文娱产业等。为使公司的发展有一个高标准、高</span><span style=\"font-family: 宋体;\">起点的开始，公司在成立初</span><span style=\"font-family: 宋体;\">始就严格按照现代化企业的建设要求，对人力资源配</span><span style=\"font-family: 宋体;\">置及机构设置进行了优化组合，着力将</span><span style=\"font-family: 宋体;\">公司打造成一个管理规范、经营专业的现</span><span style=\"font-family: 宋体;\">代化企业。</span></p><p style=\"white-space: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"font-family: 宋体;\">集团公司旗下现有</span>4<span style=\"font-family: 宋体;\">家子公司：</span></p><p style=\"white-space: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;1<span style=\"font-family: 宋体;\">、成都蓝琪生物科技有限公司，公司成立于</span>2016<span style=\"font-family: 宋体;\">年</span>5<span style=\"font-family: 宋体;\">月，注册资本</span>1000<span style=\"font-family: 宋体;\">万元</span>RMB<span style=\"font-family: 宋体;\">，公司性质：蓝琪集团公司全资，公司主要经营物科技技术的超氧化物歧化</span><span style=\"font-family: 宋体;\">酶（</span>SOD<span style=\"font-family: 宋体;\">）系列产品：</span></p><p style=\"white-space: normal; text-indent: 28px;\">1<span style=\"font-family: 宋体;\">）蓝琪</span>SOD<span style=\"font-family: 宋体;\">酶化妆品系列</span></p><p style=\"white-space: normal; text-indent: 28px;\">2<span style=\"font-family: 宋体;\">）蓝琪</span>SOD<span style=\"font-family: 宋体;\">酶茶叶系列</span></p><p style=\"white-space: normal; text-indent: 28px;\">3<span style=\"font-family: 宋体;\">）蓝琪</span>SOD<span style=\"font-family: 宋体;\">酶果蔬饮品系列</span></p><p style=\"white-space: normal; text-indent: 28px;\">4<span style=\"font-family: 宋体;\">）蓝琪</span>SOD<span style=\"font-family: 宋体;\">酶大马士革玫瑰精油系列</span></p><p style=\"white-space: normal; text-indent: 28px;\">5<span style=\"font-family: 宋体;\">）蓝琪</span>SOD<span style=\"font-family: 宋体;\">酶矿泉水</span></p><p style=\"white-space: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;2<span style=\"font-family: 宋体;\">、都江堰蓝琪蓝农业有限公司，公司成立于</span>2016<span style=\"font-family: 宋体;\">年</span>6<span style=\"font-family: 宋体;\">月，注册资本</span>1000<span style=\"font-family: 宋体;\">万</span><span style=\"font-family: 宋体;\">元</span>RMB<span style=\"font-family: 宋体;\">，公</span><span style=\"font-family: 宋体;\">司性质：蓝琪集团公司全资，公司主要经营蓝琪国际养老产业（农</span><span style=\"font-family: 宋体;\">业、观光、旅游、养老等）</span><span style=\"font-family: 宋体;\">占地面积</span>3556<span style=\"font-family: 宋体;\">亩，以高端、候鸟、居家等养老养生为</span><span style=\"font-family: 宋体;\">主。</span></p><p style=\"white-space: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;3<span style=\"font-family: 宋体;\">、四川省遇见你婚庆股份有限公司，公司成立于</span>2014<span style=\"font-family: 宋体;\">年</span>7<span style=\"font-family: 宋体;\">月，注册资本</span>1000<span style=\"font-family: 宋体;\">万元</span>RMB<span style=\"font-family: 宋体;\">，</span><span style=\"font-family: 宋体;\">公司性质：蓝琪集团公司全资，公司主要以婚庆、庆典、文化娱乐等</span><span style=\"font-family: 宋体;\">相关产业为主。</span></p><p style=\"white-space: normal;\">&nbsp;&nbsp;&nbsp;&nbsp;4<span style=\"font-family: 宋体;\">、四川蒙顶山金龙茶业集团有限公司，公司成立于</span>2010<span style=\"font-family: 宋体;\">年</span>10<span style=\"font-family: 宋体;\">月，注册资</span><span style=\"font-family: 宋体;\">本</span>1000<span style=\"font-family: 宋体;\">万元</span>RMB<span style=\"font-family: 宋体;\">，公司性质：蓝琪集团公司控股，公司现有</span>3000<span style=\"font-family: 宋体;\">亩</span>SOD<span style=\"font-family: 宋体;\">酶种植基地</span><span style=\"font-family: 宋体;\">茶园，主要以蒙顶</span><span style=\"font-family: 宋体;\">山绿茶生产加工为主，推行</span>&nbsp;<span style=\"font-family: 宋体;\">“蓝琪·启华”品牌高端私人订</span><span style=\"font-family: 宋体;\">制茶。</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; text-indent: 28px;\">&nbsp;&nbsp;&nbsp;&nbsp;蓝琪集团坚持以人为本，坚持客户为先、诚信、团队、创新、激情的企业价</span><span style=\"font-family: 宋体; text-indent: 28px;\">值</span><span style=\"font-family: 宋体; text-indent: 28px;\">观，秉承“用心、爱心、真心”服务理念，让“蓝琪”成为高贵、智慧、</span><span style=\"font-family: 宋体; text-indent: 28px;\">能力</span><span style=\"font-family: 宋体; text-indent: 28px;\">的</span><span style=\"font-family: 宋体; text-indent: 28px;\">象征，带给客户天使般的快乐。</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; text-indent: 28px;\"><br/></span></p><p><br/></p>', '/Public/uploadfile/file/2016-11-07/581fe9c420182.jpg', '', 'admin', '0', '0', '0', '', '', '2016-11-07 11:21:19', '0', '73', '0');
INSERT INTO `my_wechat_material_detail` VALUES ('16', '13', 'SOD介绍', '', '<p style=\"text-align:center;line-height:28px;background:white\"><strong><span style=\"font-size:20px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#333333\">超氧化物歧化酶-SOD应用领域</span></strong></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">1.</span></strong><strong><span style=\";font-family:宋体;color:#333333\">药物类</span></strong></p><p style=\"text-indent: 32px;line-height: 24px;background: white\"><span style=\"font-family: 宋体\">主要集中在炎症病患者，尤其治疗类风湿关节炎、慢性多发性关节炎、心肌梗塞、心血管病、肿瘤患者以及放射性治疗炎症病患者；</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">2.</span></strong><strong><span style=\";font-family:宋体;color:#333333\">生化制药</span></strong></p><p style=\"text-indent: 32px;line-height: 24px;background: white\"><span style=\"font-family: 宋体\">作为一种生化酶制剂，广泛应用于临床和科研上，可抗衰老，抗肿瘤、调节人体<span style=\"color:black;text-underline:none\">内分泌</span>系统；</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">3.</span></strong><strong><span style=\";font-family:宋体;color:#333333\">化妆品</span></strong></p><p style=\"text-indent: 32px;line-height: 24px;background: white\"><span style=\"font-family: 宋体\">可添加在化妆品中，具有抗氧化抗腐蚀的优良性能。以SOD为主要成份的化妆品风靡世界，引发了化妆品历史上的一场革命，使人类永葆青春美丽梦想成真；</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">4.</span></strong><strong><span style=\";font-family:宋体;color:#333333\">保健食品、饮料</span></strong></p><p style=\"text-indent: 32px;line-height: 24px;background: white\"><span style=\"font-family: 宋体\">SOD糖、SOD口服液、SOD干啤等都非常畅销。在饮料、糖果、糕点等食品中加入SOD既可利用其抗腐蚀性延长保质期，又可调节人体内分泌系统。</span></p><p style=\"margin-left:392px;text-align:center;text-indent:28px;line-height:28px;background:white\"><span style=\"font-size: 12px;font-family: 宋体;color: rgb(136, 136, 136)\">来源：</span><span style=\"outline: none; cursor: pointer; font-size: 12px; font-family: 宋体; color: black;\"><a href=\"http://www.med66.com/new/201212/ly201212111774.shtml\" target=\"_blank\" style=\"outline: none;cursor: pointer\">医学教育网</a></span></p><p style=\"text-align:center;line-height:28px;background:white\"><strong><span style=\"font-size:20px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#333333\"><br/></span></strong></p><p style=\"line-height: 28px; text-align: center; background: white;\"><strong><span style=\"font-size:20px;font-family:&#39;微软雅黑&#39;,&#39;sans-serif&#39;;color:#333333\">超氧化物歧化酶作用</span></strong></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（1）抑制心脑血管疾病：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">机体的衰老与体内氧自由基的产生与积累密切相关，SOD可清除人体内过多的有害的氧自由，是对健康的有益的功效成分。具有调节血脂的保健作用，可预防动脉粥样硬化，预防高血脂引起的心脑血管疾病。降低脂质过氧化物的含量。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（2）抗衰老：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">年龄的增长和某些体外因素会造成机体和皮肤组织自由基产生超过机体正常清除自由基的的能力，从而使皮肤组织造成伤害，导致衰老。由于SOD能够清除自由基，因而可以延缓衰老。人之所以会衰老，老化迹象一点一滴出观，如色素沉淀、体力衰退、是因为体内产生氧化作用，所谓“氧化作用”就类似于生锈，抗氧化剂的补充有助于降低氧化的速度，减慢衰老的脚步。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（3）防治自身免疫性疾病：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">SOD对各类自身免疫性疾病都有一定的疗效。如红斑狼疮、硬皮病、皮肌炎等。对于类风湿关节炎患者应在急性期病变未形成前使用，疗效较好。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（4）肺气肿：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">肺气肿患者亦可使用SOD，但应在病变初期肺弹性纤维尚未受到损害时使用，疗效较好。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（5）辐射病及辐射防护：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">本品可用来治疗因放疗引起的膀胱炎、皮肌炎、红斑狼疮及白细胞减少等疾病，对有可能受到电离辐射的人员，也可注射SOD作为预防措施。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（6）老年性白内障：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">对这类疾病应在进入老年期前即开始经常服用抗氧化剂，或者说经常注射SOD。一旦形成白内障，则应该摘除，因为此时使用SOD无效。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（7）抗氧化：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">医学报告指出， 抗氧化能力的衰退期已提前至40岁左右，光靠蔬果已经不足以消除人体内外共同形成的氧化压力。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（8）预防慢性病：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">自由基是科学家最近才发现导致各种慢性病与老化的罪魁祸首，故说它是“万病之源”，是人体健康的大敌，自由基对身体的伤害是日积月累的，尤其是糖尿病与心血管方面的疾病，林天送博士说：“照顾好您的心血管，就可以活到九十岁。”养成多多摄取抗氧化物的好习惯，保证可以让您远离慢性疾病的威胁。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（10）抗疲劳：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">过多的自由基在体内残存，就犹如毒素蓄积在体内一样，会让人：容易疲劳、厌倦、注意力不集中、常常昏昏沉沉、打哈欠。SOD对上班族熬夜加班、学生应付考试所产生的疲劳，在提振精神及集中注意力方面成效显著，有助于工作绩效的提升，及考试成绩的进步。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（11）消除副作用：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">接受化疗的癌症病患体内的抗氧化能力会大大地降低，万一低到某个程度，自由基就会损害细胞、黏膜、五脏六腑、脑、中枢神经等．所以癌症患者应及时补充抗氧化剂来维持好体力。日本厚生省与美国癌症中心(NCI)均建议使用抗氧化剂来预防癌症或治疗因氧自由基破坏细胞所引起的病变，降低抗癌药物所引起的如呕吐、食欲不振、掉发等副作用。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（12）避免二次伤害：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">手术会引起大量自由基，故建议手术前后口服抗氧化剂来迅速恢复体力，加速伤口复原。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（13）化解女性的危机：</span></strong></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"color: red; font-size: 16px; background: yellow;\">妇女的氧化危机有三：</span></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">A.皮肤出现斑点皱纹： 因为氧自由基无法有效被清除，破坏胶原蛋白、弹力纤维蛋白，使皮肤保湿及维持弹性的功能丧失，皱纹横生，加速黑色素的沉淀；</span></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">B.血液循环不良、经期不顺、黑眼圈、肤色灰暗无光泽；</span></p><p style=\";margin-bottom:0;text-indent:32px;line-height:24px;background:white\"><span style=\"font-size: 16px;\">C.更年期障碍：因为动情激素的缺乏、体内的抗氧化能力降低，常有以下症状出现：阵发性朝热、失眠、夜间流汗、头痛、情绪不稳、心神不宁。</span></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（14）有效降低血脂、胆固醇、血压；</span></strong></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（15）抗辐射；</span></strong></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（16）增强肝肾功能；</span></strong></p><p style=\"background: white\"><strong><span style=\";font-family:宋体;color:#333333\">（17）对糖尿病有明显的恢复作用。</span></strong></p><p style=\"margin-left:392px;text-align:center;text-indent:28px;line-height:28px;background:white\"><span style=\"font-size: 12px;font-family: 宋体;color: rgb(136, 136, 136)\">来源：</span><a href=\"http://www.med66.com/new/201211/tc201211063353.shtml\" target=\"_blank\" style=\"outline: none;cursor: pointer\"><span style=\"font-size: 12px;font-family: 宋体;color: black\">医学教育网</span></a></p><p><br/></p>', '/Public/uploadfile/file/2016-11-07/582040d947e0a.png', '', '蓝琪国际', '0', '0', '0', '', '', '2016-11-07 16:52:47', '0', '31', '0');
INSERT INTO `my_wechat_material_detail` VALUES ('17', '14', '企业文化', '', '<p style=\"text-align: center;\"><img src=\"/Public/uploadfile/ueditor/image/20161107/1478509191149361.jpg\" title=\"1478509191149361.jpg\" alt=\"企业文化1.jpg\"/></p>', '/Public/uploadfile/file/2016-11-07/582040d947e0a.png', '', '蓝琪国际', '0', '0', '0', '', '', '2016-11-07 17:01:37', '0', '26', '0');
INSERT INTO `my_wechat_material_detail` VALUES ('18', '15', '公司组织架构', '', '<p style=\"text-align: center;\"><img src=\"/Public/uploadfile/ueditor/image/20161108/1478590867318248.png\" title=\"1478590867318248.png\" alt=\"蓝琪KT板.png\"/></p>', '/Public/uploadfile/file/2016-11-07/582040d947e0a.png', '', '蓝琪集团', '0', '0', '0', '', '', '2016-11-07 17:02:58', '0', '23', '0');
INSERT INTO `my_wechat_material_detail` VALUES ('19', '16', '会员制度', '', '<p style=\"text-align: center;\"><span style=\"font-size:14px;font-family:&#39;Calibri&#39;,&#39;sans-serif&#39;\"><img src=\"/Public/uploadfile/ueditor/image/20161108/1478573159521094.jpg\" title=\"1478573159521094.jpg\" alt=\"together.jpg\"/></span></p><p style=\"text-align: justify;\"><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;一、蓝琪商城会员免费注册。</span></span></p><p style=\"text-align: justify;\"><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-family: Calibri, sans-serif;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;二、</span><span style=\"font-family: 宋体;\">凡会员在商城上产生消费即成为</span><span style=\"font-family: Calibri, sans-serif;\">VIP</span><span style=\"font-family: 宋体;\">会员，</span><span style=\"font-family: Calibri, sans-serif;\">VIP</span><span style=\"font-family: 宋体;\">会员享受以下权益：</span></span></span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-size: 16px; font-family: 宋体;\">&nbsp;&nbsp;&nbsp;&nbsp;1、会员在商城各分类区域选购产品首次消费需全额付款，后续消费该分类区域产品可享受</span><span style=\"font-size: 16px; font-family: Calibri, sans-serif;\">5</span><span style=\"font-size: 16px; font-family: 宋体;\">折优惠（举例：会员</span><span style=\"font-size: 16px; font-family: Calibri, sans-serif;\">A</span><span style=\"font-size: 16px; font-family: 宋体;\">在商城的“高端订制茗茶”区域首次购买任意一款产品需全额付款，后续在该区域选购任何产品均享受</span><span style=\"font-size: 16px; font-family: Calibri, sans-serif;\">5</span><span style=\"font-size: 16px; font-family: 宋体;\">折优惠，然而在其他分类区域选购产品首次仍需全额消费，后续在同一区域选购产品享受</span><span style=\"font-size: 16px; font-family: Calibri, sans-serif;\">5</span><span style=\"font-size: 16px; font-family: 宋体;\">折优惠）；</span></span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;2、会员在商城消费将获赠等数额积分，可在积分兑换专区以积分换取产品；</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-size: 14px; font-family: Calibri, sans-serif;\"></span>&nbsp;&nbsp;&nbsp;&nbsp;3、VIP会员为蓝琪商城推荐会员可获得推荐佣金，首次消费奖励20%,后续消费奖励5%，此关系终身有效（举例：会员A在蓝琪商城消费后即成为VIP会员，推荐B成为蓝琪商城会员，会员B首次消费会员A可得20%推荐佣金，会员B后续在商城的所有消费会员A均可得到5%的奖励）；</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-size: 14px; font-family: Calibri, sans-serif;\"></span>&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-family: Calibri, sans-serif;\"><span style=\"font-size: 16px; font-family: 宋体, SimSun;\">4、</span>VIP</span><span style=\"font-family: 宋体;\">会员为公司推荐省、市、县级代理，可一次性奖励代理商首次进货款的</span><span style=\"font-size: 16px; font-family: 宋体, SimSun;\">5%</span><span style=\"font-family: 宋体;\">给推荐人；</span></span></span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-size: 14px; font-family: 宋体;\"></span>&nbsp;&nbsp;&nbsp;&nbsp;<span style=\"font-family: 宋体, SimSun; font-size: 16px;\"><span style=\"font-family: 宋体;\">5、</span><span style=\"font-family: Calibri, sans-serif;\">VIP</span><span style=\"font-family: 宋体;\">会员可为公司推荐营销平台及合作团队，经双方考察洽谈后一旦形成合作，平台及团队报单额的</span><span style=\"font-family: Calibri, sans-serif;\">2%</span><span style=\"font-family: 宋体;\">奖励给推荐人；</span></span></span></p><p><span style=\"font-family: 宋体;\">&nbsp;&nbsp;&nbsp;&nbsp;6、其他奖励：</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;（一）会员奖励政策</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 14px; text-indent: 48px;\">&nbsp;&nbsp;&nbsp;<span style=\"font-family: 宋体, SimSun; text-indent: 48px; font-size: 16px;\">&nbsp;1）VIP会员三个月内在商城上消费3万以上奖励蓝琪蒙顶山绿茶套盒一套（1680元/套）；</span></span></p><p><span style=\"font-family: 宋体, SimSun; text-indent: 48px; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;2）VIP会员三个月内在商城上消费4万以上奖励龙裔生命液一瓶（3300元/瓶）；</span></p><p><span style=\"font-family: 宋体, SimSun; text-indent: 48px; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;3）VIP会员三个月内在商城上消费5万以上奖励蓝琪奢华化妆品套盒一套（4990元/套）；</span></p><p><span style=\"font-family: 宋体, SimSun; text-indent: 48px; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;4）VIP会员个人年消费额累计达20万元奖励现金10000元；</span></p><p><span style=\"font-family: 宋体, SimSun; text-indent: 48px; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;5）VIP会员或推荐的其他会员累计年消费额达12万，奖励推荐人国内双人游一次；</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;备注：以上1—3项奖励不能重复享受，但可与第4项、第5项奖励分别重复享受。</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp; （二）团队奖励政策：</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp; &nbsp; 1）团队3个月完成销售额500万以上，奖励团队销售额的5%，以现金方式发放或折合公司当时市值的期权股权；</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp; &nbsp; 2）团队6个月完成销售额1200万以上，奖励团队销售额的7%，以现金方式发放或折合公司当时市值的期权股权；</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp; &nbsp; 3）团队12个月完成销售额 3000万以上，奖励团队销售额的10%，以现金方式发放或折合公司当时市值的期权股权；</span></p><p><span style=\"font-family: 宋体, SimSun; font-size: 16px;\">&nbsp;&nbsp;&nbsp;&nbsp;备注：以上奖励政策均不重复享受，且所奖励给团队的期权股均由公司董事长刘军女士代持。</span></p><p><span style=\"font-size: 14px; font-family: 宋体, SimSun;\"><br/></span></p><p><strong><span style=\"font-family: 宋体; font-size: 18px;\">&nbsp;&nbsp;&nbsp;&nbsp;蓝琪商城的分享经济模式简单明了，收益可观，希望所有会员在切实体验优质产品的同时收获分享经济时代的红利。</span></strong></p><p><strong><span style=\"font-family: 宋体; font-size: 18px;\"><br/></span></strong></p><p><span style=\"font-family: 宋体; font-size: 16px;\">（VIP会员推荐佣金已在个人会员系统作了设定，解释权归公司所有）</span></p><p><img src=\"/Public/uploadfile/ueditor/image/20161108/1478573301310082.jpg\" title=\"1478573301310082.jpg\" alt=\"分享经济.jpg\"/></p>', '/Public/uploadfile/file/2016-11-08/58213d1a83f39.jpg', '', '蓝琪国际', '0', '0', '0', '', '', '2016-11-08 10:49:05', '0', '90', '0');
INSERT INTO `my_wechat_material_detail` VALUES ('20', '17', '平台合作', '', '<p style=\"text-align: left;\"><span style=\"font-family: &#39;arial black&#39;, &#39;avant garde&#39;;\">&nbsp; &nbsp; &nbsp; 蓝琪国际集团有限公司以开放、诚挚的态度与各大电子商务平台，营销团队，以及高端美容会所、SPA会所等渠道合作。双方经过认真考察、谈判，一经达成合作 ，公司将作为产品供货方，负责产品生产、研发、物流，并以最低折扣价向合作方供应优质产品。（细则见合作协议）</span><br/></p><p style=\"text-align: center;\"><span style=\"font-family: &#39;arial black&#39;, &#39;avant garde&#39;;\"><span style=\"font-size: 18px;\"><span style=\"font-family: &#39;arial black&#39;, &#39;avant garde&#39;; font-size: 16px;\"><img src=\"/Public/uploadfile/ueditor/image/20161108/1478574457836858.jpg\" title=\"1478574457836858.jpg\" alt=\"合作.jpg\"/></span></span></span></p>', '/Public/uploadfile/file/2016-11-08/5821418c0d6d6.jpg', '', '蓝琪国际', '0', '0', '0', '', '', '2016-11-08 11:07:59', '0', '48', '0');
INSERT INTO `my_wechat_material_detail` VALUES ('21', '18', '公司介绍', '', '<p style=\"text-align: center;\"><img src=\"/Public/uploadfile/ueditor/image/20161109/1478677188522516.jpg\" title=\"1478677188522516.jpg\" alt=\"公司简介1.jpg\"/></p>', '/Public/uploadfile/file/2016-11-07/582012671b099.jpg', '', '蓝琪国际', '0', '0', '0', '', '', '2016-11-09 15:40:01', '0', '25', '0');

-- -----------------------------
-- Table structure for `my_wechat_mp`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_mp`;
CREATE TABLE `my_wechat_mp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL COMMENT '微信后台用户名',
  `userpwd` varchar(255) DEFAULT NULL COMMENT '微信后台密码',
  `panel_edition` tinyint(3) DEFAULT '0' COMMENT '0-微信，1-易信',
  `panel_name` varchar(255) DEFAULT NULL COMMENT '账号名称',
  `panel_username` varchar(255) DEFAULT NULL COMMENT '公众号',
  `panel_originid` varchar(255) DEFAULT NULL COMMENT '原始ID',
  `panel_avatar` varchar(255) DEFAULT NULL COMMENT '公众号头像',
  `panel_fans` int(11) DEFAULT NULL COMMENT '粉丝数量',
  `panel_code` varchar(255) DEFAULT NULL COMMENT '公众号二维码',
  `panel_cert` tinyint(3) DEFAULT '0' COMMENT '是否认证',
  `panel_type` tinyint(3) DEFAULT '0' COMMENT '0-订阅号，1-服务号',
  `panel_fakeid` varchar(255) DEFAULT NULL COMMENT 'fakeid',
  `provinceid` int(11) DEFAULT '0',
  `cityid` int(11) DEFAULT '0',
  `districtid` int(11) DEFAULT '0',
  `proname` varchar(255) DEFAULT NULL,
  `cityname` varchar(255) DEFAULT NULL,
  `disname` varchar(255) DEFAULT NULL,
  `app_secret` varchar(255) DEFAULT NULL COMMENT '微信-App Secret',
  `app_id` varchar(255) DEFAULT NULL COMMENT '微信-App Id',
  `app_token` varchar(255) DEFAULT NULL COMMENT '微信-token',
  `app_mchid` varchar(255) DEFAULT NULL COMMENT '微信-支付-受理商ID，身份标识',
  `app_key` varchar(255) DEFAULT NULL COMMENT '微信-支付-商户支付密钥Key',
  `app_aeskey` varchar(255) DEFAULT NULL COMMENT '微信-消息加密密钥',
  `app_url` varchar(255) DEFAULT NULL COMMENT '公众号接口地址',
  `is_default` tinyint(3) DEFAULT '0' COMMENT '是否默认账号：0-否，1-是',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `addip` varchar(50) DEFAULT NULL,
  `status` tinyint(3) DEFAULT '0',
  `ourl` varchar(1000) DEFAULT NULL COMMENT '原文链接',
  `couponid` int(11) DEFAULT '0' COMMENT '关注返券类型',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='平台用户添加的公众号表';

-- -----------------------------
-- Records of `my_wechat_mp`
-- -----------------------------
INSERT INTO `my_wechat_mp` VALUES ('1', 'jnetwork@qq.com', 'IKNfbGzhqiqmKyhpg', '0', 'weixingcn', '45833669@qq.com', 'gh_c41fd47a6206', '/Public/uploadfile/file/0/2015-03-01/1658091352.jpg', '6', '/Public/uploadfile/file/0/2015-03-01/1658091917.jpg', '1', '1', '3083420429', '28', '225', '1877', '四川省', '成都市', '金牛区', 'cb87f04df4eab5097f251f731e65388c', 'wx4cbce9c40ee7c16d', 'weixingcn', '10013319', 'zlwxweixingcn198712115421xcjqjfc', 'cqdKJJpchcUiaczHsOtkMMzNUxKrsSIPjZbuQEQSVlF', 'http://longxiang.web188.net/Wechat/', '1', '2015-03-01 16:43:19', '127.0.0.1', '1', '', '0');

-- -----------------------------
-- Table structure for `my_wechat_setting`
-- -----------------------------
DROP TABLE IF EXISTS `my_wechat_setting`;
CREATE TABLE `my_wechat_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL COMMENT '接收通知的邮箱',
  `mobile` varchar(255) DEFAULT NULL COMMENT '接收通知的手机号',
  `app_response` tinyint(3) DEFAULT '0' COMMENT '响应方式：0-图文，1-链接',
  `app_title` varchar(255) DEFAULT NULL COMMENT '图文标题',
  `app_intro` varchar(255) DEFAULT NULL COMMENT '图文简介',
  `app_cover` varchar(255) DEFAULT NULL COMMENT '图文封面',
  `menu` varchar(10240) DEFAULT NULL COMMENT '用一个字段来存-微信自定义菜单',
  `items` varchar(10240) DEFAULT NULL COMMENT '用一个字段来存-微信自定义菜单',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='应用-基础设置表*';

-- -----------------------------
-- Records of `my_wechat_setting`
-- -----------------------------
INSERT INTO `my_wechat_setting` VALUES ('1', '', '', '0', '', '', '', '{\"button\":[{\"type\":\"view\",\"name\":\"龙翔首页\",\"url\":\"http:\\/\\/longxiang.web188.net\\/\"}]}', '龙翔首页,,http://longxiang.web188.net/,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,');
